var socialcomponentsJSloaded = true;

function showNextPage(moIdVal,actionType,currentPageNum) {
        var xmlCurrentPageNo=document.getElementById("currentPageNo_"+moIdVal);
        var formCurrentPageNum=document.getElementById(currentPageNum);
		var actionType=document.getElementById(actionType);
        if (xmlCurrentPageNo) {
            var xmlCurrentPageNoVal = xmlCurrentPageNo.value;
			xmlCurrentPageNoVal = parseInt(xmlCurrentPageNoVal) + 1;
            if (formCurrentPageNum) {
                formCurrentPageNum.value = xmlCurrentPageNoVal;
            }
            showCommentsList(moIdVal, actionType, "list", formCurrentPageNum.value);
        }
    }

    function showPrevPage(moIdVal,actionType,currentPageNum) {
        var xmlCurrentPageNo=document.getElementById("currentPageNo_"+moIdVal);
        var formCurrentPageNum=document.getElementById(currentPageNum);
        if (xmlCurrentPageNo) {
            var xmlCurrentPageNoValue = xmlCurrentPageNo.value;
            xmlCurrentPageNoValue = parseInt(xmlCurrentPageNoValue) - 1;
            if (formCurrentPageNum) {
                formCurrentPageNum.value = xmlCurrentPageNoValue;
            }
            showCommentsList(moIdVal, actionType, "list", formCurrentPageNum.value);
        }
    }

    function showFirstPage(moIdVal,actionType,currentPageNum) {
        var formCurrentPageNum=document.getElementById(currentPageNum);
        if (formCurrentPageNum) {
            formCurrentPageNum.value = "1";
        }
        showCommentsList(moIdVal, actionType, "list", formCurrentPageNum.value);
    }

    function showLastPage(moIdVal,actionType,currentPageNum) {
         var lastPageNo=document.getElementById("lastPageNo_"+moIdVal);
          var formCurrentPageNum=document.getElementById(currentPageNum);
        if (lastPageNo) {
            var lastPageNoValue = lastPageNo.value;
            if (formCurrentPageNum) {
                formCurrentPageNum.value = lastPageNoValue;
            }
            showCommentsList(moIdVal, actionType, "list", formCurrentPageNum.value);
        }
    }

    function jumpToPage(event,obj,moIdVal,actionType,currentPageNum){
        var lastPageNum =document.getElementById("lastPageNo_"+moIdVal);
        var formCurrentPageNum=document.getElementById(currentPageNum);
        //pressed enter key
        if(event.keyCode == 13){
            if(obj){
                var pageNumIdVal=obj.value;
                if(lastPageNum){
                    var lastPageNumValue=lastPageNum.value;
                    if(pageNumIdVal == '' || isNaN(pageNumIdVal) || pageNumIdVal < 1 ||  parseInt(pageNumIdVal) > parseInt(lastPageNumValue)){
                        alert(ERROR_PAGE_NUMBER_MESSAGE+" "+lastPageNumValue);
                        return ;
                    }
                    if(formCurrentPageNum) {
                        formCurrentPageNum.value=pageNumIdVal;
                    }
                    showCommentsList(moIdVal, actionType, "list",formCurrentPageNum);
                }
            }
        }
    }

function xmlhttpReqPost(strURL, strQuery, strCallBack, divId, args1, moIdVal) {
	//alert(" calling xmlhttpreq ");
        var xmlHttpReq;
        try{
            // Firefox, Opera 8.0+, Safari
            xmlHttpReq=new XMLHttpRequest();
        } catch (restActionExc1){
            // Internet Explorer
            try{
                xmlHttpReq=new ActiveXObject("Msxml2.XMLHTTP");
            }catch (restActionExc2){
                xmlHttpReq=new ActiveXObject("Microsoft.XMLHTTP");
            }
        }
        xmlHttpReq.open('POST', strURL+"?"+strQuery, true);
        xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        if(divId){
            divId.className="vui-vcs-bigWaiting";
        }
        xmlHttpReq.onreadystatechange = function() {
            if (xmlHttpReq.readyState == 4) {
                if(divId){
                    divId.className="";
                }
                strCallBack(xmlHttpReq.responseText, args1, moIdVal);
            }
        }
        xmlHttpReq.send(strQuery);
    }

    function commentResponseHandler(responseText,args,moIdVal){
        var response = responseText || "no response text";
        var showCommentsListDiv =document.getElementById('showCommentsListDiv_'+moIdVal);
        if (showCommentsListDiv){
            showCommentsListDiv.innerHTML = response;
        }
    }

function addComment(moIdVal, actionType, createActionVal, commentValue, currentPageNum) {
        var xmlCurrentPageNo=document.getElementById("currentPageNo_"+moIdVal);
        var formCurrentPageNum=document.getElementById(currentPageNum);
        var errormsgDiv=document.getElementById("errormsg_"+moIdVal);
        var successmsgDiv=document.getElementById("successmsg_"+moIdVal);
        var commentDiv=document.getElementById("comment_"+moIdVal);
        var actionType=document.getElementById(actionType);
        var commentValue=document.getElementById(commentValue);
        if (errormsgDiv) {
            errormsgDiv.style.display = "none";
        }
        if (successmsgDiv) {
            successmsgDiv.style.display = "none";
        }
        if ( commentDiv && trim(commentDiv.value).length == 0) {
            alert(COMMENTS_ALERT_MESSAGE);
            return;
        }
        if(actionType) {
            actionType.value=createActionVal;
        }
        if(commentValue) {
            commentValue.value=commentDiv.value;
        }
        if(showCommentsList){
            if(xmlCurrentPageNo){
               formCurrentPageNum.value = xmlCurrentPageNo.value;
            }
            showCommentsList(moIdVal, actionType, createActionVal, formCurrentPageNum.value);
        }
        commentDiv.value="";
    }

    function showCommentsList(moIdVal, actionType, actionValue, currentPageNum) {
        var showCommentsListDiv =document.getElementById('showCommentsListDiv_'+moIdVal);
        if(showCommentsListDiv) {
            var url = requestContext+"/views/community/commentsXHTMLView.jsp";
            var queryStr="";
            var commentListForm=document.forms['commentListFormName_'+moIdVal];
            for (i=0; i<commentListForm.elements.length; i++) {
                var element = commentListForm.elements[i];
                if (element.name != '') {
                    queryStr += element.name + "=" + encodeURIComponent(trim(element.value)) + "&";
                }
            }
            xmlhttpReqPost(url, queryStr, commentResponseHandler, showCommentsListDiv, "", moIdVal);
            //to handle page refresh or f5 : setting current action type as list and pagination as 1
            actionType.value="list";
            currentPageNum.value="1";
        }
    }



 function submitRating(myRating, actionType, actionValue, ratingValue, moIdVal) {
        var errorMsgObj = document.getElementById("errormsg_"+moIdVal);
        var successMsgObj = document.getElementById("successmsg_"+moIdVal);
        if (errorMsgObj) {
            errorMsgObj.style.display = "none";
        }
        if (successMsgObj) {
            successMsgObj.style.display = "none";
        }

        var myForm =document.forms['ratingListFormName_'+moIdVal];
        if (myForm) {
            var actionType = myForm.actionType;
            var ratingValue = myForm.ratingValue;
            if (actionType) {
                actionType.value = actionValue;
            }
            if (ratingValue) {
                ratingValue.value = myRating;
            }
        }

        if (showRatingsList) {
            showRatingsList(moIdVal,actionType);
        }
    }

    function toggleStar(oImg,moIdVal) {
        var userRating = document.getElementById("userRating_"+moIdVal);
        if (userRating) {
            userRating.src = requestContext+"/community/images/rating_" + oImg + ".gif";
        }
    }

    function setUserRating(oImg,moIdVal) {
        var userRating = document.getElementById("userRating_"+moIdVal);
        if ((userRating) && (userRating.src != oImg)) {
            userRating.src = oImg;
        }
    }

    function ratingResponseHandler(responseText,args,moIdVal){
        var response = responseText || "no response text";
        var showRatingsListDiv =document.getElementById('showRatingsListDiv_'+moIdVal);
        if (showRatingsListDiv){
            showRatingsListDiv.innerHTML = response;
        }
    }

    function showRatingsList(moIdVal,actionType) {
        var showRatingsListDiv = document.getElementById('showRatingsListDiv_'+moIdVal);
        if((showRatingsListDiv)){
            var url = requestContext+"/views/community/ratingsXHTMLView.jsp";
            var queryStr="";
            var ratingForm=document.forms['ratingListFormName_'+moIdVal];
            for (i=0; i<ratingForm.elements.length; i++) {
                var element = ratingForm.elements[i];
                if (element.name != '') {
                    queryStr += element.name + "=" + escape(trim(element.value)) + "&";
                }
            }
            xmlhttpReqPost(url, queryStr, ratingResponseHandler, showRatingsListDiv, "", moIdVal);
            //to handle page refresh or f5 : setting current action type as list
            if (actionType) {
                actionType.value = "list";
            }
        }
    }

    function trim(string) {
        return string.replace(/^\s+|\s+$/g,"");
    }