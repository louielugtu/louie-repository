var ie=document.all
var ns6=document.getElementById && !document.all
var enabletip=false
if (ie||ns6)
var tipobj=document.all? document.all["dhtmltooltip"] : document.getElementById? document.getElementById("dhtmltooltip") : ""

function ietruebody(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function ddrivetip(thetext, thecolor, thewidth){
if (ns6||ie){
if (typeof thewidth!="undefined") tipobj.style.width=thewidth+"px"
if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor
tipobj.innerHTML=thetext
enabletip=true
return false
}
}

function positiontip(e){
if (enabletip){
var curX=(ns6)?e.pageX : event.clientX+ietruebody().scrollLeft;
var curY=(ns6)?e.pageY : event.clientY+ietruebody().scrollTop;
//Find out how close the mouse is to the corner of the window
var rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20
var bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20

var leftedge=(offsetxpoint<0)? offsetxpoint*(-1) : -1000

//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<tipobj.offsetWidth)
//move the horizontal position of the menu to the left by it's width
tipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+"px" : window.pageXOffset+e.clientX-tipobj.offsetWidth+"px"
else if (curX<leftedge)
tipobj.style.left="5px"
else
//position the horizontal position of the menu where the mouse is positioned
tipobj.style.left=curX+offsetxpoint+"px"

//same concept with the vertical position
if (bottomedge<tipobj.offsetHeight)
tipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+"px" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+"px"
else
tipobj.style.top=curY+offsetypoint+"px"
tipobj.style.visibility="visible"
}
}

function hideddrivetip(){
if (ns6||ie){
enabletip=false
tipobj.style.visibility="hidden"
tipobj.style.left="-1000px"
tipobj.style.backgroundColor=''
tipobj.style.width=''
}
}

document.onmousemove=positiontip

// disable enable function
function enableSettings() {
			document.formname.ttl.disabled = false;
			document.formname.seconds.disabled = false;
			document.formname.regenerate.disabled = false;
			document.formname.stale.disabled = false;
			document.formname.Import.disabled = false;
			document.formname.Export.disabled = false;
		}

function disableSettings() {
			document.formname.ttl.disabled = true;
			document.formname.seconds.disabled = true;
			document.formname.regenerate.disabled = true;
			document.formname.stale.disabled = true;
			document.formname.Import.disabled = true;
			document.formname.Export.disabled = true;
		}


// expand collapse //

 function collapse(ID)
  {
    document.getElementById('item'+ID).style.display = 'none';
    document.getElementById('expander'+ID).innerHTML = '<a href="javascript:expand('+ID+')" title="Expand this section"><img src="/vgn-ext-templating-cma/common/images/icn_container_close.gif" name="imgfirst"></a>';
  }
 
 function expand(ID)
  {
    document.getElementById('item'+ID).style.display = 'block';
    document.getElementById('expander'+ID).innerHTML = '<a href="javascript:collapse('+ID+')" title="Collapse this section"><img src="/vgn-ext-templating-cma/common/images/icn_container_open.gif" name="imgfirst"></a>';	
  }

function collapseAll(n)
{
  var i;
  for (i=0; i<=n; i++)
  {
    collapse(i);
  }
  document.getElementById("expanderAll").innerHTML = "<a href=\"javascript:expandAll(" + n + ")\">Expand all</a>";
}
  function expandAll(n)
{
  var i;
  for (i=0; i<=n; i++)
  {
    expand(i);
  }
  document.getElementById("expanderAll").innerHTML = "<a href=\"javascript:collapseAll(" + n + ")\">Collapse all</a>";
}
//end of expand collapse //

//validates a given value is numeric or not
function isNumeric( s ) {
	var myStr = s.replace( /(,|\.)/g, "" );
	if((s.indexOf("+")!=-1)||(s.indexOf(",")!=-1)){
		return (false);
	}else{
		return (!isNaN(myStr));
	}
}

//validates if a given value is decimal or not
function isDecimal( s ) {
	if(s.indexOf(".")!=-1){
		return true;
	}else{
		return false;
	}
}
