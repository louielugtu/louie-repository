var url = window.location.href;

var parentUrl = "";
var reqToken = url.substr(0, url.indexOf("?") + 1);
var optToken = url.substr(url.indexOf("?") + 1);
var delimiter = "&";

var appendString = "&vgnextrefresh=1";

//Script to define the callback handler for custom refresh functionality.
function doPostSubmit(JSName, JSCall) {
	if (eval(JSName)) eval(JSCall);
}

//Script to refresh the parent with new url for content create from detail page.
function refreshWithNewUrl(objectId, ObjectXML, isNewObject) {
	/* For FURL enabled sites,  the URL for the new content instance created cannot be formed on the client side alone.  Hence, a request is made to the server
	    where the link building happens for both FURL enabled and non-FURL enabled sites.  Earlier, for non-FURL enabled sites, the URL was being tokenized
	    and the new vgnextoid replaced n the URL by invoking the tokenize() function.  This function is no longer being used but not removed yet.
    */
	parentUrl = '/vgn-ext-templating-cma/secure/contentinstance/redirectToContentInstance.jsp';
	parentUrl += '?vgnextoid=' + objectId;
	addAdditionalRequestParameters();
	appendVgnExtRefresh();
	window.location.href = parentUrl;
}

// Function to extract all the request parameters and append them to the new URL
function addAdditionalRequestParameters() {
	var reqTokenTemp = reqToken;
	while (reqTokenTemp.length > 0) {
		if (reqTokenTemp.indexOf(delimiter) != -1) {
			pair = reqTokenTemp.substr(0, reqTokenTemp.indexOf(delimiter));
		} else {
			pair = reqTokenTemp;
		}
		var key = pair.substr(0, pair.indexOf("="));
		var value = pair.substr(pair.indexOf("=") + 1);

		if (key != '' && key != 'vgnextoid') {
			parentUrl += "&" + key;
			parentUrl += "=" + value;
		}
		reqTokenTemp = reqTokenTemp.substr(reqTokenTemp.indexOf(delimiter) + 1, reqTokenTemp.lenth - reqTokenTemp.indexOf(delimiter) + 1);
	}
}

// Script to build the new url.
function tokenize(optToken, delimiter, objectId) {
	keyArray = new Array();
	valueArray = new Array();
	var Count = 0;
	while (optToken.length > 0) {
		if (optToken.indexOf(delimiter) != -1) {
			pair = optToken.substr(0, optToken.indexOf(delimiter));
		} else {
			pair = optToken;
		}
		var key = pair.substr(0, pair.indexOf("="));
		var value = pair.substr(pair.indexOf("=") + 1);
		if (key == "vgnextoid") {
			value = objectId;
		}
		if (key != "vgnextchannel") {
			keyArray[Count] = key;
			valueArray[Count] = value;
			Count = Count + 1;
		}
		optToken = optToken.substr(optToken.indexOf(delimiter) + 1, optToken.lenth - optToken.indexOf(delimiter) + 1);
	}
	parentUrl = reqToken;
	for (var i = 0; i < keyArray.length; i++) {
		parentUrl = parentUrl + keyArray[i] + "=" + valueArray[i];
		if (i < keyArray.length - 1) {
			parentUrl = parentUrl + delimiter;
		}
	}
}

function isDefined(variable) {
	return (typeof(window[variable]) == "undefined")?  false: true;
}


//Script to refresh the parent for content create from query.
function refreshParent(objectId, ObjectXML, isNewObject) {
	//refer to refererURI in COE mode for the parent window url
	if (isDefined('refererURI')) {
		parentUrl = refererURI;
	} else {
		parentUrl = url;
	}

	appendVgnExtRefresh();
	window.location.href = parentUrl;
}

//Script to append the "&vgnextrefresh=1" to the url.
function appendVgnExtRefresh() {
	if (parentUrl.indexOf(appendString) == -1) {
		if (parentUrl.indexOf("?") == -1) {
			parentUrl = parentUrl + "?" + appendString.substr(1);
		} else {
			parentUrl = parentUrl + appendString;
		}
	}
}