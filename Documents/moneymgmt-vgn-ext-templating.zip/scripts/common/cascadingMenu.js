
var counter=new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

var timeout = 90;

function whenMouseOver(theDiv, i) { 
	showPopup(theDiv); 
	counter[i]++;
}

function whenMouseOut(theDiv, i) { 
	counter[i]++; 
	functionCall="whenTimeout('" + theDiv+ "', " + counter[i] + "," + i + ")";
	window.setTimeout(functionCall,timeout); 
}

function whenTimeout(theDiv, currCounterValue, currCounterIndex){	
	if(currCounterValue == counter[currCounterIndex])	
	hidePopup(theDiv);}
	
function showPopup(theDiv) {
	MM_changeProp(theDiv,'','style.visibility','visible');
}

function hidePopup(theDiv) {
	MM_changeProp(theDiv,'','style.visibility','hidden');
}
