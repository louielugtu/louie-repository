// When invoked by the content component COE's OK or Apply buttons,
// we need to tell our own opener, the parent COE, to refresh itself.
// Then we need to refresh ourselves by going back to the JSP that
// posted to this form.

var numChecksForOpenerRefreshComplete = 0;
var MAX_CHECKS_FOR_OPENER_REFRESH_COMPLETE = 50;
var CHECK_FOR_OPENER_REFRESH_PERIOD = 100;

// Called by the content component COE on OK or Apply
function submitCMD(command) {
	// Mark the last element rendered into the parent COE as dirty
	var elements = parent.opener.document.getElementsByName('VgnExtOpenerRefreshComplete');
	if (elements.length == 1) {
	    elements[0].value = 'dirty';
	}

	// Tell the parent COE to refresh
	parent.opener.submitCMD('refresh', true);

	// Wait for the parent COE to finish its refresh before our refresh
	checkForOpenerRefreshComplete();
}

// Checks for a well-known hidden form field rendered at the end of the page
function checkForOpenerRefreshComplete() {
	numChecksForOpenerRefreshComplete++;

	// Try to find the last element rendered into the parent COE and make sure it's been refreshed.
	var elements = parent.opener.document.getElementsByName('VgnExtOpenerRefreshComplete');
	if (((elements.length != 1) ||
	     (elements[0].value == 'dirty')) &&
	    (numChecksForOpenerRefreshComplete <= MAX_CHECKS_FOR_OPENER_REFRESH_COMPLETE)) {
		// Couldn't find it.  Do it again in a bit.
		setTimeout('checkForOpenerRefreshComplete()', CHECK_FOR_OPENER_REFRESH_PERIOD);
	} else {
		// Found it and it was refreshed.  Refresh this window now.
		refreshContents();
	}
}

// Reloads the previous URI which is what generated this page
function refreshContents() {
	// Return to the maker...
	window.location = refererURI;	
}
