package jsp_servlet._templates;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.util.Arrays;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import java.util.StringTokenizer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import java.io.*;
import com.vignette.ext.templating.util.RequestContext;
import com.vignette.ext.templating.util.PageUtil;
import com.vignette.ext.templating.link.LinkBuilder;
import com.vignette.ext.templating.util.RequestUtil;
import com.vignette.as.client.javabean.ContentInstance;
import com.vignette.ext.templating.client.javabean.Template;
import java.util.ArrayList;
import java.util.List;
import com.vignette.ext.templating.TemplatingConstants;

public final class __tablelayouttemplate extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/templates/tableLayoutTemplate.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "ISO-8859-1".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 ="\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    ";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="\n    ";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    private final static java.lang.String  _wl_block4 ="\n    <meta http-equiv=\"Content-Script-Type\" content=\"text/javascript\" />\n\t";
    private final static byte[]  _wl_block4Bytes = _getBytes( _wl_block4 );

    private final static java.lang.String  _wl_block5 ="\n\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"../scripts/ext-2.2/resources/css/ext-all.css\" />\n\t\t<script type=\"text/javascript\" src=\"../scripts/ext-2.2/adapter/ext/ext-base.js\"></script>\n\t\t<script type=\"text/javascript\" src=\"../scripts/ext-2.2/ext-all.js\"></script>\n\t";
    private final static byte[]  _wl_block5Bytes = _getBytes( _wl_block5 );

    private final static java.lang.String  _wl_block6 ="\n</head>\n<body style=\"margin:5px\" ";
    private final static byte[]  _wl_block6Bytes = _getBytes( _wl_block6 );

    private final static java.lang.String  _wl_block7 =" onkeypress=\"bodyKey(event)\" ";
    private final static byte[]  _wl_block7Bytes = _getBytes( _wl_block7 );

    private final static java.lang.String  _wl_block8 =" >\n\n";
    private final static byte[]  _wl_block8Bytes = _getBytes( _wl_block8 );

    private final static java.lang.String  _wl_block9 ="\n\n";
    private final static byte[]  _wl_block9Bytes = _getBytes( _wl_block9 );

    private final static java.lang.String  _wl_block10 ="\n\n<script type=\"text/javascript\">\n\tfunction inspectCheckboxes() {\n\t\tvar form = this.document.forms[\'main\'];\n\t\tvar selectionCount = 0;\n\t\tvar selectedElements = new Array();\n\t\tfor (var i=0; i<form.elements.length; i++) {\n\t\t\tif (form.elements[i].name == \'selection\') {\n\t\t\t\tif (form.elements[i].checked) {\n\t\t\t\t\tselectedElements[selectionCount] = form.elements[i];\n\t\t\t\t\tselectionCount++;\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t\t// Algorithm to see whether to disable merge/unmerge button\n\t\tvar enableUnmerge = selectionCount == 1\n\t\t\t\t&& (form.elements[\'rowspan\'+selectedElements[0].value].value > 1\n\t\t\t\t|| form.elements[\'colspan\'+selectedElements[0].value].value > 1);\n\t\tvar enableMerge = selectionCount > 1;\n\t\tif (enableMerge) {\n\t\t\tvar row0 = eval(selectedElements[0].value.substring(0, selectedElements[0].value.indexOf(\",\")));\n\t\t\tvar col0 = eval(selectedElements[0].value.substring(selectedElements[0].value.indexOf(\",\")+1));\n\t\t\tvar rowspan = 1;\n\t\t\tvar colspan = 1;\n\t\t\tvar selectedCellsCount = 0;\n\t\t\tfor (var i=0; i<selectedElements.length; i++) {\n\t\t\t\tvar rowi = eval(selectedElements[i].value.substring(0, selectedElements[i].value.indexOf(\",\")));\n\t\t\t\tvar coli = eval(selectedElements[i].value.substring(selectedElements[i].value.indexOf(\",\")+1));\n\t\t\t\tvar rowspani = eval(form.elements[\'rowspan\'+selectedElements[i].value].value);\n\t\t\t\tvar colspani = eval(form.elements[\'colspan\'+selectedElements[i].value].value);\n\t\t\t\tenableMerge &= rowi >= row0 && coli >= col0;\n\t\t\t\trowspan = Math.max(rowspan, rowi - row0 + rowspani);\n\t\t\t\tcolspan = Math.max(colspan, coli - col0 + colspani);\n\t\t\t\tselectedCellsCount += rowspani * colspani;\n\t\t\t}\n\t\t\tenableMerge &= (rowspan * colspan) == selectedCellsCount;\n\t\t}\n\t\tvar mergeButton = tableToolkitWindow.buttons[0];\n\t\tvar unmergeButton = tableToolkitWindow.buttons[1];\n\t\tif (enableUnmerge) unmergeButton.enable(); else unmergeButton.disable();\n\t\tif (enableMerge) mergeButton.enable(); else mergeButton.disable();\n\t}\n\tvar selecting=false, selected=false, mouseStartX, mouseStartY, mouseEndX, mouseEndY, cellStartIJ, cellEndIJ, currcellij;\n\tfunction cellMouseMove(cell) {\n\t\tvar ij = cell.id.substring(5);\n\t\tcurrcellij = ij;\n\t\tif (selecting) {\n\t\t\tmouseEndX = Ext.EventObject.getPageX();\n\t\t\tmouseEndY = Ext.EventObject.getPageY();\n\t\t\tcellEndIJ = ij;\n\t\t\tredrawTableGrid();\n\t\t} else {\n\t\t\tshowTableGrid();\n\t\t}\n\t\treturn false;\n\t}\n\tfunction cellMouseDown(cell) {\n\t\tif (isEditingRegionName) return false;\n\t\tvar ij = cell.id.substring(5);\n\t\tif (!selecting) {\n\t\t\tselecting = true;\n\t\t\tselected = true;\n\t\t\tmouseStartX = Ext.EventObject.getPageX();\n\t\t\tmouseStartY = Ext.EventObject.getPageY();\n\t\t\tmouseEndX = Ext.EventObject.getPageX();\n\t\t\tmouseEndY = Ext.EventObject.getPageY();\n\t\t\tcellStartIJ = ij;\n\t\t\tcellEndIJ = ij;\n\t\t}\n\t\tredrawTableGrid();\n\t\treturn false;\n\t}\n\tfunction cellMouseUp(cell) {\n\t\tvar ij = cell.id.substring(5);\n\t\tselecting = false;\n\t\tselected = true;\n\t\tmouseEndX = Ext.EventObject.getPageX();\n\t\tmouseEndY = Ext.EventObject.getPageY();\n\t\tcellEndIJ = ij;\n\t\tredrawTableGrid();\n\t\treturn false;\n\t}\n\tfunction cellMouseOut(cell) {\n\t\tcurrcellij = \"\";\n\t\tshowTableGrid();\n\t\treturn false;\n\t}\n\tfunction bodyKey(e) {\n\t\tif (e.keyCode == 27) {  // Escape key pressed\n\t\t\tcancelSelecting();\n\t\t}\n\t\treturn false;\n\t}\n\tfunction cancelSelecting() {\n\t\tselecting = false;\n\t\tselected = false;\n\t\tredrawTableGrid();\n\t}\n\tfunction showRuler() {\n\t\tvar form = this.document.forms[\'main\'];\n\t\tvar hideRuler = form.elements[\'hideRuler\'].checked;\n\t\tvar ruler = document.getElementById(\'ruler\');\n\t\tif (hideRuler) {\n\t\t\truler.style.visibility = \'hidden\';\n\t\t} else {\n\t\t\truler.style.visibility = \'visible\';\n\t\t}\n\t}\n\tfunction showTableGrid() {\n\t\tvar form = this.document.forms[\'main\'];\n\t\tvar hideGrid = form.elements[\'hideGrid\'].checked;\n\t\tfor (var i=0; i<form.elements.length; i++) {\n\t\t\tif (form.elements[i].name == \'selection\') {\n\t\t\t\tvar ij = form.elements[i].value;\n\t\t\t\tvar cell = document.getElementById(\"region\"+ij);\n\t\t\t\tvar selection = document.getElementById(\"selection\"+ij);\n\t\t\t\tif (!selecting && !selected) selection.checked = false;\n\t\t\t\tvar border = \"solid transparent 1px\";\n\t\t\t\tvar regionName = document.getElementById(\"RegionName\"+ij);\n\t\t\t\tvar region = Ext.fly(\"region\"+ij);\n\t\t\t\tvar showRegionName = false;\n\t\t\t\tif (!hideGrid || isEditingRegionName) {\n\t\t\t\t\tborder = \"dotted green 1px\";\n\t\t\t\t\tshowRegionName = true;\n\t\t\t\t}\n\t\t\t\tif (selection.checked) {\n\t\t\t\t\tborder = \"solid red 1px\";\n\t\t\t\t\tshowRegionName = true;\n\t\t\t\t} else if (currcellij == ij) {\n\t\t\t\t\tborder = \"dotted red 1px\";\n\t\t\t\t\tshowRegionName = true;\n\t\t\t\t}\n\t\t\t\tif (showRegionName || isEditingRegionName) {\n\t\t\t\t\tregionName.style.top = region.getY();\n\t\t\t\t\tregionName.style.left = region.getX();\n\t\t\t\t\tregionName.style.visibility = \'visible\';\n\t\t\t\t} else {\n\t\t\t\t\tregionName.style.visibility = \'hidden\';\n\t\t\t\t}\n\t\t\t\tcell.style.border = border;\n\t\t\t}\n\t\t}\n\t}\n\tfunction redrawTableGrid() {\n\t\tshowTableGrid();\n\t\tvar msr = document.getElementById(\'mouseSelectRegion\');\n\t\tif (selecting) {\n\t\t\tvar sx = Math.min(mouseStartX, mouseEndX);\n\t\t\tvar sy = Math.min(mouseStartY, mouseEndY);\n\t\t\tvar ex = Math.max(mouseStartX, mouseEndX);\n\t\t\tvar ey = Math.max(mouseStartY, mouseEndY);\n\t\t\tmsr.style.top = sy + \"px\";\n\t\t\tmsr.style.left = sx + \"px\";\n\t\t\tmsr.style.width = (ex-sx) + \"px\";\n\t\t\tmsr.style.height = (ey-sy) + \"px\";\n\t\t\tmsr.style.visibility = \'visible\';\n\n\t\t\tvar formElements = document.forms[\'main\'].elements;\n\t\t\tvar i, j, region, psx, psy, pex, pey, sel, cellElement, formElement;\n\t\t\tfor (var fe=0; fe<formElements.length; fe++) {\n\t\t\t\tformElement = formElements[fe];\n\t\t\t\tif (formElement.name == \'selection\') {\n\t\t\t\t\ti = eval(formElement.value.substring(0, formElement.value.indexOf(\",\")));\n\t\t\t\t\tj = eval(formElement.value.substring(formElement.value.indexOf(\",\")+1));\n\t\t\t\t\tregion = Ext.fly(\'region\'+i+\',\'+j);\n\t\t\t\t\tpsx = region.getX();\n\t\t\t\t\tpsy = region.getY();\n\t\t\t\t\tpex = psx + region.getWidth();\n\t\t\t\t\tpey = psy + region.getHeight();\n\t\t\t\t\tsel = (psx >= sx && psx <= ex || pex >= sx && pex <= ex ||\n\t\t                   sx >= psx && sx <= pex || ex >= psx && ex <= pex ) &&\n\t\t\t\t\t      (psy >= sy && psy <= ey || pey >= sy && pey <= ey ||\n\t\t                   sy >= psy && sy <= pey || ey >= psy && ey <= pey);\n\n\t\t\t\t\tif (sel) {\n\t\t\t\t\t\tcellElement = document.getElementById(\'region\'+i+\',\'+j);\n\t\t\t\t\t\tcellElement.style.border = \'solid red 1px\';\n\t\t\t\t\t\tformElement.checked = true;\n\t\t\t\t\t} else {\n\t\t\t\t\t\tformElement.checked = false;\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\n\t\t} else {\n\t\t\tmsr.style.visibility = \'hidden\';\n\t\t}\n\t\tinspectCheckboxes();\n\t}\n\tfunction getDivContentAndClear(divName){\n\t\tvar dom = Ext.fly(\'_\'+divName).dom;\n\t\tvar s = dom.innerHTML;\n\t\tdom.innerHTML = \"\";\n\t\treturn \'<div id=\\\"\'+divName+\'\\\" style=\\\"width:100%;cursor:auto;\\\">\'+s+\'</div>\';\n\t}\n\tvar isEditingRegionName = false;\n\tfunction beginEditRegionName(regionNameDiv) {\n\t\tif (!isEditingRegionName) {\n\t\t\tisEditingRegionName = true;\n\t\t\tvar value = regionNameDiv.innerHTML;\n\t\t\tregionNameDiv.innerHTML = \'<input id=\"regionNameEditor\" onkeypress=\"if(event.keyCode==13||event.keyCode==10||event.keyCode==27)endEditRegionName(document.getElementById(\\\'\'+regionNameDiv.id+\'\\\'))\" onblur=\"endEditRegionName(document.getElementById(\\\'\'+regionNameDiv.id+\'\\\'))\" value=\"\'+value+\'\" style=\"border:solid black 1px;font-weight:bold;font-size:8pt;\">\';\n\t\t\tdocument.getElementById(\'regionNameEditor\').select();\n\t\t\tcancelSelecting();\n\t\t}\n\t}\n\tfunction endEditRegionName(regionNameDiv) {\n\t\tvar editor = document.getElementById(\'regionNameEditor\');\n\t\tvar regionName = editor.value;\n\t\tregionNameDiv.innerHTML = regionName;\n\t\tisEditingRegionName = false;\n\t\tvar ij = regionNameDiv.id.substring(10);\n\t\tvar form = document.forms[\'main\'];\n\t\tform.elements[\'name\'+ij].value = regionName;\n\t\tform.action.value = \'update\';\n\t\tsubmitMainForm();\n\t}\n\tfunction submitMainForm() {\n\t\tvar form = document.forms[\'main\'];\n\t\tform.x.value = tableToolkitWindow.x;\n\t\tform.y.value = tableToolkitWindow.y;\n\t\tvar colNum=0;\n\t\tfor (var i=0; i<form.elements.length; i++) {\n\t\t\tvar el = form.elements[i];\n\t\t\tif (el.name == \'width\') {\n\t\t\t\tel.value = document.getElementById(\'width\'+colNum).value;\n\t\t\t\tcolNum++;\n\t\t\t}\n\t\t}\n\t\tform.submit();\n\t}\n\tvar tableToolkitWindow;\n\tvExt.onReady(function(){\n\t\ttableToolkitWindow = new vExt.Window({\n\t\t\tapplyTo: \'table-toolkit-win\',\n\t\t\tlayout: \'fit\',\n\t\t\twidth: 450,\n\t\t\theight: 100,\n\t\t\tplain: true,\n\t\t\tclosable: false,\n\t\t\titems: new Ext.Panel({\n\t\t\t\tapplyTo: \'table-toolkit-tab\',\n\t\t\t\tautoTabs: true,\n\t\t\t\tactiveTab: 0,\n\t\t\t\tdeferredRender: false,\n\t\t\t\tborder: false\n\t\t\t}),\n\t\t\tbuttons: [{\n\t\t\t\tid: \'MergeButton\',\n\t\t\t\ttext: \'Merge\',\n\t\t\t\tdisabled: true,\n\t\t\t\thandler: function() {\n\t\t\t\t\tvar form = document.forms[\'main\'];\n\t\t\t\t\tform.action.value=\'merge\';\n\t\t\t\t\tsubmitMainForm();\n\t\t\t\t}\n\t\t\t},{\n\t\t\t\tid: \'UnmergeButton\',\n\t\t\t\ttext: \'Unmerge\',\n\t\t\t\tdisabled: true,\n\t\t\t\thandler: function() {\n\t\t\t\t\tvar form = document.forms[\'main\'];\n\t\t\t\t\tform.action.value=\'unmerge\';\n\t\t\t\t\tsubmitMainForm();\n\t\t\t\t}\n\t\t\t},{\n\t\t\t\ttext: \'Update\',\n\t\t\t\thandler: function() {\n\t\t\t\t\tvar form = document.forms[\'main\'];\n\t\t\t\t\tform.action.value=\'update\';\n\t\t\t\t\tsubmitMainForm();\n\t\t\t\t}\n\t\t\t},{\n\t\t\t\ttext: \'New\',\n\t\t\t\thandler: function() {\n\t\t\t\t\tvar form = document.forms[\'main\'];\n\t\t\t\t\tform.action.value=\'new\';\n\t\t\t\t\tsubmitMainForm();\n\t\t\t\t}\n\t\t\t},{\n\t\t\t\ttext: \'Save\',\n\t\t\t\thandler: function() {\n\t\t\t\t\tvar form = document.forms[\'main\'];\n\t\t\t\t\tform.action.value=\'save\';\n\t\t\t\t\tsubmitMainForm();\n\t\t\t\t}\n\t\t\t}]\n\t\t});\n\t\t";
    private final static byte[]  _wl_block10Bytes = _getBytes( _wl_block10 );

    private final static java.lang.String  _wl_block11 ="\n\t\ttableToolkitWindow.setPosition(";
    private final static byte[]  _wl_block11Bytes = _getBytes( _wl_block11 );

    private final static java.lang.String  _wl_block12 =",";
    private final static byte[]  _wl_block12Bytes = _getBytes( _wl_block12 );

    private final static java.lang.String  _wl_block13 =");\n\t\t";
    private final static byte[]  _wl_block13Bytes = _getBytes( _wl_block13 );

    private final static java.lang.String  _wl_block14 ="\n\t\ttableToolkitWindow.show();\n\t\tredrawTableGrid();\n\t\tinspectCheckboxes();\n\t\tshowRuler();\n\t\t";
    private final static byte[]  _wl_block14Bytes = _getBytes( _wl_block14 );

    private final static java.lang.String  _wl_block15 ="\n\t\tExt.Ajax.request({\n\t\t\turl: \'../../vgn-ext-templating-cma/secure/template/savePageLayout.jsp\',\n\t\t\tsuccess: function() {},\n\t\t\tfailure: function() {},\n\t\t\tparams: {\n\t\t\t\tlayoutData: document.forms[\'main\'].elements[\'xmlData\'].value,\n\t\t\t\tvgnextoid: \'";
    private final static byte[]  _wl_block15Bytes = _getBytes( _wl_block15 );

    private final static java.lang.String  _wl_block16 ="\'\n\t\t\t}\n\t\t});\n\t\t";
    private final static byte[]  _wl_block16Bytes = _getBytes( _wl_block16 );

    private final static java.lang.String  _wl_block17 ="\n\t});\n\tvExt.EventManager.onWindowResize(function(){\n\t\tredrawTableGrid();\n\t});\n</script>\n<div id=\"mouseSelectRegion\" style=\"position:absolute;visibility:hidden;border:dotted red 2px;background:pink;opacity:.25;filter:alpha(opacity=25);vertical-align:middle;text-align:center;\"></div>\n<table id=\"ruler\" style=\"position:absolute;visibility:hidden;opacity:.5;filter:alpha(opacity=50);top:0px;left:0px;";
    private final static byte[]  _wl_block17Bytes = _getBytes( _wl_block17 );

    private final static java.lang.String  _wl_block18 ="\">\n\t<tr>\n";
    private final static byte[]  _wl_block18Bytes = _getBytes( _wl_block18 );

    private final static java.lang.String  _wl_block19 ="\n\t\t<td id=\"rulerSection";
    private final static byte[]  _wl_block19Bytes = _getBytes( _wl_block19 );

    private final static java.lang.String  _wl_block20 ="\" style=\"text-align:center;width:";
    private final static byte[]  _wl_block20Bytes = _getBytes( _wl_block20 );

    private final static java.lang.String  _wl_block21 =";vertical-align:top;font-size:8pt;min-width:100px;\" class=\"x-form-field\">\n\t\t\t<input type=\"text\" id=\"width";
    private final static byte[]  _wl_block21Bytes = _getBytes( _wl_block21 );

    private final static java.lang.String  _wl_block22 ="\" value=\"";
    private final static byte[]  _wl_block22Bytes = _getBytes( _wl_block22 );

    private final static java.lang.String  _wl_block23 ="\" size=\"2\"\n\t\t\t       style=\"border:solid black 1px;font-size:8pt;font-weight:bold;background:gray;color:white;text-align:center;\"\n\t\t\t       onfocus=\"document.getElementById(\'ruler\').style.opacity=1;document.getElementById(\'ruler\').style.filter=\'alpha(opacity=100)\';this.style.background=\'white\';this.style.color=\'black\';\"\n\t\t\t       onblur=\"document.getElementById(\'ruler\').style.opacity=.5;document.getElementById(\'ruler\').style.filter=\'alpha(opacity=50)\';this.style.background=\'gray\';this.style.color=\'white\';\"\n\t\t\t       onkeypress=\"if(event.keyCode==13||event.keyCode==10){document.forms[\'main\'].action.value=\'update\';submitMainForm();};if(event.keyCode==27)this.blur();\"> ";
    private final static byte[]  _wl_block23Bytes = _getBytes( _wl_block23 );

    private final static java.lang.String  _wl_block24 ="\n\t\t</td>\n";
    private final static byte[]  _wl_block24Bytes = _getBytes( _wl_block24 );

    private final static java.lang.String  _wl_block25 ="\n\t</tr>\n</table>\n<div id=\"table-toolkit-win\" class=\"x-hidden\">\n\t<div class=\"x-window-header\">Table Editor</div>\n\t<div id=\"table-toolkit-tab\" class=\"x-box\">\n\t\t<form action=\"\" method=\"post\" name=\"main\">\n\t\t\t<input type=\"hidden\" name=\"x\" value=\"\">\n\t\t\t<input type=\"hidden\" name=\"y\" value=\"\">\n\t\t\t<input type=\"hidden\" name=\"action\" value=\"\">\n\t\t\tRows:\n\t\t\t<select name=\"row\" onchange=\"action.value=\'setRowCol\';submitMainForm()\" class=\"x-combo-list\">\n\t\t\t\t";
    private final static byte[]  _wl_block25Bytes = _getBytes( _wl_block25 );

    private final static java.lang.String  _wl_block26 ="\n\t\t\t</select>\n\t\t\tCols:\n\t\t\t<select name=\"col\" onchange=\"action.value=\'setRowCol\';submitMainForm()\" class=\"x-combo-list\">\n\t\t\t\t";
    private final static byte[]  _wl_block26Bytes = _getBytes( _wl_block26 );

    private final static java.lang.String  _wl_block27 ="\n\t\t\t</select>\n\t\t\t<input type=\"checkbox\" name=\"relativeWidths\" value=\"true\" ";
    private final static byte[]  _wl_block27Bytes = _getBytes( _wl_block27 );

    private final static java.lang.String  _wl_block28 =" onchange=\"action.value=\'setRelativeWidths\';submitMainForm()\" id=\"relativeWidths\"><label for=\"relativeWidths\"> Use % Widths</label>\n\t\t\t<input type=\"checkbox\" id=\"hideGrid\" name=\"hideGrid\" value=\"Hide Grid\" onclick=\"showTableGrid();\" ";
    private final static byte[]  _wl_block28Bytes = _getBytes( _wl_block28 );

    private final static java.lang.String  _wl_block29 ="> <label for=\"hideGrid\"> Hide Grid</label>\n\t\t\t<input type=\"checkbox\" id=\"hideRuler\" name=\"hideRuler\" value=\"Hide Ruler\" onclick=\"showRuler();\" ";
    private final static byte[]  _wl_block29Bytes = _getBytes( _wl_block29 );

    private final static java.lang.String  _wl_block30 ="> <label for=\"hideRuler\"> Hide Ruler</label>\n\t\t\t\t\t\t<br/>\n\t\t\t";
    private final static byte[]  _wl_block30Bytes = _getBytes( _wl_block30 );

    private final static java.lang.String  _wl_block31 ="\n\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"width\" value=\"";
    private final static byte[]  _wl_block31Bytes = _getBytes( _wl_block31 );

    private final static java.lang.String  _wl_block32 ="\" size=\"2\" style=\"visibility:hidden;\">\n\t\t\t";
    private final static byte[]  _wl_block32Bytes = _getBytes( _wl_block32 );

    private final static java.lang.String  _wl_block33 ="\n\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"rowspan";
    private final static byte[]  _wl_block33Bytes = _getBytes( _wl_block33 );

    private final static java.lang.String  _wl_block34 ="\">\n\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"colspan";
    private final static byte[]  _wl_block34Bytes = _getBytes( _wl_block34 );

    private final static java.lang.String  _wl_block35 ="\">\n\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"selection\" value=\"";
    private final static byte[]  _wl_block35Bytes = _getBytes( _wl_block35 );

    private final static java.lang.String  _wl_block36 ="\" onchange=\"inspectCheckboxes()\" id=\"selection";
    private final static byte[]  _wl_block36Bytes = _getBytes( _wl_block36 );

    private final static java.lang.String  _wl_block37 ="\" style=\"visibility:hidden;\">\n\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"name";
    private final static byte[]  _wl_block37Bytes = _getBytes( _wl_block37 );

    private final static java.lang.String  _wl_block38 ="\">\n\t\t\t\t\t\t\t\t\t\t<textarea rows=\"1\" cols=\"10\" name=\"style";
    private final static byte[]  _wl_block38Bytes = _getBytes( _wl_block38 );

    private final static java.lang.String  _wl_block39 ="\" style=\"visibility:hidden;\">";
    private final static byte[]  _wl_block39Bytes = _getBytes( _wl_block39 );

    private final static java.lang.String  _wl_block40 ="</textarea>\n\t\t\t";
    private final static byte[]  _wl_block40Bytes = _getBytes( _wl_block40 );

    private final static java.lang.String  _wl_block41 ="\n\t\t\t\t\t\t<textarea name=\"xmlData\" style=\"visibility:hidden;\">";
    private final static byte[]  _wl_block41Bytes = _getBytes( _wl_block41 );

    private final static java.lang.String  _wl_block42 ="</textarea>\n\t\t\t\t\t\t<input type=\"button\" name=\"load\" value=\"Load\" onclick=\"action.value=\'load\';submitMainForm()\" style=\"visibility:hidden;\">\n\t\t</form>\n\t</div>\n</div>\n\n";
    private final static byte[]  _wl_block42Bytes = _getBytes( _wl_block42 );

    private final static java.lang.String  _wl_block43 ="\n\t\t\t<div id=\"RegionName";
    private final static byte[]  _wl_block43Bytes = _getBytes( _wl_block43 );

    private final static java.lang.String  _wl_block44 ="\"\n\t\t\t\t onclick=\"beginEditRegionName(this)\"\n\t\t\t     style=\"position:absolute;visibility:hidden;opacity:.75;filter:alpha(opacity=75);background:gray;color:white;text-align:left;padding:2px;font-size:7pt;font-family:Verdana, Arial, Helvetica, sans-serif;font-style:normal;font-weight:bold;opacity:.5;filter:alpha(opacity=50);\">";
    private final static byte[]  _wl_block44Bytes = _getBytes( _wl_block44 );

    private final static java.lang.String  _wl_block45 ="</div>\n";
    private final static byte[]  _wl_block45Bytes = _getBytes( _wl_block45 );

    private final static java.lang.String  _wl_block46 ="\n\n<!-- BEGIN Render Table -->\n<table style=\"";
    private final static byte[]  _wl_block46Bytes = _getBytes( _wl_block46 );

    private final static java.lang.String  _wl_block47 ="\n\t\t<tr style=\"min-height:100px\">\n";
    private final static byte[]  _wl_block47Bytes = _getBytes( _wl_block47 );

    private final static java.lang.String  _wl_block48 ="\n\t\t\t<td id=\"region";
    private final static byte[]  _wl_block48Bytes = _getBytes( _wl_block48 );

    private final static java.lang.String  _wl_block49 ="\"\n\t\t\t    colspan=\"";
    private final static byte[]  _wl_block49Bytes = _getBytes( _wl_block49 );

    private final static java.lang.String  _wl_block50 ="\" rowspan=\"";
    private final static byte[]  _wl_block50Bytes = _getBytes( _wl_block50 );

    private final static java.lang.String  _wl_block51 ="\"\n\t\t\t\twidth=\"";
    private final static byte[]  _wl_block51Bytes = _getBytes( _wl_block51 );

    private final static java.lang.String  _wl_block52 ="\"\n\t\t\t\t";
    private final static byte[]  _wl_block52Bytes = _getBytes( _wl_block52 );

    private final static java.lang.String  _wl_block53 ="\n\t\t\t\t\tonmousemove=\"return cellMouseMove(this);\"\n\t\t\t\t\tonmouseout=\"return cellMouseOut(this);\"\n\t\t\t\t\tonmousedown=\"return cellMouseDown(this);\"\n\t\t\t\t\tonmouseup=\"return cellMouseUp(this);\"\n\t\t\t\t\tonkeypress=\"return bodyKey(event);\"\n\t\t\t\t";
    private final static byte[]  _wl_block53Bytes = _getBytes( _wl_block53 );

    private final static java.lang.String  _wl_block54 ="\n\t\t\t\tstyle=\"border:solid transparent 1px;height:100px;min-width:100px;";
    private final static byte[]  _wl_block54Bytes = _getBytes( _wl_block54 );

    private final static java.lang.String  _wl_block55 ="\">\n\n\t\t\t\t";
    private final static byte[]  _wl_block55Bytes = _getBytes( _wl_block55 );

    private final static java.lang.String  _wl_block56 ="\n\n\t\t\t</td>\n";
    private final static byte[]  _wl_block56Bytes = _getBytes( _wl_block56 );

    private final static java.lang.String  _wl_block57 ="\n\t</tr>\n";
    private final static byte[]  _wl_block57Bytes = _getBytes( _wl_block57 );

    private final static java.lang.String  _wl_block58 ="\n</table>\n<!-- END Render Table -->\n</body>\n</html>\n";
    private final static byte[]  _wl_block58Bytes = _getBytes( _wl_block58 );

    /**
     * Splits the given string into an array of substrings at
     * the given set of character delimiters.
     *
     * For instance, split("a/b\c/d\baby/whee", "/\") returns
     * an array with elements "a", "b", "c", "d", "baby", "whee".
     */
    public static String[] split(String string, String delimiter) {
        List<String> strings = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer(string, delimiter);
        while (st.hasMoreTokens()) {
            strings.add(st.nextToken());
        }
        String[] items = new String[strings.size()];
        strings.toArray(items);
        return items;
    }

    public static class ModelData implements Serializable, Cloneable {

		private static final long serialVersionUID = 1L;

        public static final int LAYOUT_TYPE_NESTED_TABLE = 0;
        public static final int LAYOUT_TYPE_SINGLE_TABLE = 1;

        protected int layoutType = LAYOUT_TYPE_NESTED_TABLE;
		protected boolean verticallyOriented;
		protected boolean useRelativeWidths;
		protected int defaultCellWidth = 100;

		protected int[] dividerWidths;
		protected int[][] cellWidths;
		protected String[][] cellNames;
	    protected String[][] styles;
		protected int[][] maxModuleWidths;
		protected int[][] colspans;
		protected int[][] rowspans;

		/**
		 * Default constructor will initialize ModelData with default values.
		 */
		public ModelData() {
			this(LAYOUT_TYPE_NESTED_TABLE, true, true, 3, 3);
		}

		/**
		 * Constructor that takes layout type, orientation, and # of dividers (assuming # of regions = 1)
		 * @param layoutType
		 * @param verticallyOriented
		 * @param numDividers
		 */
		public ModelData(int layoutType, boolean verticallyOriented, boolean useRelativeWidths, int numDividers, int numCell) {
			this.layoutType = layoutType;
			this.verticallyOriented = verticallyOriented;
			this.useRelativeWidths = useRelativeWidths;

			// use a default of two dividers with one cell each.
			int[] numCells = new int[numDividers];
			for (int i=0; i<numDividers; i++) {
				numCells[i] = numCell;
			}

			// make the divider widths equal initially
			dividerWidths = new int[numCells.length];
			int divWidth = Math.round((float)100 / numCells.length);
			int remaining = 100;
			for (int i = 0; i < numCells.length - 1; ++i) {
				dividerWidths[i] = divWidth;
				remaining -= divWidth;
			}
			dividerWidths[dividerWidths.length - 1] = remaining;

			// same for cell widths.  make cell names while we're at it.
			cellWidths = new int[numCells.length][];
			cellNames = new String[numCells.length][];
			styles = new String[numCells.length][];
			maxModuleWidths = new int[numCells.length][];
			colspans = new int[numCells.length][];
			rowspans = new int[numCells.length][];

			for (int i = 0; i < numCells.length; ++i) {
				int cellCount = numCells[i];
				cellWidths[i] = new int[cellCount];
				cellNames[i] = new String[cellCount];
				styles[i] = new String[cellCount];
				maxModuleWidths[i] = new int[cellCount];
				colspans[i] = new int[cellCount];
				rowspans[i] = new int[cellCount];
				int cellWidth = Math.round((float)100 / cellCount);
				remaining = 100;
				for (int j = 0; j < cellCount; ++j) {
					if (j == cellCount - 1) {
						cellWidths[i][cellCount - 1] = remaining;
					} else {
						cellWidths[i][j] = cellWidth;
						remaining -= cellWidth;
					}
					cellNames[i][j] = makeCellName(i, j);
					styles[i][j] = "";
					maxModuleWidths[i][j] = 0;
					colspans[i][j] = 1; // default value is 1
					rowspans[i][j] = 1; // default value is 1
				}
			}
		}

		/**
		 * @return layoutType (int constants from PageLayout.LAYOUT_TYPE_*)
		 */
		public int getLayoutType() {
			return layoutType;
		}

		/**
		 * Sets the LayoutType
		 * @param layoutType the int constants from PageLayout.LAYOUT_TYPE_*
		 */
		public void setLayoutType(int layoutType) {
			this.layoutType = layoutType;
			normalizeWidths();
		}

		public boolean isVerticallyOriented() {
			return verticallyOriented;
		}

		public void setVerticallyOriented(boolean verticallyOriented) {
			this.verticallyOriented = verticallyOriented;
		}

		public boolean isUseRelativeWidths() {
			return useRelativeWidths;
		}

		/**
		 * Sets whether divider and cell widths are specified as
		 * relative or absolute.
		 *
		 * Note that calling this method with isRelative = true will
		 * have the side effect of invoking <code>normalizeWidths()</code>
		 * to ensure layout consistency.
		 *
		 * @param isRelative <code>true</code> to use percentage widths,
		 * <code>false</code> to use absolute pixel widths
		 */
		public void setUseRelativeWidths(boolean isRelative) {
			useRelativeWidths = isRelative;
			normalizeWidths();
		}

		/**
		 * Normalize the widths of dividers and cells.
		 *
		 * <li> In case of NESTED_TABLE w/ relative widths,
		 *      all widths should add up to 100%.
		 * <li> In case of SINGLE_TABLE, all widths should be
		 *      recalculated according to the getTableColumnWidths() array.
		 */
		public void normalizeWidths() {
			if (useRelativeWidths) {
				dividerWidths = absToPct(dividerWidths);
				for (int i = 0; i < dividerWidths.length; ++i) {
					cellWidths[i] = absToPct(cellWidths[i]);
				}
			}
		}

		public int getDefaultCellWidth() {
			return defaultCellWidth;
		}

		public void setDefaultCellWidth(int defaultCellWidth) {
			this.defaultCellWidth = defaultCellWidth;
		}

		public int[] getDividerWidths() {
			return dividerWidths;
		}

		public void setDividerWidths(int[] dividerWidths) {
			this.dividerWidths = dividerWidths;
		}

		public int[][] getCellWidths() {
			return cellWidths;
		}

		public void setCellWidths(int[][] cellWidths) {
			this.cellWidths = cellWidths;
		}

		public String[][] getCellNames() {
			return cellNames;
		}

		public void setCellNames(String[][] cellNames) {
			this.cellNames = cellNames;
		}

	    public String[][] getStyles() {
		    return styles;
	    }

	    public void setStyles(String[][] styles) {
		    this.styles = styles;
	    }

		public int[][] getMaxModuleWidths() {
			return maxModuleWidths;
		}

		public int[][] getColSpans() {
			return colspans;
		}

		public int[][] getRowSpans() {
			return rowspans;
		}

		public void setMaxModuleWidths(int[][] maxModuleWidths) {
			this.maxModuleWidths = maxModuleWidths;
		}

		public int getDividerCount() {
			return cellNames.length;
		}

		public void setColSpans(int[][] colspans) {
			this.colspans = colspans;
		}

		public void setRowSpans(int[][] rowspans) {
			this.rowspans = rowspans;
		}

		public int getCellCount(int dividerIndex) {
			return divOutOfRange(dividerIndex) ? 0 : cellNames[dividerIndex].length;
		}

		public int getDividerWidth(int dividerIndex) {
			return divOutOfRange(dividerIndex) ? 0 : dividerWidths[dividerIndex];
		}

		public int getCellWidth(int dividerIndex, int cellIndex) {
			return cellOutOfRange(dividerIndex, cellIndex) ? 0 : cellWidths[dividerIndex][cellIndex];
		}

		public int getMaxModuleWidth(int dividerIndex, int cellIndex) {
			return cellOutOfRange(dividerIndex, cellIndex) ? 0 : maxModuleWidths[dividerIndex][cellIndex];
		}

		public int getColSpan(int dividerIndex, int cellIndex) {
			return cellOutOfRange(dividerIndex, cellIndex) ? 0 : colspans[dividerIndex][cellIndex];
		}

		public int getRowSpan(int dividerIndex, int cellIndex) {
			return cellOutOfRange(dividerIndex, cellIndex) ? 0 : rowspans[dividerIndex][cellIndex];
		}

		public String getCellName(int dividerIndex, int cellIndex) {
			return cellOutOfRange(dividerIndex, cellIndex) ? null : cellNames[dividerIndex][cellIndex];
		}

	    public String getStyle(int dividerIndex, int cellIndex) {
		    return cellOutOfRange(dividerIndex, cellIndex) ? null : styles[dividerIndex][cellIndex];
	    }

		public int getTableColumnCount() {
			return getCellCount(0);
		}

		public int getTableRowCount() {
			int count = 0;
			if (layoutType == LAYOUT_TYPE_SINGLE_TABLE
					&& rowspans != null) {
				count = rowspans.length;
			}
			return count;
		}

		/**
		 * Performs checking on whether this model is valid
		 * @return
		 */
		public boolean isValid() {
			boolean valid = true;
			// common tests
			valid &= cellNames != null && cellNames.length > 0;
			valid &= cellNames.length == styles.length;
			valid &= cellNames.length == dividerWidths.length;
			valid &= cellNames.length == cellWidths.length;
			valid &= cellNames.length == maxModuleWidths.length;
			valid &= cellNames.length == colspans.length;
			valid &= cellNames.length == rowspans.length;
			for (int i=0; valid && i<cellNames.length; i++) {
				valid &= cellWidths[i] != null && cellWidths[i].length > 0;
				valid &= cellWidths[i].length == styles[i].length;
				valid &= cellWidths[i].length == maxModuleWidths[i].length;
				valid &= cellWidths[i].length == colspans[i].length;
				valid &= cellWidths[i].length == rowspans[i].length;
			}

			switch (layoutType) {
				case LAYOUT_TYPE_NESTED_TABLE:
					if (useRelativeWidths) { // all widths must add up to 100%
						if (verticallyOriented) { // column oriented
							int totalWidth = 0;
							for (int dividerWidth : dividerWidths) {
								totalWidth += dividerWidth;
							}
							valid &= totalWidth == 100;
						} else { // row oriented
							for (int[] cellWidth : cellWidths) {
								int totalWidth = 0;
								for (int cw : cellWidth) {
									totalWidth += cw;
								}
								valid &= totalWidth == 100;
							}
						}
					}
					break;
				case LAYOUT_TYPE_SINGLE_TABLE:
					// see if the spans & widths are valid
					int numCols = getTableColumnCount();
					int numRows = getTableRowCount();
					valid &= colspans.length == numRows;
					valid &= rowspans.length == numRows;
					valid &= cellWidths.length == numCols;
					for (int i=0; valid && i<colspans.length; i++) {
						valid &= colspans[i].length == numCols;
						valid &= rowspans[i].length == numCols;
						valid &= cellWidths[i].length == numRows;
						int rowWidth = 0;
						for (int j=0; valid && j<colspans[i].length; j++) {
							valid &= (colspans[i][j] > 0 && rowspans[i][j] > 0)
									|| (colspans[i][j] < 1  && rowspans[i][j] < 1);
							if (valid && colspans[i][j] > 0 && rowspans[i][j] > 0) {
								for (int ii=1; valid && ii < rowspans[i][j]; ii++) {
									for (int jj=1; valid && jj < colspans[i][j]; jj++) {
										valid &= -i == rowspans[i+ii][j];
										valid &= -j == colspans[i][j+jj];
									}
								}
							} else if (valid) {
								valid &= rowspans[-rowspans[i][j]][-colspans[i][j]] >= i + rowspans[i][j];
								valid &= colspans[-rowspans[i][j]][-colspans[i][j]] >= j + colspans[i][j];
							}
							rowWidth += cellWidths[i][j];
							if (valid && i > 0) {
								valid &= cellWidths[0][j] == cellWidths[i][j];
							}
						}
						if (useRelativeWidths) {
							valid &= rowWidth == 100;
						}
					}
					break;
				default:
			}
			return valid;
		}

		/**
		 * Returns the width of this layout. If we are using relative
		 * layout widths, this value will be 100.
		 *
		 * @return the width of this layout
		 */
		public int getLayoutWidth() {
			int total = 0;
			for (int i = 0; i < dividerWidths.length; ++i) {
				total += dividerWidths[i];
			}
			return total;
		}

		// --------------------- Some private methods

		/**
		 * Creates a string name for a cell based on its divider
		 * and cell indices. Cell names are not guaranteed to be
		 * unique.
		 *
		 * @param div the divider index of a cell
		 * @param cell the cell index of a cell
		 * @return a String name for the specified cell
		 */
		private String makeCellName(int div, int cell) {
			return "Region"+(div + 1)+"_"+(cell + 1);
		}

		/**
		 * Checks to see if divider index is valid for this layout
		 *
		 * @param div the divider index to check
		 * @return <code>true</code> if divider index identifies one
		 * of the dividers in this layout, <code>false</code> if it
		 * does not
		 */
		private boolean divOutOfRange(int div) {
			return (div < 0 || div > dividerWidths.length - 1);
		}

		/**
		 * Checks to see if the divider and cell indices are valid for
		 * this layout
		 *
		 * @param div the divider index to check
		 * @param cell the cell index to check
		 * @return <code>true</code> if divider and cell indices identify
		 * one of the cells in this layout, <code>false</code> if they
		 * do not
		 */
		private boolean cellOutOfRange(int div, int cell) {
			return (null == maxModuleWidths ||
					div < 0 ||
					div > maxModuleWidths.length - 1 ||
					null == maxModuleWidths[div] ||
					cell < 0 ||
					cell > maxModuleWidths[div].length - 1);
		}

		/**
		 * Normalize values to sum to 100 (convert values to percentages).
		 *
		 * @param array the int array to normalize
		 * @return the input int array, after being normalized
		 */
		private int[] absToPct(int[] array) {
			int len = array.length;
			int total = 0;

			for (int i = 0; i < len; ++i) {
				total += array[i];
			}

			if (total == 100) return array;

			int newTot = 0;

			for (int i = 0; i < len - 1; ++i) {
				newTot += array[i] = Math.round(((float)array[i] / total) * 100);
			}

			array[len - 1] = 100 - newTot;

			return array;
		}

		// --------------------- Convenience layout manipulation methods

		public void setCellName(int divider, int cell, String name) {
			if (!cellOutOfRange(divider, cell))	{
				cellNames[divider][cell] = name;
			}
		}

	    public void setStyle(int divider, int cell, String style) {
		    if (!cellOutOfRange(divider, cell))	{
			    styles[divider][cell] = style;
		    }
	    }

		public void setMaxModuleWidth(int divider, int cell, int size) {
			if (!cellOutOfRange(divider, cell)) {
				maxModuleWidths[divider][cell] = Math.max(0, size);
			}
		}

		/**
		 * Sets the width for a specified cell
		 * @param divider
		 * @param cell
		 * @param size
		 */
		public void setCellWidth(int divider, int cell, int size) {
			if (!cellOutOfRange(divider, cell)) {
				cellWidths[divider][cell] = Math.max(0, size);
			}
		}


		/**
		 * Setting the new div count.
		 * This may result in structural modification of the layout.
		 * @param newCount
		 */
		public void setDivCount(int newCount) {
			if (newCount < 1) {
				return;
			}

			int layoutWidth = getLayoutWidth();
			int curCount = dividerWidths.length;
			int diff = newCount - curCount;

			if (diff == 0) {
				return;
			}

			int[] newDivWidths = new int[newCount];

			if (diff < 0) {
				// get total size we're removing
				int leftover = 0;

				for (int i = newCount; i < curCount; ++i) {
					leftover += dividerWidths[i];
				}

				// disperse it evenly among existing
				int sizeChange = Math.round((float)leftover / newCount);

				for (int i = 0; i < newCount - 1; ++i) {
					newDivWidths[i] = dividerWidths[i] + sizeChange;
				}

				// account for rounding errors - insure sum is equal to total
				// by padding the last div.
				int calcTotal = 0;

				for (int i = 0; i < newCount - 1; ++i) {
					calcTotal += newDivWidths[i];
				}

				newDivWidths[newDivWidths.length - 1] = layoutWidth  - calcTotal;
			} else {
				// new dividers get equally-proportional width
				int newSize = Math.round((float)layoutWidth / newCount);

				// (do last one later, to catch rounding errors)
				for (int i = curCount; i < newCount - 1; ++i) {
					newDivWidths[i] = newSize;
				}

				// resize existing dividers
				int sizeLeft = layoutWidth - newSize * diff;
				int total = 0;

				for (int i = 0; i < curCount; ++i) {
					float pct = (float)dividerWidths[i] / (float)layoutWidth;
					newDivWidths[i] = Math.round((float)sizeLeft * pct);
					total += newDivWidths[i];
				}

				// last div width == total - rest
				total = 0;

				for (int i = 0; i < newCount - 1; ++i) {
					total += newDivWidths[i];
				}

				int remaining = layoutWidth - total;
				newDivWidths[newDivWidths.length - 1] = remaining;
			}

			dividerWidths = newDivWidths;

			// cell width, cell name arrays, max module width
			int[][] newCellWidths = new int[newCount][];
			String[][] newCellNames = new String[newCount][];
			String[][] newStyles = new String[newCount][];
			String[][] newCellIDs = new String[newCount][];
			int[][] newMaxModuleWidths = new int[newCount][];
			int[][] newColSpans = new int[newCount][];
			int[][] newRowSpans = new int[newCount][];

			if (diff < 0) {
				curCount = newCount;
			}

			// copy existing cells
			for (int i = 0; i < curCount; ++i) {
				newCellWidths[i] = new int[cellWidths[i].length];
				System.arraycopy(cellWidths[i], 0, newCellWidths[i], 0, cellWidths[i].length);

				newCellNames[i] = new String[cellNames[i].length];
				System.arraycopy(cellNames[i], 0, newCellNames[i], 0, newCellNames[i].length);

				newStyles[i] = new String[cellNames[i].length];
				System.arraycopy(styles[i], 0, newStyles[i], 0, newStyles[i].length);

				newCellIDs[i] = new String[cellNames[i].length];
				System.arraycopy(cellNames[i], 0, newCellIDs[i], 0, newCellIDs[i].length);

				newMaxModuleWidths[i] = new int[cellNames[i].length];
				System.arraycopy(maxModuleWidths[i], 0, newMaxModuleWidths[i], 0, newMaxModuleWidths[i].length);

				newColSpans[i] = new int[cellNames[i].length];
				System.arraycopy(colspans[i], 0, newColSpans[i], 0, newColSpans[i].length);

				newRowSpans[i] = new int[cellNames[i].length];
				System.arraycopy(rowspans[i], 0, newRowSpans[i], 0, newRowSpans[i].length);
			}

			if (diff > 0) {
				// create one new cell for each divider
				for (int i = curCount; i < newCount; ++i) {
					newCellWidths[i] = new int[1];
					newCellWidths[i][0] = getLayoutWidth();

					newCellNames[i] = new String[1];
					newCellNames[i][0] = makeCellName(i, 0);

					newStyles[i] = new String[1];
					newStyles[i][0] = "";

					newMaxModuleWidths[i] = new int[1];
					newMaxModuleWidths[i][0] = 0;  // default to zero width

					newColSpans[i] = new int[1];
					newColSpans[i][0] = 1;  // default to 1

					newRowSpans[i] = new int[1];
					newRowSpans[i][0] = 1;  // default to 1
				}
			}

			cellWidths = newCellWidths;
			cellNames = newCellNames;
			styles = newStyles;
			maxModuleWidths = newMaxModuleWidths;
			colspans = newColSpans;
			rowspans = newRowSpans;
		}

		/**
		 * Setting table dimension to a new row & column count.
		 * This operation will unmerge all curently merged cells.
		 *
		 * @param rowCount
		 * @param columnCount
		 */
		public void setTableDimension(int rowCount, int columnCount) {
			int curRowCount = getTableRowCount();
			if (curRowCount != rowCount) {
				setDivCount(rowCount);
			}
			for (int i=0; i<rowCount; i++) {
				setCellCount(i, columnCount);
				for (int j=0; j<columnCount; j++) {
					if (i+rowspans[i][j] > rowCount) {
						rowspans[i][j] = rowCount - i;
					}
					if (j+colspans[i][j] > columnCount) {
						colspans[i][j] = columnCount - j;
					}
				}
			}
			normalizeWidths();
		}

		/**
		 * Setting a new cell count for a div.
		 * This may result in structural modification of the layout (inserting or deleting cells).
		 *
		 * @param divider
		 * @param newCount
		 */
		public void setCellCount(int divider, int newCount) {
			if (divOutOfRange(divider) || newCount < 1) {
				return;
			}

			int[] widths = cellWidths[divider];
			int curCount = widths.length;
			int diff = newCount - curCount;

			if (0 == diff) {
				return;
			}

			// widths
			int[] newWidths = new int[newCount];

			if (diff < 0) { // shrinking, deleting cells
				if (useRelativeWidths) {
					// get total size we're removing
					int leftover = 0;

					for (int i = newCount; i < curCount; ++i) {
						leftover += widths[i];
					}

					// disperse it evenly among existing
					int sizeChange = Math.round((float)leftover / newCount);

					for (int i = 0; i < newCount - 1; ++i) {
						newWidths[i] = widths[i] + sizeChange;
					}

					// account for rounding errors - insure sum is equal to total
					// by padding the last cell.
					int calcTotal = 0;

					for (int i = 0; i < newCount - 1; ++i) {
						calcTotal += newWidths[i];
					}

					newWidths[newWidths.length - 1] = 100 - calcTotal;
				} else {  // (absolute mode)
					System.arraycopy(widths, 0, newWidths, 0, newCount);
				}
			} else { // expanding, inserting cells
				if (useRelativeWidths) {
					// new cells get equally-proportional width
					int newSize = Math.round((float)100 / newCount);

					// (do last one later, to catch rounding errors)
					for (int i = curCount; i < newCount - 1; ++i) {
						newWidths[i] = newSize;
					}

					// resize existing cells
					int sizeLeft = 100 - newSize * diff;
					int total = 0;

					for (int i = 0; i < curCount; ++i) {
						float pct = (float)widths[i] / 100f;
						newWidths[i] = Math.round((float)sizeLeft * pct);
						total += newWidths[i];
					}

					// last cell width == total - rest
					total = 0;


					for (int i = 0; i < newCount - 1; ++i) {
						total += newWidths[i];
					}

					int remaining = 100 - total;
					newWidths[newWidths.length - 1] = remaining;
				} else {  // (absolute)
					System.arraycopy(widths, 0, newWidths, 0, curCount);
					// set default width for new cells
					for (int i = curCount; i < newCount; ++i) {
						newWidths[i] = defaultCellWidth;
					}
				}
			}

			cellWidths[divider] = newWidths;

			// cell name arrays, max module width
			String[] newCellNames = new String[newCount];
			String[] newStyles = new String[newCount];
			String[] newCellIDs = new String[newCount];
			int[] newMaxModuleWidths = new int[newCount];
			int[] newColSpans = new int[newCount];
			int[] newRowSpans = new int[newCount];

			if (diff < 0) {
				// delete by exclusion
				System.arraycopy(cellNames[divider], 0, newCellNames, 0, newCount);
				System.arraycopy(styles[divider], 0, newStyles, 0, newCount);
				System.arraycopy(maxModuleWidths[divider], 0, newMaxModuleWidths, 0, newCount);
				System.arraycopy(colspans[divider], 0, newColSpans, 0, newCount);
				System.arraycopy(rowspans[divider], 0, newRowSpans, 0, newCount);
			} else {
				// copy old cells
				System.arraycopy(cellNames[divider], 0, newCellNames, 0, curCount);
				System.arraycopy(styles[divider], 0, newStyles, 0, curCount);
				System.arraycopy(maxModuleWidths[divider], 0, newMaxModuleWidths, 0, curCount);
				System.arraycopy(colspans[divider], 0, newColSpans, 0, curCount);
				System.arraycopy(rowspans[divider], 0, newRowSpans, 0, curCount);

				// add new cells
				for (int i = curCount; i < newCount; ++i) {
					newCellNames[i] = makeCellName(divider, i);
					newStyles[i] = "";
					newMaxModuleWidths[i] = 0;
					newColSpans[i] = 1;
					newRowSpans[i] = 1;
				}
			}

			cellNames[divider] = newCellNames;
			styles[divider] = newStyles;
			maxModuleWidths[divider] = newMaxModuleWidths;
			colspans[divider] = newColSpans;
			rowspans[divider] = newRowSpans;
		}

		/**
		 * Setting width for a given div
		 * @param div
		 * @param divWidth
		 */
		public void setDivWidth(int div, int divWidth) {
			if (!divOutOfRange(div) && divWidth > 0) {
				dividerWidths[div] = divWidth;
			}
		}


		/**
		 * Setting a colspan attribute in a [div, cell] coordinate
		 * @param div
		 * @param cell
		 * @param colspan
		 */
		public void setColSpan(int div, int cell, int colspan) {
			if (!cellOutOfRange(div, cell)) {
				colspans[div][cell] = colspan;
			}
		}

		/**
		 * Setting a rowspan attribute in a [div, cell] coordinate
		 * @param div
		 * @param cell
		 * @param rowspan
		 */
		public void setRowSpan(int div, int cell, int rowspan) {
			if (!cellOutOfRange(div, cell)) {
				rowspans[div][cell] = rowspan;
			}
		}

		/**
		 * Merge given pairs of [div, cell] coordinates (only for SINGLE_TABLE layout type).
		 * <p>
		 * Requirements (if not fulfilled, then this method will do nothing):
		 * <li> Valid divCells parameter must be specified.
		 *      If the value is not specified correctly (odd cardinality or not greater than two or
		 *      any specified [div, cell] pair is out of range).
		 * <li> All coordinates do not presently span in any direction.
		 * <li> All coordinates must be adjacent in one direction.
		 * <p>
		 * Note: div and cells indexes are not necessarily the row and col indexes.
		 *
		 * @param divCells is an int[] with even cardinality greater than two.
		 * Its value should be { div1, cell1, div2, cell2, ..., ..., divN, cellN }
		 */
		public void mergeCells(int[] divCells) {
			if (layoutType == LAYOUT_TYPE_SINGLE_TABLE
					&& divCells != null && divCells.length > 2 && divCells.length % 2 == 0) {

				// Let's not assume the coordinates are in any particular order, try to buble sort it
				// Also make sure all cells to be merged are not currently spanning
				int numCoords = divCells.length / 2;
				for (int i=0; i<numCoords-1; i++) {
					for (int j=i+1; j<numCoords; j++) {
						int iDiv = divCells[2*i];
						int iCell = divCells[2*i+1];
						int jDiv = divCells[2*j];
						int jCell = divCells[2*j+1];
						if (iDiv > jDiv || iDiv == jDiv && iCell > jCell) {
							divCells[2*j] = iDiv;
							divCells[2*j+1] = iCell;
							divCells[2*i] = jDiv;
							divCells[2*i+1] = jCell;
						}
					}
				}

				int colspan = 1;
				int rowspan = 1;
				int numCellsSpanned = 0;
				// Compute colspan & rowspan values
				for (int i=0; i<divCells.length/2; i++) {
					int rowspani = rowspans[divCells[2*i]][divCells[2*i+1]];
					int colspani = colspans[divCells[2*i]][divCells[2*i+1]];
					rowspan = Math.max(rowspan, divCells[2*i] - divCells[0] + rowspani);
					colspan = Math.max(colspan, divCells[2*i+1] - divCells[1] + colspani);
					if (divCells[0] > divCells[2*i] || divCells[1] > divCells[2*i+1]) {
						return; // no coordinate can be more left or top of the first one
					}
					numCellsSpanned += rowspani * colspani;
				}
				// If all these coordinates are adjacent and represent a rectangle and there's no duplicates,
				// then the number of coordinates must be = colspan * rowspan
				if (colspan * rowspan != numCellsSpanned) {
					return;
				}

				// All checks passed, now perform merge
				rowspans[divCells[0]][divCells[1]] = rowspan;
				colspans[divCells[0]][divCells[1]] = colspan;
				for (int i=1; i<divCells.length/2; i++) {
					rowspans[divCells[2*i]][divCells[2*i+1]] = -divCells[0];
					colspans[divCells[2*i]][divCells[2*i+1]] = -divCells[1];
				}
			}
		}

		/**
		 * Unmerge cells in a given [div, cell] coordinate (only for SINGLE_TABLE layout type).
		 * Out of range coordinate will be ignored
		 * @param div
		 * @param cell
		 */
		public void unmergeCells(int div, int cell) {
			if (layoutType == LAYOUT_TYPE_SINGLE_TABLE && !cellOutOfRange(div, cell)) {
				int rowspan = rowspans[div][cell];
				int colspan = colspans[div][cell];
				for (int i=0; i<rowspan; i++) {
					for (int j=0; j<colspan; j++) {
						rowspans[div+i][cell+j] = 1;
						colspans[div+i][cell+j] = 1;
					}
				}
			}
		}

		public int getTableColumnWidth(int columnIndex) {
			return getCellWidth(0, columnIndex);
		}

		public void setTableColumnWidth(int columnIndex, int width) {
			int divCount = getDividerCount();
			for (int i=0; i<divCount; i++) {
				cellWidths[i][columnIndex] = width;
			}
		}

		public int getTableCellWidth(int rowIndex, int cellIndex) {
			int colspan = colspans[rowIndex][cellIndex];
			int cellCount = getCellCount(rowIndex);
			int width = 0;
			for (int i=0; i<colspan && cellIndex+i < cellCount; i++) {
				width += cellWidths[rowIndex][cellIndex+i];
			}
			return width;
		}

		/**
		 * Returns an int array of cell indexes for the columns available in this row.
		 *
		 * @param rowIndex the row index (or divider index)
		 * @return
		 */
		public int[] getTableColumnCells(int rowIndex) {
			int cellCount = getCellCount(rowIndex);
			int count = 0;
			for (int i=0; i<cellCount; i++) {
				if (rowspans[rowIndex][i] > 0 && colspans[rowIndex][i] > 0) {
					count++;
				}
			}
			int[] cells = new int[count];
			for (int i=0, c=0; i<cellCount; i++) {
				if (rowspans[rowIndex][i] > 0 && colspans[rowIndex][i] > 0) {
					cells[c] = i;
					c++;
				}
			}
			return cells;
		}

		// --------------------- Object equality and cloning

		public boolean equals(Object obj) {
			if (obj instanceof ModelData) {
				boolean eq = true;
				ModelData other = (ModelData) obj;
				eq &= other.layoutType == layoutType;
				if (layoutType == LAYOUT_TYPE_NESTED_TABLE) {
					// row or column orientation only matters in nested table layout
					eq &= other.verticallyOriented == verticallyOriented;
				}
				eq &= other.useRelativeWidths == useRelativeWidths;
				eq &= other.defaultCellWidth == defaultCellWidth;
				eq &= Arrays.equals(other.dividerWidths, dividerWidths);

				eq &= other.cellWidths.length == cellWidths.length;
				eq &= other.cellNames.length == cellNames.length;
				eq &= other.styles.length == styles.length;
				eq &= other.maxModuleWidths.length == maxModuleWidths.length;
				eq &= other.colspans.length == colspans.length;
				eq &= other.rowspans.length == rowspans.length;

				int dividerCount = getDividerCount();
				eq &= other.getDividerCount() == dividerCount;
				for (int i=0; eq && i<dividerCount; i++) {
					eq &= Arrays.equals(other.cellWidths[i], cellWidths[i]);
					eq &= Arrays.equals(other.cellNames[i], cellNames[i]);
					eq &= Arrays.equals(other.styles[i], styles[i]);
					eq &= Arrays.equals(other.maxModuleWidths[i], maxModuleWidths[i]);
					eq &= Arrays.equals(other.colspans[i], colspans[i]);
					eq &= Arrays.equals(other.rowspans[i], rowspans[i]);
				}
				return eq;
			} else {
				return false;
			}
		}

		protected Object clone() throws CloneNotSupportedException {
			ModelData clone = new ModelData();
			clone.layoutType = layoutType;
			clone.verticallyOriented = verticallyOriented;
			clone.useRelativeWidths = useRelativeWidths;
			clone.defaultCellWidth = defaultCellWidth;
			clone.dividerWidths = dividerWidths.clone();

			clone.cellWidths = new int[cellWidths.length][];
			clone.cellNames = new String[cellNames.length][];
			clone.styles = new String[styles.length][];
			clone.maxModuleWidths = new int[maxModuleWidths.length][];
			clone.colspans = new int[colspans.length][];
			clone.rowspans = new int[rowspans.length][];
			int dividerCount = getDividerCount();
			for (int i=0; i<dividerCount; i++) {
				clone.cellWidths[i] = cellWidths[i].clone();
				clone.cellNames[i] = cellNames[i].clone();
				clone.styles[i] = styles[i].clone();
				clone.maxModuleWidths[i] = maxModuleWidths[i].clone();
				clone.colspans[i] = colspans[i].clone();
				clone.rowspans[i] = rowspans[i].clone();
			}
			return clone;
		}

		public Element toXML(Document doc) {
			Element el = doc.createElement("modelData");
			el.setAttribute("layoutType", Integer.toString(layoutType));
			el.setAttribute("verticallyOriented", Boolean.toString(verticallyOriented));
			el.setAttribute("useRelativeWidths", Boolean.toString(useRelativeWidths));
			el.setAttribute("defaultCellWidth", Integer.toString(defaultCellWidth));
			int divCount = getDividerCount();
			for (int i=0; i<divCount; i++) {
				Element divEl = doc.createElement("divider");
				divEl.setAttribute("width", Integer.toString(dividerWidths[i]));
				int cellCount = getCellCount(i);
				for (int j=0; j<cellCount; j++) {
					Element cellEl = doc.createElement("cell");
					cellEl.setAttribute("width", Integer.toString(cellWidths[i][j]));
					cellEl.setAttribute("name", cellNames[i][j]);
					cellEl.setAttribute("style", styles[i][j]);
					cellEl.setAttribute("colspan", Integer.toString(colspans[i][j]));
					cellEl.setAttribute("rowspan", Integer.toString(rowspans[i][j]));
					cellEl.setAttribute("maxModuleWidth", Integer.toString(maxModuleWidths[i][j]));
					divEl.appendChild(cellEl);
				}
				el.appendChild(divEl);
			}
			return el;
		}

		public void fromXML(Element el) {
			if ("modelData".equals(el.getTagName())) {
				layoutType = Integer.parseInt(el.getAttribute("layoutType"));
				verticallyOriented = Boolean.parseBoolean(el.getAttribute("verticallyOriented"));
				useRelativeWidths = Boolean.parseBoolean(el.getAttribute("useRelativeWidths"));
				defaultCellWidth = Integer.parseInt(el.getAttribute("defaultCellWidth"));
				NodeList dividers = el.getElementsByTagName("divider");
				int divCount = dividers.getLength();
				dividerWidths = new int[divCount];
				cellWidths = new int[divCount][];
				cellNames = new String[divCount][];
				styles = new String[divCount][];
				colspans = new int[divCount][];
				rowspans = new int[divCount][];
				maxModuleWidths = new int[divCount][];
				for (int i=0; i<divCount; i++) {
					Element divEl = (Element) dividers.item(i);
					dividerWidths[i] = Integer.parseInt(divEl.getAttribute("width"));
					NodeList cells = divEl.getElementsByTagName("cell");
					int cellCount = cells.getLength();
					cellWidths[i] = new int[cellCount];
					cellNames[i] = new String[cellCount];
					styles[i] = new String[cellCount];
					colspans[i] = new int[cellCount];
					rowspans[i] = new int[cellCount];
					maxModuleWidths[i] = new int[cellCount];
					for (int j=0; j<cellCount; j++) {
						Element cellEl = (Element) cells.item(j);
						cellWidths[i][j] = Integer.parseInt(cellEl.getAttribute("width"));
						cellNames[i][j] = cellEl.getAttribute("name");
						styles[i][j] = cellEl.getAttribute("style");
						colspans[i][j] = Integer.parseInt(cellEl.getAttribute("colspan"));
						rowspans[i][j] = Integer.parseInt(cellEl.getAttribute("rowspan"));
						maxModuleWidths[i][j] = Integer.parseInt(cellEl.getAttribute("maxModuleWidth"));
					}
				}
			}
		}

	    public String toXMLString() throws TransformerException, ParserConfigurationException {
		    Transformer xform = TransformerFactory.newInstance().newTransformer();
		    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		    Source src = new DOMSource(toXML(doc));
		    StringWriter writer = new StringWriter();
		    Result result = new StreamResult(writer);
		    xform.transform(src, result);
		    return writer.toString();
	    }

	    public void fromXMLString(String xmlData) throws ParserConfigurationException, IOException, SAXException {
		    ByteArrayInputStream bais = new ByteArrayInputStream(xmlData.getBytes("UTF-8"));
		    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bais);
		    Element element = (Element) doc.getElementsByTagName("modelData").item(0);
		    fromXML(element);
	    }
	}



    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);

    String SESSION_ATTR_NAME = "$modelData";

	RequestContext requestContext = PageUtil.getCurrentRequestContext(pageContext);

	//If editing is on
	boolean displayInContextEditing = (requestContext.getParameter(LinkBuilder.DISABLE_ICE) == null);
	boolean displayTemplateEditor = false;

	//If editing is on and we are on the preview stage
	if (displayInContextEditing && RequestUtil.inMgmtCDS(request)) {
		ContentInstance ci = (ContentInstance) requestContext.getPrimaryRequestedObject();

		//If this is a template preview
		if(ci instanceof Template) {
			//Display the template editor
			displayTemplateEditor = true;
		}
	}

    ModelData modelData = null;

    try {
        modelData = (ModelData) session.getAttribute(SESSION_ATTR_NAME);
    } catch (ClassCastException ex) {}

    if (modelData == null) {
		modelData = new ModelData(ModelData.LAYOUT_TYPE_SINGLE_TABLE, true, true, 3, 3);
		session.setAttribute(SESSION_ATTR_NAME, modelData);
	}

	String action = displayInContextEditing ? request.getParameter("action") : null;

	if ("new".equals(action)) {
		modelData = new ModelData(ModelData.LAYOUT_TYPE_SINGLE_TABLE, true, true, 3, 3);
		session.setAttribute(SESSION_ATTR_NAME, modelData);
	} else if ("setRowCol".equals(action)) {
		int newRow = Integer.parseInt(request.getParameter("row"));
		int newCol = Integer.parseInt(request.getParameter("col"));
		modelData.setTableDimension(newRow, newCol);
	} else if ("setRelativeWidths".equals(action)) {
		modelData.setUseRelativeWidths(request.getParameter("relativeWidths") != null);
	} else if ("update".equals(action) || "save".equals(action)) {
		String[] width = request.getParameterValues("width");
		for (int i=0; i<width.length; i++) {
			modelData.setTableColumnWidth(i, Integer.parseInt(width[i]));
		}
        modelData.normalizeWidths();
		for (int i=0; i<modelData.getTableRowCount(); i++) {
			for (int j=0; j<modelData.getTableColumnCount(); j++) {
				if (modelData.getColSpan(i, j) > 0 && modelData.getRowSpan(i, j) > 0) {
					modelData.setCellName(i, j, request.getParameter("name"+i+","+j));
					modelData.setStyle(i, j, request.getParameter("style"+i+","+j));
				}
			}
		}
    } else if ("merge".equals(action)) {
		String[] selection = request.getParameterValues("selection");
		int[] divCells = new int[selection.length * 2];
		for (int i=0; i<selection.length; i++) {
			String[] divCell = split(selection[i], ",");
			divCells[2*i] = Integer.parseInt(divCell[0]);
			divCells[2*i+1] = Integer.parseInt(divCell[1]);
		}
		modelData.mergeCells(divCells);
	} else if ("unmerge".equals(action)) {
		String selection = request.getParameter("selection");
		String[] divCell = split(selection, ",");
		modelData.unmergeCells(Integer.parseInt(divCell[0]), Integer.parseInt(divCell[1]));
	} else if ("load".equals(action)) {
		String xmlData = request.getParameter("xmlData");
		modelData.fromXMLString(xmlData);
	} else if (action == null || "".equals(action)) {
		String layoutData = (String) request.getAttribute(TemplatingConstants.PAGE_LAYOUT_DATA_XML);
		if (layoutData == null || "".equals(layoutData)) {
			modelData = new ModelData();
		} else {
			modelData.fromXMLString(layoutData);
		}
	}

	String unit = modelData.isUseRelativeWidths()?"%":"px";

            bw.write(_wl_block1Bytes, _wl_block1);

            if (_jsp__tag0(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block2Bytes, _wl_block2);

            if (_jsp__tag1(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block3Bytes, _wl_block3);

            if (_jsp__tag2(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block3Bytes, _wl_block3);

            if (_jsp__tag3(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block3Bytes, _wl_block3);

            if (_jsp__tag4(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block4Bytes, _wl_block4);
 if (displayTemplateEditor) { 
            bw.write(_wl_block5Bytes, _wl_block5);
 } 
            bw.write(_wl_block6Bytes, _wl_block6);
 if (displayTemplateEditor) { 
            bw.write(_wl_block7Bytes, _wl_block7);
 } 
            bw.write(_wl_block8Bytes, _wl_block8);

            if (_jsp__tag5(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block9Bytes, _wl_block9);
 if (displayTemplateEditor) { 
            bw.write(_wl_block10Bytes, _wl_block10);

		if (request.getParameter("x") != null && !request.getParameter("x").equals("") &&
			request.getParameter("y") != null && !request.getParameter("y").equals("")) {
		
            bw.write(_wl_block11Bytes, _wl_block11);
            out.print(request.getParameter("x"));
            bw.write(_wl_block12Bytes, _wl_block12);
            out.print(request.getParameter("y"));
            bw.write(_wl_block13Bytes, _wl_block13);

		}
		
            bw.write(_wl_block14Bytes, _wl_block14);
 if ("save".equals(action)) { 
            bw.write(_wl_block15Bytes, _wl_block15);
            out.print(requestContext. getRequestOID().getId());
            bw.write(_wl_block16Bytes, _wl_block16);
 } 
            bw.write(_wl_block17Bytes, _wl_block17);
            out.print(modelData.useRelativeWidths?"width:100"+unit+";":"");
            bw.write(_wl_block18Bytes, _wl_block18);

	for (int i=0; i<modelData.getTableColumnCount(); i++) {

            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(i);
            bw.write(_wl_block20Bytes, _wl_block20);
            out.print(modelData.getTableColumnWidth(i));
            out.print(unit);
            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(i);
            bw.write(_wl_block22Bytes, _wl_block22);
            out.print(modelData.getTableColumnWidth(i));
            bw.write(_wl_block23Bytes, _wl_block23);
            out.print(unit);
            bw.write(_wl_block24Bytes, _wl_block24);

		}

            bw.write(_wl_block25Bytes, _wl_block25);

				for (int i=1; i<=10; i++) {
					out.println("<option"+(i==modelData.getTableRowCount()?" selected":"")+">"+i+"</option>");
				}
				
            bw.write(_wl_block26Bytes, _wl_block26);

				for (int i=1; i<=10; i++) {
					out.println("<option"+(i==modelData.getTableColumnCount()?" selected":"")+">"+i+"</option>");
				}
				
            bw.write(_wl_block27Bytes, _wl_block27);
            out.print(modelData.isUseRelativeWidths()?"checked":"");
            bw.write(_wl_block28Bytes, _wl_block28);
            out.print(request.getParameter("hideGrid")!=null?"checked":"");
            bw.write(_wl_block29Bytes, _wl_block29);
            out.print(request.getParameter("hideRuler")!=null?"checked":"");
            bw.write(_wl_block30Bytes, _wl_block30);

							for (int i=0; i<modelData.getTableColumnCount(); i++) {
			
            bw.write(_wl_block31Bytes, _wl_block31);
            out.print( modelData.getTableColumnWidth(i) );
            bw.write(_wl_block32Bytes, _wl_block32);

							}
							for (int i=0; i<modelData.getDividerCount(); i++) {
								for (int j=0; j<modelData.getCellCount(i); j++) {
									if (modelData.getRowSpan(i,j) > 0 || modelData.getColSpan(i,j) > 0) {
										String ij = i+","+j;
			
            bw.write(_wl_block33Bytes, _wl_block33);
            out.print(ij);
            bw.write(_wl_block22Bytes, _wl_block22);
            out.print(modelData.getRowSpan(i,j));
            bw.write(_wl_block34Bytes, _wl_block34);
            out.print(ij);
            bw.write(_wl_block22Bytes, _wl_block22);
            out.print(modelData.getColSpan(i,j));
            bw.write(_wl_block35Bytes, _wl_block35);
            out.print(ij);
            bw.write(_wl_block36Bytes, _wl_block36);
            out.print(ij);
            bw.write(_wl_block37Bytes, _wl_block37);
            out.print(ij);
            bw.write(_wl_block22Bytes, _wl_block22);
            out.print(modelData.getCellName(i,j));
            bw.write(_wl_block38Bytes, _wl_block38);
            out.print(ij);
            bw.write(_wl_block39Bytes, _wl_block39);
            out.print(modelData.getStyle(i,j));
            bw.write(_wl_block40Bytes, _wl_block40);

									}
								}
							}
			
            bw.write(_wl_block41Bytes, _wl_block41);
            out.print( modelData.toXMLString() );
            bw.write(_wl_block42Bytes, _wl_block42);

	for (int i=0; i<modelData.getDividerCount(); i++) {
		for (int j=0; j<modelData.getCellCount(i); j++) {
			if (modelData.getRowSpan(i,j) > 0 || modelData.getColSpan(i,j) > 0) {
				String ij = i+","+j;

            bw.write(_wl_block43Bytes, _wl_block43);
            out.print(ij);
            bw.write(_wl_block44Bytes, _wl_block44);
            out.print(modelData.getCellName(i,j));
            bw.write(_wl_block45Bytes, _wl_block45);

			}
		}
	}

            bw.write(_wl_block9Bytes, _wl_block9);
 } // end if (displayInContextEditing) 
            bw.write(_wl_block46Bytes, _wl_block46);
            out.print( modelData.isUseRelativeWidths()?"width:100%":"" );
            bw.write(_wl_block18Bytes, _wl_block18);

	for (int i=0; i<modelData.getDividerCount(); i++) {

            bw.write(_wl_block47Bytes, _wl_block47);

		for (int j=0; j<modelData.getCellCount(i); j++) {
			if (modelData.getRowSpan(i,j) > 0 || modelData.getColSpan(i,j) > 0) {
				String ij = i+","+j;

            bw.write(_wl_block48Bytes, _wl_block48);
            out.print(ij);
            bw.write(_wl_block49Bytes, _wl_block49);
            out.print( modelData.getColSpan(i,j) );
            bw.write(_wl_block50Bytes, _wl_block50);
            out.print( modelData.getRowSpan(i,j) );
            bw.write(_wl_block51Bytes, _wl_block51);
            out.print( modelData.getCellWidth(i,j) );
            out.print( unit );
            bw.write(_wl_block52Bytes, _wl_block52);
 if (displayTemplateEditor) { 
            bw.write(_wl_block53Bytes, _wl_block53);
 } 
            bw.write(_wl_block54Bytes, _wl_block54);
            out.print( modelData.getStyle(i,j) );
            bw.write(_wl_block55Bytes, _wl_block55);
             com.vignette.ext.templating.mvc.taglib.ContentRegionTagSupport __tag6 = null ;
            int __result__tag6 = 0 ;

            if (__tag6 == null ){
                __tag6 = new  com.vignette.ext.templating.mvc.taglib.ContentRegionTagSupport ();
                weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag6);
            }
            __tag6.setPageContext(pageContext);
            __tag6.setParent(null);
            __tag6.setName( modelData.getCellName(i,j) 
);
            __tag6.setScope(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("template", java.lang.String .class,"scope"));
            _activeTag=__tag6;
            __result__tag6 = __tag6.doStartTag();

            if (__result__tag6!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
                if (__result__tag6== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                     throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.ContentRegionTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
                }
            }
            if (__tag6.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
                _activeTag = null;
                _releaseTags(pageContext, __tag6);
                return;
            }
            _activeTag=__tag6.getParent();
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag6);
            __tag6.release();
            bw.write(_wl_block56Bytes, _wl_block56);

			}
		}

            bw.write(_wl_block57Bytes, _wl_block57);

	}

            bw.write(_wl_block58Bytes, _wl_block58);
        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag0(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.XhtmlTagSupport __tag0 = null ;
        int __result__tag0 = 0 ;

        if (__tag0 == null ){
            __tag0 = new  com.vignette.ext.templating.mvc.taglib.XhtmlTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
        }
        __tag0.setPageContext(pageContext);
        __tag0.setParent(null);
        _activeTag=__tag0;
        __result__tag0 = __tag0.doStartTag();

        if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.XhtmlTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag0);
            return true;
        }
        _activeTag=__tag0.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
        __tag0.release();
        return false;
    }

    private boolean _jsp__tag1(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.MetaDescriptionTagSupport __tag1 = null ;
        int __result__tag1 = 0 ;

        if (__tag1 == null ){
            __tag1 = new  com.vignette.ext.templating.mvc.taglib.MetaDescriptionTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag1);
        }
        __tag1.setPageContext(pageContext);
        __tag1.setParent(null);
        _activeTag=__tag1;
        __result__tag1 = __tag1.doStartTag();

        if (__result__tag1!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag1== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.MetaDescriptionTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag1.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag1);
            return true;
        }
        _activeTag=__tag1.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag1);
        __tag1.release();
        return false;
    }

    private boolean _jsp__tag2(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.MetaKeywordsTagSupport __tag2 = null ;
        int __result__tag2 = 0 ;

        if (__tag2 == null ){
            __tag2 = new  com.vignette.ext.templating.mvc.taglib.MetaKeywordsTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag2);
        }
        __tag2.setPageContext(pageContext);
        __tag2.setParent(null);
        _activeTag=__tag2;
        __result__tag2 = __tag2.doStartTag();

        if (__result__tag2!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag2== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.MetaKeywordsTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag2.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag2);
            return true;
        }
        _activeTag=__tag2.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag2);
        __tag2.release();
        return false;
    }

    private boolean _jsp__tag3(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.StyleSheetTagSupport __tag3 = null ;
        int __result__tag3 = 0 ;

        if (__tag3 == null ){
            __tag3 = new  com.vignette.ext.templating.mvc.taglib.StyleSheetTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag3);
        }
        __tag3.setPageContext(pageContext);
        __tag3.setParent(null);
        _activeTag=__tag3;
        __result__tag3 = __tag3.doStartTag();

        if (__result__tag3!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag3== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.StyleSheetTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag3.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag3);
            return true;
        }
        _activeTag=__tag3.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag3);
        __tag3.release();
        return false;
    }

    private boolean _jsp__tag4(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.ThemeTagSupport __tag4 = null ;
        int __result__tag4 = 0 ;

        if (__tag4 == null ){
            __tag4 = new  com.vignette.ext.templating.mvc.taglib.ThemeTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag4);
        }
        __tag4.setPageContext(pageContext);
        __tag4.setParent(null);
        _activeTag=__tag4;
        __result__tag4 = __tag4.doStartTag();

        if (__result__tag4!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag4== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.ThemeTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag4.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag4);
            return true;
        }
        _activeTag=__tag4.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag4);
        __tag4.release();
        return false;
    }

    private boolean _jsp__tag5(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         com.vignette.ext.templating.mvc.taglib.PageInContextEditTagSupport __tag5 = null ;
        int __result__tag5 = 0 ;

        if (__tag5 == null ){
            __tag5 = new  com.vignette.ext.templating.mvc.taglib.PageInContextEditTagSupport ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag5);
        }
        __tag5.setPageContext(pageContext);
        __tag5.setParent(null);
        _activeTag=__tag5;
        __result__tag5 = __tag5.doStartTag();

        if (__result__tag5!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag5== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class com.vignette.ext.templating.mvc.taglib.PageInContextEditTagSupport does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag5.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag5);
            return true;
        }
        _activeTag=__tag5.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag5);
        __tag5.release();
        return false;
    }
}
