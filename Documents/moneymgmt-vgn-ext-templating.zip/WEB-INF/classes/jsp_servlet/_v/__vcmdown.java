package jsp_servlet._v;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public final class __vcmdown extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/v/vcmdown.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "utf-8".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\n<html>\n<head>\n<script type=\"text/javascript\">\n\tvar vgnextvcmdown = {\n\t\tinit: function() {\n\t\t\tthis.serverPrefix = document.location.protocol+\"//\"+document.location.host;\n\t\t\tthis.imagePrefix = this.serverPrefix + \"/vgn-ext-templating/vcmdown-images/\";\n\t\t\tthis.vcmPingUrl = this.serverPrefix + \"/cps/script/preview/cps-ping.jsp\";\n\t\t\tif (window.XMLHttpRequest) {\n\t\t\t\t// code for all new browsers\n\t\t\t\tthis.xmlhttp = new XMLHttpRequest();\n\t\t\t} else if (window.ActiveXObject) {\n\t\t\t\t// code for IE5 and IE6\n\t\t\t\tthis.xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");\n\t\t\t}\n\t\t},\n\t\tretry: function() {\n\t\t\tvar xmlhttp = this.xmlhttp;\n\t\t\tif (xmlhttp != null) {\n\t\t\t\tthis.button.disabled = true;\n\t\t\t\tthis.ready.style.display = \'none\';\n\t\t\t\tthis.wait.style.display = \'\';\n\t\t\t\tthis.timeout = 30000;\n\t\t\t\ttry {\n\t\t\t\t\txmlhttp.open(\"GET\", this.vcmPingUrl, false);\n\t\t\t\t\txmlhttp.send(null);\n\t\t\t\t\tif (xmlhttp.readyState == 4) {\n\t\t\t\t\t\tif (xmlhttp.status == 200) {\n\t\t\t\t\t\t\t//VCM is now up\n\t\t\t\t\t\t\tdocument.location.reload(true);\n\t\t\t\t\t\t}\n\t\t\t\t\t}\n\t\t\t\t} catch (ex) {\n\t\t\t\t}\n\t\t\t\tthis.button.disabled = false;\n\t\t\t\tthis.ready.style.display = \'\';\n\t\t\t\tthis.wait.style.display = \'none\';\n\t\t\t}\n\t\t}\n\t};\n\t(function(){\n\t\tvgnextvcmdown.init();\n\t\tdocument.writeln(\n\t\t\'<style type=\"text/css\">\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie{position: fixed; bottom: 0; left: 0; z-index: 10000;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie, .vui-cps-ui-vcmdownfloatie .warning-message{font-family: arial, sans-serif; font-size: 0.875em;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .x-window-tl{background: transparent url(\"\'+vgnextvcmdown.imagePrefix+\'headerSprite-opt.png\") no-repeat scroll left top; padding-left: 6px; zoom: 1; z-index: 1; position: relative;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .x-window-tr{background: transparent url(\"\'+vgnextvcmdown.imagePrefix+\'headerSprite-opt.png\") no-repeat scroll right -104px; padding-right: 6px;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .x-window-tc{background: transparent url(\"\'+vgnextvcmdown.imagePrefix+\'headerSprite-opt.png\") repeat-x scroll left -312px; zoom: 1;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .x-window-tc .x-window-header{background: transparent url(\"\'+vgnextvcmdown.imagePrefix+\'headerSprite-opt.png\") no-repeat scroll right -208px; padding: 2px 0 2px;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .vui-cps-icon-warning, .vui-cps-ui-vcmdownfloatie .x-btn-retry{font-size: 0.85em;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .vui-cps-icon-warning{font-weight: bold; width: 100px; height: 16px; margin: 0 0 0 3px; overflow: hidden; padding: 1px 0 0 19px; background: transparent url(\"\'+vgnextvcmdown.imagePrefix+\'warning.png\") no-repeat; color: #ffffff;}\'+\n\t\t\t\'.vui-cps-ui-vcmdownfloatie .x-btn-retry{background: #cccccc none no-repeat;}\'+\n\t\t\'</style>\');\n\t\tdocument.writeln(\n\t\t\'<div class=\"vui-cps-ui-vcmdownfloatie\">\'+\n\t\t\t\'<div class=\"x-window-tl\">\'+\n\t\t\t\t\'<div class=\"x-window-tr\">\'+\n\t\t\t\t\t\'<div class=\"x-window-tc\">\'+\n\t\t\t\t\t\t\'<div class=\"x-window-header\">\'+\n\t\t\t\t\t\t\t\'<span class=\"x-window-header-text vui-cps-icon-warning\">";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 ="\'+\n\t\t\t\t\t\t\t\t\'&nbsp;&nbsp;</span>\'+\n\t\t\t\t\t\t\t\'<img id=\"vgnextvcmdown_wait\" src=\"\'+vgnextvcmdown.imagePrefix+\'animated_wait.gif\" style=\"display: none;\" width=\"16\" height=\"16\"/>\'+\n\t\t\t\t\t\t\t\'<img id=\"vgnextvcmdown_ready\" src=\"\'+vgnextvcmdown.imagePrefix+\'s.gif\" width=\"16\" height=\"16\"/>\'+\n\t\t\t\t\t\t\t\'<input id=\"vgnextvcmdown_button\" type=\"button\" class=\"x-btn-retry\" value=\"";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="\" onclick=\"vgnextvcmdown.retry();\" />\'+\n\t\t\t\t\t\t\'</div>\'+\n\t\t\t\t\t\'</div>\'+\n\t\t\t\t\'</div>\'+\n\t\t\t\'</div>\'+\n\t\t\'</div>\');\n\t\tvgnextvcmdown.wait = document.getElementById(\'vgnextvcmdown_wait\');\n\t\tvgnextvcmdown.ready = document.getElementById(\'vgnextvcmdown_ready\');\n\t\tvgnextvcmdown.button = document.getElementById(\'vgnextvcmdown_button\');\n\t})();\n </script>\n </head>\n </html>";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html; charset=utf-8");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            response.setContentType("text/html; charset=utf-8");
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
             org.apache.taglibs.i18n.BundleTag __tag0 = null ;
            int __result__tag0 = 0 ;

            if (__tag0 == null ){
                __tag0 = new  org.apache.taglibs.i18n.BundleTag ();
                weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
            }
            __tag0.setPageContext(pageContext);
            __tag0.setParent(null);
            __tag0.setBaseName(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("com.vignette.ext.templating.TemplatingJSPMsgs", java.lang.String .class,"baseName"));
            __tag0.setLocale( request.getLocale()
);
            _activeTag=__tag0;
            __result__tag0 = __tag0.doStartTag();

            if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
                if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                     throw  new  javax.servlet.jsp.JspTagException("Since tag class org.apache.taglibs.i18n.BundleTag does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
                }
            }
            if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
                _activeTag = null;
                _releaseTags(pageContext, __tag0);
                return;
            }
            _activeTag=__tag0.getParent();
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
            __tag0.release();
            bw.write(_wl_block1Bytes, _wl_block1);

            if (_jsp__tag1(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block2Bytes, _wl_block2);

            if (_jsp__tag2(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block3Bytes, _wl_block3);
        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag1(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag1 = null ;
        int __result__tag1 = 0 ;

        if (__tag1 == null ){
            __tag1 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag1);
        }
        __tag1.setPageContext(pageContext);
        __tag1.setParent(null);
        __tag1.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_SERVER_DOWN", java.lang.String .class,"key"));
        _activeTag=__tag1;
        __result__tag1 = __tag1.doStartTag();

        if (__result__tag1!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag1== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag1.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag1);
            return true;
        }
        _activeTag=__tag1.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag1);
        __tag1.release();
        return false;
    }

    private boolean _jsp__tag2(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag2 = null ;
        int __result__tag2 = 0 ;

        if (__tag2 == null ){
            __tag2 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag2);
        }
        __tag2.setPageContext(pageContext);
        __tag2.setParent(null);
        __tag2.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_RETRY", java.lang.String .class,"key"));
        _activeTag=__tag2;
        __result__tag2 = __tag2.doStartTag();

        if (__result__tag2!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag2== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag2.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag2);
            return true;
        }
        _activeTag=__tag2.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag2);
        __tag2.release();
        return false;
    }
}
