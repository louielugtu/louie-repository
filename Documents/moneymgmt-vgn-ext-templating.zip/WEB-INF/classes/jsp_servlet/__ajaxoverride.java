package jsp_servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.vignette.as.client.javabean.ManagedObject;
import com.vignette.ext.templating.TemplatingConstants;
import com.vignette.ext.templating.client.javabean.ContentComponent;
import com.vignette.ext.templating.client.javabean.QueryContentComponent;
import com.vignette.ext.templating.link.LinkBuilder;
import com.vignette.ext.templating.util.RequestContext;
import com.vignette.ext.templating.util.PageUtil;
import com.vignette.ext.templating.util.XSLPageUtil;
import com.vignette.logging.context.ContextLogger;
import java.util.List;

public final class __ajaxoverride extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/ajaxOverride.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "UTF-8".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\n";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 ="\n\t\t\t<div style=\"font-family:verdana,arial; font-size:11px; padding:3px; background-color:#dedede;\" >\n\t\t\t\t";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="\n\t\t\t</div>\n";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    private final static java.lang.String  _wl_block4 ="\n\t\t\t\t<div style=\"font-family:verdana,arial; font-size:11px; padding:3px; background-color:#dedede;\" >\n\t\t\t\t\t";
    private final static byte[]  _wl_block4Bytes = _getBytes( _wl_block4 );

    private final static java.lang.String  _wl_block5 ="\n\t\t\t\t</div>\n";
    private final static byte[]  _wl_block5Bytes = _getBytes( _wl_block5 );

    private final static java.lang.String  _wl_block6 ="\n\t\t\t\t\t<div id=\"";
    private final static byte[]  _wl_block6Bytes = _getBytes( _wl_block6 );

    private final static java.lang.String  _wl_block7 ="pagination-div\">\n";
    private final static byte[]  _wl_block7Bytes = _getBytes( _wl_block7 );

    private final static java.lang.String  _wl_block8 ="\n\t\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t\t";
    private final static byte[]  _wl_block8Bytes = _getBytes( _wl_block8 );

    private final static java.lang.String  _wl_block9 ="\n\t\t\t\t\t<br/>\n\t\t\t\t</div>\n";
    private final static byte[]  _wl_block9Bytes = _getBytes( _wl_block9 );

    private final static java.lang.String  _wl_block10 ="\n\t\t\t<span class=\"vgn-ext-text\">\n\t\t\t\t<li type=\"square\">\n\t\t\t\t\t<a href=\"";
    private final static byte[]  _wl_block10Bytes = _getBytes( _wl_block10 );

    private final static java.lang.String  _wl_block11 ="\" class=\"vgn-ext-link\" >";
    private final static byte[]  _wl_block11Bytes = _getBytes( _wl_block11 );

    private final static java.lang.String  _wl_block12 =" </a>&nbsp;";
    private final static byte[]  _wl_block12Bytes = _getBytes( _wl_block12 );

    private final static java.lang.String  _wl_block13 ="\n\t\t\t\t</li>\n\t\t\t</span>\n";
    private final static byte[]  _wl_block13Bytes = _getBytes( _wl_block13 );

    private final static java.lang.String  _wl_block14 ="\n\t\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t\t<br/>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block14Bytes = _getBytes( _wl_block14 );

    private final static java.lang.String  _wl_block15 ="\n\t<!--Portal AJAX Library-->\n\t<script language=\"JavaScript\" src=\"/portal/jslib/vapajaxlibrary.js\" ></script>\n\t<!--call back function that reloads the view with ajax response-->\n\t<script language=\"JavaScript\">\n\n\t\tfunction ";
    private final static byte[]  _wl_block15Bytes = _getBytes( _wl_block15 );

    private final static java.lang.String  _wl_block16 ="handleResponse(req) {\n\n\t\t\tvar html = req.responseText;\n\t\t\tvar elementId = \"";
    private final static byte[]  _wl_block16Bytes = _getBytes( _wl_block16 );

    private final static java.lang.String  _wl_block17 ="pagination-div\";\n\t\t\t//DIV will be reloaded with the response\n\t\t\tdocument.getElementById(elementId).innerHTML = req.responseText;\n\t\t}\n\t</script>\n\t\t\t\t<table width=100% > <tr>\n";
    private final static byte[]  _wl_block17Bytes = _getBytes( _wl_block17 );

    private final static java.lang.String  _wl_block18 ="\n\t\t\t\t\t<td align=\"left\" class=\"epi-dim\">\n\t\t\t\t\t\t<a href=\"javascript:;\" style=\"\" onclick=\"new VignettePortal.AJAXClient().sendURL(\'";
    private final static byte[]  _wl_block18Bytes = _getBytes( _wl_block18 );

    private final static java.lang.String  _wl_block19 ="&";
    private final static byte[]  _wl_block19Bytes = _getBytes( _wl_block19 );

    private final static java.lang.String  _wl_block20 ="=";
    private final static byte[]  _wl_block20Bytes = _getBytes( _wl_block20 );

    private final static java.lang.String  _wl_block21 ="\',";
    private final static byte[]  _wl_block21Bytes = _getBytes( _wl_block21 );

    private final static java.lang.String  _wl_block22 ="handleResponse);return false\" >\n\n\t\t\t\t\t\t\t";
    private final static byte[]  _wl_block22Bytes = _getBytes( _wl_block22 );

    private final static java.lang.String  _wl_block23 ="\n\t\t\t\t\t\t</a>\n\t\t\t\t\t</td>\n";
    private final static byte[]  _wl_block23Bytes = _getBytes( _wl_block23 );

    private final static java.lang.String  _wl_block24 ="\n\t\t\t\t\t<td align=\"right\" class=\"epi-dim\">\n\t\t\t\t\t\t<a href=\"javascript:;\" style=\"\" onclick=\"new VignettePortal.AJAXClient().sendURL(\'";
    private final static byte[]  _wl_block24Bytes = _getBytes( _wl_block24 );

    private final static java.lang.String  _wl_block25 ="handleResponse);return false\" > \n\t\t\t\t\t\t\t";
    private final static byte[]  _wl_block25Bytes = _getBytes( _wl_block25 );

    private final static java.lang.String  _wl_block26 ="\n\t\t\t\t</tr></table>\n";
    private final static byte[]  _wl_block26Bytes = _getBytes( _wl_block26 );

    private final static java.lang.String  _wl_block27 ="\n\t";
    private final static byte[]  _wl_block27Bytes = _getBytes( _wl_block27 );

    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html; charset=UTF-8");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            response.setContentType("text/html; charset=UTF-8");
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
             org.apache.taglibs.i18n.BundleTag __tag0 = null ;
            int __result__tag0 = 0 ;

            if (__tag0 == null ){
                __tag0 = new  org.apache.taglibs.i18n.BundleTag ();
                weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
            }
            __tag0.setPageContext(pageContext);
            __tag0.setParent(null);
            __tag0.setBaseName(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("com.vignette.ext.templating.TemplatingJSPMsgs", java.lang.String .class,"baseName"));
            __tag0.setLocale( request.getLocale() 
);
            _activeTag=__tag0;
            __result__tag0 = __tag0.doStartTag();

            if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
                if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                     throw  new  javax.servlet.jsp.JspTagException("Since tag class org.apache.taglibs.i18n.BundleTag does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
                }
            }
            if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
                _activeTag = null;
                _releaseTags(pageContext, __tag0);
                return;
            }
            _activeTag=__tag0.getParent();
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
            __tag0.release();
            bw.write(_wl_block0Bytes, _wl_block0);

	RequestContext rc = PageUtil.getCurrentRequestContext(pageContext);
	final ContextLogger logger = ContextLogger.getLogger(request.getServletPath());
	try {
		// If not DPM display error message
		if (!rc.isPortalRequest()) {
			if (logger.isDebugEnabled()) {
				logger.debug("ajaxOverride.jsp : This view cannot be configured for a DSM appInstance.");
			}
			if (rc.inMgmtCDS()) {

            bw.write(_wl_block2Bytes, _wl_block2);

            if (_jsp__tag1(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block3Bytes, _wl_block3);

			}

		} else {
			ManagedObject renderedMo = rc.getRenderedManagedObject();
			// Check if the component being used is QueryComponent, else do not render the component
			if (!(renderedMo instanceof QueryContentComponent)) {
				if (logger.isDebugEnabled()) {
					logger.debug("ajaxOverride.jsp : This Content Component is not supported for Pagination View.");
				}
				if (rc.inMgmtCDS()) {

            bw.write(_wl_block4Bytes, _wl_block4);

            if (_jsp__tag2(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block5Bytes, _wl_block5);

				}
			} else {
				QueryContentComponent qc = (QueryContentComponent)renderedMo;
				// NameSpace - in this case portlet name retrieved from request, used to prefix the JavaScript functions 
				// to ensure uniqueness
				String nameSpace = rc.getNameSpaceForPagination();
				// Verifying if we have the index key, if yes it means that the call is from pagination response jsp
				boolean hasVgnNextStartIndexKey = rc.getParameter(TemplatingConstants.QUERY_RESULTS_PAGINATION_NEXT_INDEX_KEY) != null;
				// We do not want this div element to be rendered for every click in pagination mode, so verifying if this call
				// is from pagination mode, if yes do not render the div
				if (!hasVgnNextStartIndexKey) {

            bw.write(_wl_block6Bytes, _wl_block6);
            out.print(nameSpace);
            bw.write(_wl_block7Bytes, _wl_block7);

				}
				// Display Title if it is set
				if (qc.getAttributeValue(ContentComponent.COMPONENT_TITLE_ATTRIB) != null) {

            bw.write(_wl_block8Bytes, _wl_block8);
            out.print(qc.getAttributeValue(ContentComponent.COMPONENT_TITLE_ATTRIB));
            bw.write(_wl_block9Bytes, _wl_block9);

				}
				// Display Header if it is set
				if (qc.getAttributeValue(ContentComponent.COMPONENT_HEADER_ATTRIB) != null) {

            bw.write(_wl_block8Bytes, _wl_block8);
            out.print(qc.getAttributeValue(ContentComponent.COMPONENT_HEADER_ATTRIB));
            bw.write(_wl_block9Bytes, _wl_block9);

				}
				// Pagination code starts here
				// vgnextoid and appInstance have to be added to the query string as it will be not available when 
				// we reset a component
				String oidLink = "";
				if (rc.getParameter(LinkBuilder.OID_LINK_PARAMETER) != null) {
					oidLink = LinkBuilder.OID_LINK_PARAMETER + '=' + rc.getParameter(LinkBuilder.OID_LINK_PARAMETER) +'&' + TemplatingConstants.REQUEST_PARAM_APP_INSTANCE_NAME +'=' + rc.getParameter(TemplatingConstants.REQUEST_PARAM_APP_INSTANCE_NAME) + '&';
				}
				// Retrieve the start index for the current batch of items to be displayed on this page 
				String vgnNextStartIndex = (String)rc.getRequest().getAttribute(TemplatingConstants.QUERY_RESULTS_PAGINATION_NEXT_INDEX_KEY);
				// This value indicates that the component is reset and so we should not consider the start index value set in the request
				String vgnExtIsComponentReset = (String)rc.getParameter(TemplatingConstants.COMPONENT_RESET_PARAM_KEY);
				// Check if the component has been reset
				if (vgnExtIsComponentReset == null) {
					vgnExtIsComponentReset = "false"; 
				}
				// Ajax URL set in portlet
				String nextURL = rc.getNextURLForPagination();;
				int currentStartIndex = 0;
				// Start index value has to be picked up from request only when you click on next/previous links
				if (vgnNextStartIndex != null && !vgnExtIsComponentReset.equals("true")) {
					currentStartIndex = Integer.parseInt(vgnNextStartIndex);
				}
				// Pagination list size or the number of results to be displayed per page
				int batchsize = qc.getPaginationListSize();
				// Query for the results required per page
				List subList = qc.getResults(rc, currentStartIndex, batchsize + 1);
				int subListCount = subList.size();
				ManagedObject mo = null;
				int len = 0;
				if (subListCount > batchsize) {
					len = subList.size() -1;
				} else {
					len = subList.size();
				}
				// Display the results
				for (int i = 0; i < len; i++) {
					mo = (ManagedObject)subList.get(i);
					String linkURI = XSLPageUtil.buildLinkURI(rc, mo.getContentManagementId().toString(), "", "");
					String inContext = XSLPageUtil.displayInContextEditing(rc, mo.getContentManagementId().toString());

            bw.write(_wl_block10Bytes, _wl_block10);
            out.print(linkURI);
            bw.write(_wl_block11Bytes, _wl_block11);
            out.print(mo.getName());
            bw.write(_wl_block12Bytes, _wl_block12);
            out.print(inContext);
            bw.write(_wl_block13Bytes, _wl_block13);

				}
				// Display Footer if it is set
				if (qc.getAttributeValue(ContentComponent.COMPONENT_FOOTER_ATTRIB) != null) {

            bw.write(_wl_block14Bytes, _wl_block14);
            out.print(qc.getAttributeValue(ContentComponent.COMPONENT_FOOTER_ATTRIB));
            bw.write(_wl_block9Bytes, _wl_block9);

				}

            bw.write(_wl_block15Bytes, _wl_block15);
            out.print(nameSpace.toString());
            bw.write(_wl_block16Bytes, _wl_block16);
            out.print(nameSpace);
            bw.write(_wl_block17Bytes, _wl_block17);

				// Generating the link for Previous Page, we are suffixing vgnextoid, appInstanceName and next start index 
				// to the URL. oid and appinstance are added as they are lost from request when a ajax response is loaded
				if (currentStartIndex > 0) {

            bw.write(_wl_block18Bytes, _wl_block18);
            out.print(nextURL.toString());
            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(oidLink);
            out.print(TemplatingConstants.QUERY_RESULTS_PAGINATION_NEXT_INDEX_KEY);
            bw.write(_wl_block20Bytes, _wl_block20);
            out.print((currentStartIndex - batchsize));
            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(nameSpace);
            bw.write(_wl_block22Bytes, _wl_block22);

            if (_jsp__tag3(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block23Bytes, _wl_block23);

				}
				// Next Page link
				if (subListCount > batchsize) {

            bw.write(_wl_block24Bytes, _wl_block24);
            out.print(nextURL.toString());
            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(oidLink);
            out.print(TemplatingConstants.QUERY_RESULTS_PAGINATION_NEXT_INDEX_KEY);
            bw.write(_wl_block20Bytes, _wl_block20);
            out.print((currentStartIndex + batchsize));
            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(nameSpace);
            bw.write(_wl_block25Bytes, _wl_block25);

            if (_jsp__tag4(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block23Bytes, _wl_block23);

				}

            bw.write(_wl_block26Bytes, _wl_block26);

			if (!hasVgnNextStartIndexKey) {

            bw.write(_wl_block5Bytes, _wl_block5);

			}
			}
		}
	} catch(Exception e) {
		// indicate that the following output shouldnt be cached.
		rc.setNoCache(true);

            bw.write(_wl_block27Bytes, _wl_block27);

            if (_jsp__tag5(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block0Bytes, _wl_block0);

	}

        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag1(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag1 = null ;
        int __result__tag1 = 0 ;

        if (__tag1 == null ){
            __tag1 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag1);
        }
        __tag1.setPageContext(pageContext);
        __tag1.setParent(null);
        __tag1.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_EXCEPTION_WHILE_RENDERING_PAGINATION_VIEW", java.lang.String .class,"key"));
        _activeTag=__tag1;
        __result__tag1 = __tag1.doStartTag();

        if (__result__tag1!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag1== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag1.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag1);
            return true;
        }
        _activeTag=__tag1.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag1);
        __tag1.release();
        return false;
    }

    private boolean _jsp__tag2(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag2 = null ;
        int __result__tag2 = 0 ;

        if (__tag2 == null ){
            __tag2 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag2);
        }
        __tag2.setPageContext(pageContext);
        __tag2.setParent(null);
        __tag2.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_WRONG_COMPONENT_ASSOC_FOR_PAGINATION_VIEW", java.lang.String .class,"key"));
        _activeTag=__tag2;
        __result__tag2 = __tag2.doStartTag();

        if (__result__tag2!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag2== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag2.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag2);
            return true;
        }
        _activeTag=__tag2.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag2);
        __tag2.release();
        return false;
    }

    private boolean _jsp__tag3(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag3 = null ;
        int __result__tag3 = 0 ;

        if (__tag3 == null ){
            __tag3 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag3);
        }
        __tag3.setPageContext(pageContext);
        __tag3.setParent(null);
        __tag3.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_LABEL_PREVIOUS_PAGE", java.lang.String .class,"key"));
        _activeTag=__tag3;
        __result__tag3 = __tag3.doStartTag();

        if (__result__tag3!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag3== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag3.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag3);
            return true;
        }
        _activeTag=__tag3.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag3);
        __tag3.release();
        return false;
    }

    private boolean _jsp__tag4(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag4 = null ;
        int __result__tag4 = 0 ;

        if (__tag4 == null ){
            __tag4 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag4);
        }
        __tag4.setPageContext(pageContext);
        __tag4.setParent(null);
        __tag4.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_LABEL_NEXT_PAGE", java.lang.String .class,"key"));
        _activeTag=__tag4;
        __result__tag4 = __tag4.doStartTag();

        if (__result__tag4!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag4== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag4.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag4);
            return true;
        }
        _activeTag=__tag4.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag4);
        __tag4.release();
        return false;
    }

    private boolean _jsp__tag5(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag5 = null ;
        int __result__tag5 = 0 ;

        if (__tag5 == null ){
            __tag5 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag5);
        }
        __tag5.setPageContext(pageContext);
        __tag5.setParent(null);
        __tag5.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_EXCEPTION_WHILE_RENDERING_VIEW", java.lang.String .class,"key"));
        _activeTag=__tag5;
        __result__tag5 = __tag5.doStartTag();

        if (__result__tag5!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag5== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag5.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag5);
            return true;
        }
        _activeTag=__tag5.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag5);
        __tag5.release();
        return false;
    }
}
