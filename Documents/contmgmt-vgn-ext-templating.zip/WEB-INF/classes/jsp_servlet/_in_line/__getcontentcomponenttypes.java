package jsp_servlet._in_line;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.vignette.as.client.common.RequestParameters;
import com.vignette.as.client.exception.ApplicationException;
import com.vignette.as.client.javabean.ContentType;
import com.vignette.as.client.javabean.IPagingList;
import com.vignette.ext.templating.client.javabean.ContentComponent;
import com.vignette.ext.templating.util.SysUtil;
import com.vignette.logging.context.ContextLogger;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class __getcontentcomponenttypes extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/in_line/getContentComponentTypes.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "ISO-8859-1".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n\t\t\t\t<ol>\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\t\t\t\t\t<li>ID: ";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 =", Name: ";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="</li>\n";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    private final static java.lang.String  _wl_block4 ="\n\t\t\t\t</ol>\n";
    private final static byte[]  _wl_block4Bytes = _getBytes( _wl_block4 );

    private final static java.lang.String  _wl_block5 ="\n";
    private final static byte[]  _wl_block5Bytes = _getBytes( _wl_block5 );

    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;

		final ContextLogger logger = ContextLogger.getLogger(SysUtil.LOGGER_PREFIX + request.getServletPath());
		Map allTypes = new HashMap();

		try {
			IPagingList pagingList = ContentType.findAll(RequestParameters.requestParametersTopRelationOnly);
			List contentTypes = pagingList.asList();

			for (Iterator iterator = contentTypes.iterator(); iterator.hasNext();) {
				ContentType contentType = (ContentType) iterator.next();
				String name = contentType.getData().getDisplayName();
				String id = contentType.getData().getName();
				String javaClassName = contentType.getData().getJavaClassName();
				try{
					if ((javaClassName != null) &&
						ContentComponent.class.isAssignableFrom(Class.forName(javaClassName))){	
						allTypes.put(id, name);
					}
				}catch(ClassNotFoundException cnfe){
					if (logger.isDebugEnabled()) {
						logger.debug("getContentComponentTypes.jsp: Could not load the instance for Content Type: " + name);
					}
				}
			}
			request.setAttribute("com.vignette.content_component_types", allTypes);

			if ("yes".equals(request.getParameter("display_list"))) {
				if (allTypes.isEmpty()) {
					// TODO: We need to move this into the message catalog
					out.println("There are no elements to display");
					return;
				}

            bw.write(_wl_block0Bytes, _wl_block0);

				Iterator displayIt = allTypes.keySet().iterator();
				while (displayIt.hasNext()) {
				String id = (String)displayIt.next();
					String name = (String)allTypes.get(id);

            bw.write(_wl_block1Bytes, _wl_block1);
            out.print(id);
            bw.write(_wl_block2Bytes, _wl_block2);
            out.print(name);
            bw.write(_wl_block3Bytes, _wl_block3);

				}

            bw.write(_wl_block4Bytes, _wl_block4);

			}
	
		} catch (ApplicationException e) {

			try {
		
				Exception root = (Exception)e.getRootCause();
				// TODO: We need to move this into the message catalog
				out.println("Exception in getContentComponentTypes.jsp: " + root.getMessage());
				StringWriter stackTraceString = new StringWriter();
				PrintWriter stackTrace = new PrintWriter(stackTraceString);
				root.printStackTrace(stackTrace);
				out.println(stackTraceString.toString());
				return;
			} catch (Throwable t) {
				// TODO: We need to move this into the message catalog
				out.println("Exception in exception in getContentComponentTypes.jsp: " + t.getMessage());
				StringWriter stackTraceString = new StringWriter();
				PrintWriter stackTrace = new PrintWriter(stackTraceString);
				t.printStackTrace(stackTrace);
				out.println(stackTraceString.toString());
				return;
			}
			
		} catch (Throwable root) {
			// TODO: We need to move this into the message catalog
			out.println("Exception in getContentComponentTypes.jsp: " + root.getMessage());
			StringWriter stackTraceString = new StringWriter();
			PrintWriter stackTrace = new PrintWriter(stackTraceString);
			root.printStackTrace(stackTrace);
			out.println(stackTraceString.toString());
			return;
		}

            bw.write(_wl_block5Bytes, _wl_block5);
        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }
}
