package jsp_servlet._views;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.vignette.as.client.javabean.Channel;
import com.vignette.as.client.javabean.ManagedObject;
import com.vignette.ext.templating.client.javabean.ChannelNavComponent;
import com.vignette.ext.templating.client.javabean.ContentComponent;
import com.vignette.ext.templating.client.javabean.ContentSelectComponent;
import com.vignette.ext.templating.client.javabean.QueryContentComponent;
import com.vignette.ext.templating.util.ContentUtil;
import com.vignette.ext.templating.util.RequestContext;
import com.vignette.ext.templating.util.PageUtil;
import com.vignette.ext.templating.util.XSLPageUtil;
import java.util.List;
import com.vignette.ext.link.delivery.ETLDeliveryTranslator;

public final class __sampledisplayview extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/views/sampledisplayview.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "ISO-8859-1".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\t\t";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 ="\n\t\t\t<div class=\"vgn-ext-text\" align=\"center\">\n\t\t\t\t<b>";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="</b>\n\t\t\t\t<br/><br/>\n\t\t\t</div>\n";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    private final static java.lang.String  _wl_block4 ="\n\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t";
    private final static byte[]  _wl_block4Bytes = _getBytes( _wl_block4 );

    private final static java.lang.String  _wl_block5 ="\n\t\t\t\t<br/><br/>\n\t\t\t</div>\n";
    private final static byte[]  _wl_block5Bytes = _getBytes( _wl_block5 );

    private final static java.lang.String  _wl_block6 ="\n\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t<li type=\"square\">\n\t\t\t\t\t<a href=\"";
    private final static byte[]  _wl_block6Bytes = _getBytes( _wl_block6 );

    private final static java.lang.String  _wl_block7 ="\" class=\"vgn-ext-link\" >";
    private final static byte[]  _wl_block7Bytes = _getBytes( _wl_block7 );

    private final static java.lang.String  _wl_block8 =" </a>&nbsp;";
    private final static byte[]  _wl_block8Bytes = _getBytes( _wl_block8 );

    private final static java.lang.String  _wl_block9 ="\n\t\t\t\t</li>\n\t\t\t</div>\n";
    private final static byte[]  _wl_block9Bytes = _getBytes( _wl_block9 );

    private final static java.lang.String  _wl_block10 ="\n\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t<br/>\n\t\t\t\t\t<i>";
    private final static byte[]  _wl_block10Bytes = _getBytes( _wl_block10 );

    private final static java.lang.String  _wl_block11 ="</i>\n\t\t\t\t<br/>\n\t\t\t</div>\n";
    private final static byte[]  _wl_block11Bytes = _getBytes( _wl_block11 );

    private final static java.lang.String  _wl_block12 ="\n\n\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td valign=\"middle\">\n\t\t\t\t\t\t<nobr>\n\t\t\t\t\t\t\t<div class=\"vgn-ext-nav-item\"><b>";
    private final static byte[]  _wl_block12Bytes = _getBytes( _wl_block12 );

    private final static java.lang.String  _wl_block13 ="</b></div>\n\t\t\t\t\t\t</nobr>\n";
    private final static byte[]  _wl_block13Bytes = _getBytes( _wl_block13 );

    private final static java.lang.String  _wl_block14 ="\n\t\t\t\t\t\t\t<nobr>\n\t\t\t\t\t\t\t\t<div class=\"vgn-ext-nav-item\">&nbsp;||&nbsp;<b>";
    private final static byte[]  _wl_block14Bytes = _getBytes( _wl_block14 );

    private final static java.lang.String  _wl_block15 ="</b></div>\n\t\t\t\t\t\t\t</nobr>\n";
    private final static byte[]  _wl_block15Bytes = _getBytes( _wl_block15 );

    private final static java.lang.String  _wl_block16 ="\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t</table>\n";
    private final static byte[]  _wl_block16Bytes = _getBytes( _wl_block16 );

    private final static java.lang.String  _wl_block17 ="\n\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\t\t\t<tr>\n\t\t\t\t<td valign=\"middle\">\n\t\t\t\t\t<nobr>\n\t\t\t\t\t<div class=\"vgn-ext-text\"><b>";
    private final static byte[]  _wl_block17Bytes = _getBytes( _wl_block17 );

    private final static java.lang.String  _wl_block18 ="</b></div>\n\t\t\t\t\t</nobr>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t</table>\n";
    private final static byte[]  _wl_block18Bytes = _getBytes( _wl_block18 );

    private final static java.lang.String  _wl_block19 ="\n\t\t\t\t<div class=\"vgn-ext-text\" align=\"center\">\n\t\t\t\t\t<b>";
    private final static byte[]  _wl_block19Bytes = _getBytes( _wl_block19 );

    private final static java.lang.String  _wl_block20 ="</b>\n\t\t\t\t\t<br/><br/>\n\t\t\t\t</div>\n";
    private final static byte[]  _wl_block20Bytes = _getBytes( _wl_block20 );

    private final static java.lang.String  _wl_block21 ="\n\t\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t\t";
    private final static byte[]  _wl_block21Bytes = _getBytes( _wl_block21 );

    private final static java.lang.String  _wl_block22 ="\n\t\t\t\t\t<br/><br/>\n\t\t\t\t</div>\n";
    private final static byte[]  _wl_block22Bytes = _getBytes( _wl_block22 );

    private final static java.lang.String  _wl_block23 ="\n\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td valign=\"middle\">\n\t\t\t\t\t\t<nobr>\n\t\t\t\t\t\t\t<div class=\"vgn-ext-text\">";
    private final static byte[]  _wl_block23Bytes = _getBytes( _wl_block23 );

    private final static java.lang.String  _wl_block24 ="</div>\n\t\t\t\t\t\t</nobr>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n";
    private final static byte[]  _wl_block24Bytes = _getBytes( _wl_block24 );

    private final static java.lang.String  _wl_block25 ="\n\t\t\t\t<div class=\"vgn-ext-text\">\n\t\t\t\t\t<br/>\n\t\t\t\t\t\t<i>";
    private final static byte[]  _wl_block25Bytes = _getBytes( _wl_block25 );

    private final static java.lang.String  _wl_block26 ="</i>\n\t\t\t\t\t<br/>\n\t\t\t\t</div>\n";
    private final static byte[]  _wl_block26Bytes = _getBytes( _wl_block26 );

    private final static java.lang.String  _wl_block27 ="\n\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td valign=\"middle\">\n\t\t\t\t\t\t<nobr>\n\t\t\t\t\t\t\t<img src=\'";
    private final static byte[]  _wl_block27Bytes = _getBytes( _wl_block27 );

    private final static java.lang.String  _wl_block28 ="\' title=\'Image\' border=\'0\' align=\'center\' />\n\t\t\t\t\t\t</nobr>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n";
    private final static byte[]  _wl_block28Bytes = _getBytes( _wl_block28 );

    private final static java.lang.String  _wl_block29 ="\n\t\t\t";
    private final static byte[]  _wl_block29Bytes = _getBytes( _wl_block29 );

    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
             org.apache.taglibs.i18n.BundleTag __tag0 = null ;
            int __result__tag0 = 0 ;

            if (__tag0 == null ){
                __tag0 = new  org.apache.taglibs.i18n.BundleTag ();
                weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
            }
            __tag0.setPageContext(pageContext);
            __tag0.setParent(null);
            __tag0.setBaseName(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("com.vignette.ext.templating.TemplatingJSPMsgs", java.lang.String .class,"baseName"));
            __tag0.setLocale( request.getLocale() 
);
            _activeTag=__tag0;
            __result__tag0 = __tag0.doStartTag();

            if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
                if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                     throw  new  javax.servlet.jsp.JspTagException("Since tag class org.apache.taglibs.i18n.BundleTag does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
                }
            }
            if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
                _activeTag = null;
                _releaseTags(pageContext, __tag0);
                return;
            }
            _activeTag=__tag0.getParent();
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
            __tag0.release();
            bw.write(_wl_block0Bytes, _wl_block0);

	/**
	 * This sample JSP is used to render views for all Content Components. This is to demonstrate the functionality of 
	 * Display View. Users can extend this JSP to customize their views.
	 */
	RequestContext rc = PageUtil.getCurrentRequestContext(pageContext);
	ManagedObject mo = null;
	try{
		mo = rc.getRenderedManagedObject();
	}catch(Exception ex){
		// indicate that the following output shouldnt be cached.
		rc.setNoCache(true);

            bw.write(_wl_block1Bytes, _wl_block1);

            if (_jsp__tag1(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block0Bytes, _wl_block0);

	}
	// Render QueryContentComponent results
	if (mo instanceof QueryContentComponent) {
		QueryContentComponent queryContentComponent = (QueryContentComponent) mo;
		if (queryContentComponent.getTitle() != null) {

            bw.write(_wl_block2Bytes, _wl_block2);
            out.print(queryContentComponent.getTitle());
            bw.write(_wl_block3Bytes, _wl_block3);

		}
		if (queryContentComponent.getHeader() != null) {

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print(queryContentComponent.getHeader());
            bw.write(_wl_block5Bytes, _wl_block5);

		}
		List results = queryContentComponent.getResults(rc);
			for (int i = 0; i < results.size(); i++) {
				ManagedObject managedObject = (ManagedObject)results.get(i);
				String linkURI = XSLPageUtil.buildLinkURI(rc, managedObject.getContentManagementId().toString(), "", "");
				String inContext = XSLPageUtil.displayInContextEditing(rc, managedObject.getContentManagementId().toString());

            bw.write(_wl_block6Bytes, _wl_block6);
            out.print(linkURI);
            bw.write(_wl_block7Bytes, _wl_block7);
            out.print(managedObject.getName());
            bw.write(_wl_block8Bytes, _wl_block8);
            out.print(inContext);
            bw.write(_wl_block9Bytes, _wl_block9);

			}
		if (queryContentComponent.getFooter() != null) {

            bw.write(_wl_block10Bytes, _wl_block10);
            out.print(queryContentComponent.getFooter());
            bw.write(_wl_block11Bytes, _wl_block11);

		}
	// Render ChannelNavComponent results, Limited information (only the top level channel information) 
	// is being displayed here. Users may have to extend this JSP to customize their views. 
	} else if (mo instanceof ChannelNavComponent) {

		ChannelNavComponent channelNavComponent = (ChannelNavComponent) mo;
		if (channelNavComponent.getTitle() != null) {

            bw.write(_wl_block2Bytes, _wl_block2);
            out.print(channelNavComponent.getTitle());
            bw.write(_wl_block3Bytes, _wl_block3);

		}
		if (channelNavComponent.getHeader() != null) {

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print(channelNavComponent.getHeader());
            bw.write(_wl_block5Bytes, _wl_block5);

		}
		Channel channel = rc.getRequestedChannel();
		if (channel != null) {

            bw.write(_wl_block12Bytes, _wl_block12);
            out.print(channel.getData().getName());
            bw.write(_wl_block13Bytes, _wl_block13);

						Channel subChannels[] = ContentUtil.getSubchannels(channel);
						for (int counter = 0; counter < subChannels.length; counter++) {

            bw.write(_wl_block14Bytes, _wl_block14);
            out.print((subChannels[counter]).getData().getName());
            bw.write(_wl_block15Bytes, _wl_block15);

		}

            bw.write(_wl_block16Bytes, _wl_block16);

		}
		if (channelNavComponent.getFooter() != null) {

            bw.write(_wl_block10Bytes, _wl_block10);
            out.print(channelNavComponent.getFooter());
            bw.write(_wl_block11Bytes, _wl_block11);

		}
	// Render ContentSelectComponent results
	} else if (mo instanceof ContentSelectComponent) {

		ContentSelectComponent contentSelectComponent = (ContentSelectComponent) mo;
		if (contentSelectComponent.getTitle() != null) {

            bw.write(_wl_block2Bytes, _wl_block2);
            out.print(contentSelectComponent.getTitle());
            bw.write(_wl_block3Bytes, _wl_block3);

		}
		if (contentSelectComponent.getHeader() != null) {

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print(contentSelectComponent.getHeader());
            bw.write(_wl_block5Bytes, _wl_block5);

		}
		ManagedObject referencedManagedObject = (ManagedObject)contentSelectComponent.getReferencedItem(rc);

            bw.write(_wl_block17Bytes, _wl_block17);
            out.print(referencedManagedObject.getName());
            bw.write(_wl_block18Bytes, _wl_block18);

		if (contentSelectComponent.getFooter() != null) {

            bw.write(_wl_block10Bytes, _wl_block10);
            out.print(contentSelectComponent.getFooter());
            bw.write(_wl_block11Bytes, _wl_block11);

		}
	// Render ImageComponent/Textblock results
	} else {
		ContentComponent contentComponent = (ContentComponent) mo;

		String title = contentComponent.getTitle();
		String header = contentComponent.getHeader();
		String footer = contentComponent.getFooter();

		if (mo.getObjectType().getData().getName().equals("VgnExtTextBlock")) {
			Object textValue = contentComponent.getAttributeValue("text");
			String content = textValue == null ? "" : textValue.toString();
			ETLDeliveryTranslator etlDeliveryTranslator = new ETLDeliveryTranslator();
			content = etlDeliveryTranslator.translate(content, rc);

			if (title != null) {

            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(title);
            bw.write(_wl_block20Bytes, _wl_block20);

			}
			if (header != null) {

            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(header);
            bw.write(_wl_block22Bytes, _wl_block22);

			}

            bw.write(_wl_block23Bytes, _wl_block23);
            out.print(content);
            bw.write(_wl_block24Bytes, _wl_block24);

			if (footer != null) {

            bw.write(_wl_block25Bytes, _wl_block25);
            out.print(footer);
            bw.write(_wl_block26Bytes, _wl_block26);

			}
		} else if (mo.getObjectType().getData().getName().equals("VgnExtImage")) {
			String imgObject = contentComponent.getAttributeValue("image").toString();
			String staticFilePath = com.vignette.ext.templating.util.PageUtil.getStaticFilePath(imgObject, rc);
			if (title != null) {

            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(title);
            bw.write(_wl_block20Bytes, _wl_block20);

			}
			if (header != null) {

            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(header);
            bw.write(_wl_block22Bytes, _wl_block22);

			}

            bw.write(_wl_block27Bytes, _wl_block27);
            out.print(staticFilePath);
            bw.write(_wl_block28Bytes, _wl_block28);

			if (footer != null) {

            bw.write(_wl_block25Bytes, _wl_block25);
            out.print(footer);
            bw.write(_wl_block26Bytes, _wl_block26);

			}
		} else {

            bw.write(_wl_block29Bytes, _wl_block29);

            if (_jsp__tag2(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block0Bytes, _wl_block0);

		}
	}

        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag1(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag1 = null ;
        int __result__tag1 = 0 ;

        if (__tag1 == null ){
            __tag1 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag1);
        }
        __tag1.setPageContext(pageContext);
        __tag1.setParent(null);
        __tag1.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_EXCEPTION_WHILE_RENDERING_VIEW", java.lang.String .class,"key"));
        _activeTag=__tag1;
        __result__tag1 = __tag1.doStartTag();

        if (__result__tag1!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag1== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag1.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag1);
            return true;
        }
        _activeTag=__tag1.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag1);
        __tag1.release();
        return false;
    }

    private boolean _jsp__tag2(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.i18n.MessageTag __tag2 = null ;
        int __result__tag2 = 0 ;

        if (__tag2 == null ){
            __tag2 = new  org.apache.taglibs.i18n.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag2);
        }
        __tag2.setPageContext(pageContext);
        __tag2.setParent(null);
        __tag2.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("VGN_EXT_EXCEPTION_WHILE_RENDERING_VIEW", java.lang.String .class,"key"));
        _activeTag=__tag2;
        __result__tag2 = __tag2.doStartTag();

        if (__result__tag2!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag2== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag2.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag2);
            return true;
        }
        _activeTag=__tag2.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag2);
        __tag2.release();
        return false;
    }
}
