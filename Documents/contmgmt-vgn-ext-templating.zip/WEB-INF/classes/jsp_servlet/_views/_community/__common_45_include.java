package jsp_servlet._views._community;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.vignette.as.client.exception.ApplicationException;
import com.vignette.as.client.javabean.Channel;
import com.vignette.as.client.javabean.ContentInstance;
import com.vignette.as.client.javabean.ManagedObject;
import com.vignette.community.client.services.common.NativeObject;
import com.vignette.community.client.services.common.RemoteObjectEntity;
import com.vignette.community.client.services.common.XAPIConstants;
import com.vignette.community.client.services.dataservice.*;
import com.vignette.community.client.services.exceptions.CCSConnectionException;
import com.vignette.config.client.common.ConfigException;
import com.vignette.ext.templating.util.ContentUtil;
import com.vignette.ext.templating.util.RequestContext;
import org.xml.sax.SAXException;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import com.vignette.ext.templating.client.javabean.ContentComponent;
import com.vignette.ext.templating.client.javabean.Page;
import com.vignette.ext.templating.util.TemplatingUtil;
import com.vignette.logging.context.ContextLogger;
import com.vignette.logging.LoggingManager;
import java.util.*;
import com.vignette.ext.templating.mvc.Constants;
import com.vignette.ext.templating.community.service.CommunityService;
import com.vignette.ext.templating.community.util.CommunityComponentQueryUtils;
import com.vignette.ext.templating.community.util.CommunityComponentConstants;
import com.vignette.util.StringUtil;

public final class __common_45_include extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/views/community/common-include.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "ISO-8859-1".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\n";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    ContextLogger commonlogger = LoggingManager.getContextLogger( this.getClass());


    private static final String PROP_SOCIAL_SITE_NAME = "repository.<repositoryname>.community.name";
    private static final String PROP_SOCIAL_SITE_URL_PREFIX = "repository.<repositoryname>.community.url.prefix";
    private static final String DEFAULT_SOCIAL_SITE_NAME = "socialmedia";
    private static final String PROP_SOCIAL_REPOSITORY_ADMIN_NAME = "repository.<repositoryname>.user";
    private static final String PROP_SOCIAL_REPOSITORY_HOST_NAME = "repository.<repositoryname>.hostName";
    private static final String PROP_SOCIAL_SITE_APP_RESOLVER = "repository.<repositoryname>.community.app.resolver";
    private static final String DEFAULT_SOCIAL_SITE_APP_RESOLVER = "/vca";

    static Map VCA_SOCIAL_APPLICATION_TEMPLATE_MAP = new HashMap();
    // Community Applications templates
    static {
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("blog", "community_applications_blog_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("wiki", "community_applications_wiki_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("photolibrary", "community_applications_photo_library_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("videolibrary", "community_applications_video_library_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("forum", "community_applications_forum_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("podcastlibrary", "community_applications_podcast_library_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("calendar", "community_applications_calendar_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("idealibrary", "community_applications_idea_library_template");
        VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.put("flashlibrary", "community_applications_flash_library_template");
    }

    static final String SYSTEM_TYPE = "VCM";
    static final String SYSTEM_ID = "2";
    static final String SINGLE_SLASH = "/";
    static final String VCA_APP_RESOLVER = "/resolver.vcarp";
    static final String CC_CONTEXT_ATTRIBUTE = "vgnExtSocialComponentContext";
    static final String CC_NAME_ATTRIBUTE = "vgnExtSocialComponentName";
    static final String CC_CONTEXTTYPE_ATTRIBUTE = "vgnExtSocialComponentContextType";
    static final String CC_OBJECT_ID_ATTRIBUTE = "vgnExtSocialComponentIdentifier";
    static final String CC_REALM_ATTRIBUTE = "vgnExtSocialComponentRealm";
    static final String CC_SOCIAL_APPTYPE_ATTRIBUTE = "vgnExtSocialComponentAppType";
    static final String CC_SOCIAL_SERVICE_APPTYPE_ATTRIBUTE = "vgnExtSocialComponentServiceType";
    static final String CC_SOCIAL_REPOSITORY_ATTRIBUTE = "vgnExtSocialComponentRepository";
    static final String CC_SOCIAL_STRATEGY_ATTRIBUTE = "vgnExtSocialComponentStrategy";
    static final String CC_SOCIAL_MANUAL_OBJECT_ID_ATTRIBUTE = "vgnExtSocialComponentManualObjectId";
    static final String STRATEGY_ATTRIBUTE_VALUE_AUTOMATIC = "automatic";
    static final String STRATEGY_ATTRIBUTE_VALUE_NONE = "none";
    static final String STRATEGY_TYPE_VCM = "vcm-strategy";
    static final String STRATEGY_TYPE_MANUAL = "manual";
    static final String CC_TEMPLATE_PARAMS_ATTRIBUTE = "vgnExtTemplatingComponentParameters";
	static final String COMMA_SEPARATOR = ",";

	/**
     * Method to get the Social Portal site name to create the link.
     * @return socialSiteName the name of the Social Site
     * @throws IOException
     * @throws ConfigException
     */
    public String getSocialSiteName(Properties repositoryConfig, String repositoryId) throws IOException, ConfigException {
        String socialSiteName = repositoryConfig.getProperty(PROP_SOCIAL_SITE_NAME.replaceAll("<repositoryname>", repositoryId));
        if(commonlogger.isInfoEnabled()) {
            commonlogger.info("Social Site Name is " + socialSiteName);
        }
        return (null == socialSiteName || ("".equals(socialSiteName))) ? DEFAULT_SOCIAL_SITE_NAME : socialSiteName;
    }

    /**
     * Method to get the Social site URL prefix
     * @return social site url
     * @throws IOException
     * @throws ConfigException
     */
    public String getSocialSitePrefix(Properties repositoryConfig, String repositoryId) throws IOException, ConfigException {
        return repositoryConfig.getProperty(PROP_SOCIAL_SITE_URL_PREFIX.replaceAll("<repositoryname>", repositoryId));
    }

    /**
     * Method to get the Social site Resolver
     * @return siteAppResolver
     * @throws IOException
     * @throws ConfigException
     */
    public String getSocialSiteAppResolver(Properties repositoryConfig, String repositoryId) throws IOException, ConfigException {
        String appResolver = repositoryConfig.getProperty(PROP_SOCIAL_SITE_APP_RESOLVER.replaceAll("<repositoryname>", repositoryId));
        if (null == appResolver || "".equals(appResolver)) {
            appResolver = DEFAULT_SOCIAL_SITE_APP_RESOLVER;
        }
        if(commonlogger.isInfoEnabled()) {
            commonlogger.info("Social Site App Resolver is " + appResolver);
        }
        return appResolver;
    }

    /**
     * Method to get the Admin user name from the Generic Resource
     * @param repositoryId
     * @return adminUserName
     * @throws IOException
     * @throws ConfigException
     */
    public String getRepositoryAdminUserName(String repositoryId) throws IOException, ConfigException {
        String adminKey = PROP_SOCIAL_REPOSITORY_ADMIN_NAME.replaceAll("<repositoryname>", repositoryId);
        if(commonlogger.isInfoEnabled()) {
            commonlogger.info("Admin Key " + adminKey);
        }
        return CommunityService.getSocialRepositoryConfig().getProperty(adminKey);
    }

    /**
     * Method to get the Repository Host name from Generic Resource
     * @param repositoryId
     * @return
     * @throws IOException
     * @throws ConfigException
     */
    public String getRepositoryHostName(String repositoryId) throws IOException, ConfigException {
        String repositoryKey = PROP_SOCIAL_REPOSITORY_HOST_NAME.replaceAll("<repositoryname>", repositoryId);
        return CommunityService.getSocialRepositoryConfig().getProperty(repositoryKey);
    }

    /**
     * Method to get the Remote object from the Context information passed from the Content Component
     * The remote object creation includes the domain param
     * @param rc RequestContext
     * @param realm
     * @param objectid
     * @param context
     * @param contentType
     * @param repository
     * @return remoteObject
     * @throws ApplicationException
     * @throws IOException
     * @throws ConfigException
     */
    public RemoteObjectEntity getRemoteObject(RequestContext rc, String realm, String objectid,
                                              String context, String contentType, String repository, String domain)
                                              throws ApplicationException, IOException, ConfigException {
        String currentSiteName = null;
        String renderedPrimaryObjectID = null;
        String channelName = null;
        String type = null;
        ManagedObject renderedPrimaryObject = rc.getPrimaryRequestedObject();
        Channel renderedChannel = rc.getRequestedChannel();
        boolean isDomainIncluded = false;
        RemoteObjectEntity ro = null;
        String extSystemType = null;
        String extSystemId = null;

        if (null != renderedChannel) {
            channelName = renderedChannel.getName();
        }
        if (rc.getCurrentSite() != null) {
            currentSiteName = rc.getCurrentSite().getName();
        }
        if (null != renderedPrimaryObject) {
            renderedPrimaryObjectID = renderedPrimaryObject.getContentManagementId().getId();

            if (renderedPrimaryObject instanceof ContentInstance) {
                type = renderedPrimaryObject.getObjectType().getData().getName();

				if (type != null && "VgnExtPage".equalsIgnoreCase(type)) {
				   type = "Channel";
				   // this is a page, change the rendered obj to channel instead.
					renderedPrimaryObjectID = ((Page)renderedPrimaryObject).getId();
				}else{
					if (null == channelName || "VgnExtTemplating".equals(channelName)) {
						// If the channel name is VgnExtTemplating then try to get the first channel of the Content instance
						channelName = ContentUtil.getFirstChannelByContentInstance(rc.getCurrentSite(),
								(ContentInstance) renderedPrimaryObject).getName();
					}
				}
			}
        }
        objectid = renderedPrimaryObjectID; // For VCM Strategy, we will always have the rendered object id
        if (StringUtil.isEmpty(realm) || STRATEGY_ATTRIBUTE_VALUE_AUTOMATIC.equalsIgnoreCase(realm)) {
            realm = currentSiteName;
        }
        if (StringUtil.isEmpty(context) || STRATEGY_ATTRIBUTE_VALUE_AUTOMATIC.equalsIgnoreCase(context)) {
            context = channelName;
        }
        if (StringUtil.isEmpty(contentType) || STRATEGY_ATTRIBUTE_VALUE_AUTOMATIC.equalsIgnoreCase(contentType)){
            contentType = type;
        }
        if(commonlogger.isDebugEnabled()) {
            commonlogger.debug("Context " + context);
            commonlogger.debug("realm " + realm);
            commonlogger.debug("contentType " + contentType);
        }
        //this check is introduced to include the domain attribute in the RO creation, for supporting the collab 8.1
        if(repository != null) {
            isDomainIncluded = CommunityComponentQueryUtils.isDomainUsedForROCreation(repository);
            extSystemId = CommunityComponentQueryUtils.getExternalSystemId(repository);
            extSystemType = CommunityComponentQueryUtils.getExternalSystemType(repository);
        }
        extSystemId = StringUtil.isEmpty(extSystemId) ? SYSTEM_ID : extSystemId;
        extSystemType = StringUtil.isEmpty(extSystemType) ? SYSTEM_TYPE : extSystemType;

        if (commonlogger.isDebugEnabled()) {
            commonlogger.debug("the value of domain inclusion is " + isDomainIncluded + " for repository  " + repository);
            commonlogger.debug("the extSystemId is " + extSystemId + " for repository  " + repository);
            commonlogger.debug("the extSystemType is " + extSystemType + " for repository  " + repository);
        }


        if(isDomainIncluded){
            ro = new  RemoteObjectEntity(objectid, // obj id
                    context,  // context
                    extSystemType, // system type(),
                    extSystemId,  //system id,
                    realm, //realm
                    contentType,
                    domain,
                    "");
        }else{
            ro = new RemoteObjectEntity(objectid, // obj id
                    context,  // context
                    extSystemType, // system type(),
                    extSystemId,  //system id,
                    realm, //realm
                    contentType);//content type
        }
        return ro;
    }

    /**
     * Method to get the Remote object from the Context information passed from the Content Component
     * @param rc RequestContext
     * @param realm
     * @param objectid
     * @param context
     * @param contentType
     * @param repository
     * @return remoteObject
     * @throws ApplicationException
     * @throws IOException
     * @throws ConfigException
     */
    public RemoteObjectEntity getRemoteObject(RequestContext rc, String realm, String objectid,
                                              String context, String contentType, String repository)
                                              throws ApplicationException, IOException, ConfigException {
    return getRemoteObject(rc, realm, objectid,
                context, contentType, repository, null);
    }

    /**
     * Method to retrieve the Remote Object OID given the RequestContext and the Strategy attribute values.
     * @param rc
     * @param realm
     * @param objectid
     * @param context
     * @param contentType
     * @param repository
     * @param appType
     * @return
     * @throws XPathExpressionException
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     * @throws ConfigException
     * @throws ApplicationException
     */
    public String getAppInstanceOID(RequestContext rc, String realm, String objectid,
                                    String context, String contentType, String repository, String appType, String domain)
                                        throws XPathExpressionException, ParserConfigurationException,
                                                IOException, SAXException, ConfigException, ApplicationException, CCSConnectionException {
        // Query for the application instance for the current RO
        Query nQuery;
        String queryData = null;
        String oidValue = null;
        RemoteObjectEntity completeRO = getRemoteObject(rc, realm, objectid,
                context, contentType, repository, domain);
        NativeObject nativeObject = new NativeObject(completeRO,
                appType,
                null);
        nQuery = new NativeObjectQuery(nativeObject);
        CommunityDataServiceIf dservice = CommunityService.getInstance().getCommunityDataServiceAsAdmin(repository, getRepositoryAdminUserName(repository));// repositoryid
        Response resp = dservice.query(nQuery);

        if (resp != null) {
            if (resp.getResponseCode() == HttpServletResponse.SC_OK) {
                if(commonlogger.isInfoEnabled()) {
                    commonlogger.info("*** Remote Object found. Check the name is consistent or not");
                }
                // Parse the XML and extract the matching ROs.
                queryData = resp.getData();
                if(commonlogger.isInfoEnabled()) {
                    commonlogger.info("***queryData ::\n"+queryData);
                }
                // Check if the current component name is same as in collab or not. If not update in collab
                String collabAppName = CommunityComponentQueryUtils.getNodeValue(queryData, XAPIConstants.NameFieldName);
                String currentAppName = getAppName(rc);

                if(commonlogger.isInfoEnabled()) {
                    commonlogger.info("**** collabAppName:: "+collabAppName +"  currentAppName:: "+currentAppName);
                }
                if(collabAppName != null && !collabAppName.equals(currentAppName)) {
                    String oID = CommunityComponentQueryUtils.getNodeValue(queryData, XAPIConstants.OID);
                    if(commonlogger.isInfoEnabled()) {
                        commonlogger.info("**** app name changed.. so changing it in collab. oID :: "+oID);
                    }
                    int status =  CommunityComponentQueryUtils.updateRemoteObjectName(dservice, oID, currentAppName);
                    if(commonlogger.isInfoEnabled()) {
                        commonlogger.info("**** status:: "+status);
                    }
                    if(status != HttpServletResponse.SC_MOVED_PERMANENTLY) {
                        commonlogger.error("**** Failed to update the remote object");
                    }
                }
            } else if (resp.getResponseCode() == HttpServletResponse.SC_NO_CONTENT) {
                if(commonlogger.isInfoEnabled()) {
                    commonlogger.info("*** Remote Object not found. So creating new RO");
                }

                ManagedObject mo = rc.getRenderedManagedObject();
                String managerEmailAddress="";
                if (mo instanceof ContentComponent) {
                    Map componentParamsMap = TemplatingUtil.stringToMap((String) mo.getAttributeValue(CC_TEMPLATE_PARAMS_ATTRIBUTE));
                    // Firstcheck in advanced params
                    managerEmailAddress = (componentParamsMap != null)? (String) componentParamsMap.get(CommunityComponentConstants.PROP_MANAGER_EMAIL):"";
                    if(commonlogger.isDebugEnabled()) {
                        commonlogger.debug("*** "+ CommunityComponentConstants.PROP_MANAGER_EMAIL +" key value from advanced params : "+managerEmailAddress);
                    }

                    if(CommunityComponentQueryUtils.isNullOrEmpty(managerEmailAddress)) {
                        // Lets get this value from config console
                        managerEmailAddress = CommunityComponentQueryUtils.getManagerEmailAddress(repository);
                        if(commonlogger.isDebugEnabled()) {
                            commonlogger.debug("*** managerEmailAddress from config console : "+managerEmailAddress);
                        }
                    }
                }

                if(commonlogger.isInfoEnabled()) {
                    commonlogger.info("*** Finally using managerEmailAddress:: "+managerEmailAddress);
                }
                // If the application Instance is not found, just create a application Instance
                String appName = getAppName(rc);
                ApplicationCreateAction createAct = new ApplicationCreateAction(completeRO,
                        appType,
                        (String) VCA_SOCIAL_APPLICATION_TEMPLATE_MAP.get(appType),
                        managerEmailAddress,
                        appName,
                        false);
                Response createResp = dservice.execute(createAct, null);
                if (createResp != null) {
                    resp = dservice.query(nQuery);

                    if (resp != null) {
						queryData = resp.getData();
                    }
                }
            }

			updateWithSiteContext(rc, dservice, resp, domain, realm);
			if (queryData != null) {
                oidValue = CommunityComponentQueryUtils.getNodeValue(queryData, XAPIConstants.OID);
            }
        }
        if(commonlogger.isInfoEnabled()) {
            commonlogger.info("*** returning oID :: "+oidValue);
        }
        return oidValue;
    }

    /**
     * Method to return the component name
     * @param rc
     * @return
     * @throws ApplicationException
     */
    public String getAppName(RequestContext rc) throws ApplicationException{
        ManagedObject mo = rc.getRenderedManagedObject();
        String appName = (String) mo.getAttributeValue(CC_NAME_ATTRIBUTE);
        if(commonlogger.isInfoEnabled()) {
            commonlogger.info("*** in getAppName  appName :: "+appName);
        }
        if(appName == null || "".equals(appName)) {
            ManagedObject renderedPrimaryObject = rc.getPrimaryRequestedObject();
            if(renderedPrimaryObject !=  null) {
                appName = renderedPrimaryObject.getName();
                if(commonlogger.isInfoEnabled()) {
                   commonlogger.info("*** in getAppName - renderedPrimaryObject.getName() :: "+appName);
                }
            }
        }
        return appName;
    }

    /**
     * Method to return the local type to build the social site url given the remote type
     * @param remoteType
     * @return remoteType
     */
    public String getLocalType(String remoteType) {
        if ("flashlibrary".equalsIgnoreCase(remoteType)) {
            return "presentationlibrary";
        } else {
            return remoteType;
        }
    }

    /**
     * Method to return the local type to build the social site url given the remote type
     * @param localType
     * @return imageName
     */
    public String getImageName(String localType) {
        String imageName="";
          if("blog".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_BLOG_ARTICLE.equals(localType)){
              imageName="blog64_b24";
          }else if("wiki".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_WIKI_PAGE.equals(localType)){
              imageName="wiki64_b24";
          }else if("photolibrary".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_PHOTO.equals(localType)){
              imageName="photo64_b24";
          }else if("videolibrary".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_VIDEO.equals(localType)){
              imageName="video64_b24";
          }else if("forum".equalsIgnoreCase(localType)){
              imageName="forum64_b24";
          }else if("podcastlibrary".equalsIgnoreCase(localType)){
              imageName="podcast64_b24";
          }else if("calendar".equalsIgnoreCase(localType)){
              imageName="event64_b24";
          }else if("idealibrary".equalsIgnoreCase(localType)){
              imageName="ideas64_b24";
          }else if("presentationlibrary".equalsIgnoreCase(localType)){
              imageName="presentation64_b24";
          }
         return imageName;
    }

    /**
     * Method to get the current site name
     * @param rc
     * @return current site name
     * @throws ApplicationException
     */
    public String getCurrentSiteName(RequestContext rc) throws ApplicationException{
        if (rc.getCurrentSite() != null) {
            return rc.getCurrentSite().getName();
        }
        return null;
    }

    /**
     * Method to get the rendered channel name
     * @param rc
     * @return channel name
     * @throws ApplicationException
     */
    public String getRenderedChannelName(RequestContext rc) throws ApplicationException {
        String channelName="";
        Channel renderedChannel = rc.getRequestedChannel();
        ManagedObject renderedPrimaryObject = rc.getPrimaryRequestedObject();
        if (null != renderedChannel) {
            channelName = renderedChannel.getName();
        }
        if (null != renderedPrimaryObject) {
            if (renderedPrimaryObject instanceof ContentInstance) {
                if (null == channelName || "VgnExtTemplating".equals(channelName)) {
                    // If the channel name is VgnExtTemplating then try to get the first channel of the Content instance
                    channelName = ContentUtil.getFirstChannelByContentInstance(rc.getCurrentSite(),
                            (ContentInstance) renderedPrimaryObject).getName();
                }
            }
        }
        return channelName;
    }

	/**
	 *
	 * @param keyword
	 * @param repository
	 * @param siteContext
	 * @param types
	 * @return response string
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 * @throws ConfigException
	 * @throws ApplicationException
	 */

	public String getSearchResults(String keyword, String repository, String siteContext, String types, int startIndex, int resultsPerPage) throws XPathExpressionException, ParserConfigurationException,
			IOException, SAXException, ConfigException, ApplicationException, CCSConnectionException {

		CommunityDataServiceIf dservice = CommunityService.getInstance().getCommunityDataServiceAsAdmin(repository, getRepositoryAdminUserName(repository));// repositoryid

		Query nQuery = new BasicQuery(XAPIConstants.ObjectFieldName + "/"+ XAPIConstants.SEARCH + "/");
		nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_KEYWORD_PARAM, keyword);
		if(siteContext != null && !siteContext.equals("")) {
			nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_SITE_CONTEXT_PARAM, siteContext);
			nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_SITE_CONTEXT_FIELD_PARAM, "ITS_site_context");
			//nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_SITE_CONTEXT_OPERATOR_PARAM, "any");
		}
		if(types != null && !types.equals("")) {
			nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_INSTANCE_OF_PARAM, types);
			nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_INSTANCE_OF_FIELD_PARAM, "ITS_instance_of");
			nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_INSTANCE_OF_OPERATOR_PARAM, "any");
		}
		nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_MAX_HITS, Integer.toString(resultsPerPage));
		nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_START_INDEX_PARAM, Integer.toString(startIndex));
		nQuery.addAdditionalParam(CommunityComponentConstants.SEARCH_TRUE_PARAM, "true");
		Response resp = dservice.query(nQuery)  ;

		return resp.getData();

	}


	/**
	 * Returns the types param that needs to be set in the query to get the search results
	 * @param types string from dv
	 * @return types param for query
	 */
	public String getTypesParam(String types) {
		StringBuffer result = new StringBuffer();
		StringTokenizer st = null;
		if(types != null && types.length() >0) {
			st = new StringTokenizer(types, ";");
		}
		if(st != null && st.countTokens() > 0) {
			while(st.hasMoreTokens()){
				String token = st.nextToken();
				if(token.equalsIgnoreCase(CommunityComponentConstants.TYPE_BLOG)){
					result.append(CommunityComponentConstants.CTD_TYPE_BLOG);
					result.append(COMMA_SEPARATOR);
					result.append(CommunityComponentConstants.CTD_TYPE_BLOG_ARTICLE);
					result.append(COMMA_SEPARATOR);

				} else if(token.equalsIgnoreCase(CommunityComponentConstants.TYPE_WIKI)){
					result.append(CommunityComponentConstants.CTD_TYPE_WIKI);
					result.append(COMMA_SEPARATOR);
					result.append(CommunityComponentConstants.CTD_TYPE_WIKI_PAGE);
					result.append(COMMA_SEPARATOR);

				} else if(token.equalsIgnoreCase(CommunityComponentConstants.TYPE_PHOTO)){
					result.append(CommunityComponentConstants.CTD_TYPE_PHOTO_LIBRARY);
					result.append(COMMA_SEPARATOR);
					result.append(CommunityComponentConstants.CTD_TYPE_PHOTO);
					result.append(COMMA_SEPARATOR);

				} else if(token.equalsIgnoreCase(CommunityComponentConstants.TYPE_VIDEO)){
					result.append(CommunityComponentConstants.CTD_TYPE_VIDEO_LIBRARY);
					result.append(COMMA_SEPARATOR);
					result.append(CommunityComponentConstants.CTD_TYPE_VIDEO);
					result.append(COMMA_SEPARATOR);

				}
			} } else {
			result.append(CommunityComponentConstants.CTD_TYPE_BLOG);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_BLOG_ARTICLE);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_WIKI);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_WIKI_PAGE);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_PHOTO_LIBRARY);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_PHOTO);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_VIDEO_LIBRARY);
			result.append(COMMA_SEPARATOR);
			result.append(CommunityComponentConstants.CTD_TYPE_VIDEO);
			result.append(COMMA_SEPARATOR);
		}
		return result.toString();
	}


	/**
	 * Returns the app type depending upon the instance type
	 * @param instanceOf
	 * @return appType
	 */
	// To Do: should be moved into a static map
	public String getAppType(String instanceOf){

		if (CommunityComponentConstants.CTD_TYPE_BLOG.equalsIgnoreCase(instanceOf)) {
			return CommunityComponentConstants.TYPE_BLOG;
		} else if(CommunityComponentConstants.CTD_TYPE_BLOG_ARTICLE.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_BLOG_ARTICLE;
		} else if(CommunityComponentConstants.CTD_TYPE_WIKI.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_WIKI;
		} else if(CommunityComponentConstants.CTD_TYPE_WIKI_PAGE.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_WIKI_PAGE;
		} else if(CommunityComponentConstants.CTD_TYPE_PHOTO_LIBRARY.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_PHOTO_LIBRARY;
		} else if(CommunityComponentConstants.CTD_TYPE_PHOTO.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_PHOTO;
		} else if(CommunityComponentConstants.CTD_TYPE_VIDEO_LIBRARY.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_VIDEO_LIBRARY;
		} else if(CommunityComponentConstants.CTD_TYPE_VIDEO.equalsIgnoreCase(instanceOf)) {
			return  CommunityComponentConstants.TYPE_VIDEO;
		}
		return null;
	}

	/**
	 * Returns the parent type for the localType
	 * @param localType
	 * @return parentType
	 */
	// To Do: should be moved into a static map
	public String getParentType(String localType) {
		if(localType.equalsIgnoreCase(CommunityComponentConstants.TYPE_BLOG_ARTICLE)){
			return CommunityComponentConstants.TYPE_BLOG;
		} else if(localType.equalsIgnoreCase(CommunityComponentConstants.TYPE_WIKI_PAGE)){
			return CommunityComponentConstants.TYPE_WIKI;
		} else if(localType.equalsIgnoreCase(CommunityComponentConstants.TYPE_PHOTO)){
			return CommunityComponentConstants.TYPE_PHOTO_LIBRARY;
		} else if(localType.equalsIgnoreCase(CommunityComponentConstants.TYPE_VIDEO)){
			return CommunityComponentConstants.TYPE_VIDEO_LIBRARY;
		}
		return null;
	}

	/**
	 * Updates the site context of an object retrieved from XAPI response content.
	 * This method needs to be called to set the site context value (to enable the object
	 * to be indexed with the site context value.
	 * @param privilegedService community data serivce with privileged user context
	 * @param responseContent response xml content received from XAPI call
	 * @param domain current domain
	 * @param site current site
	 */
	public void updateWithSiteContext(RequestContext rc, CommunityDataServiceIf privilegedService, Response responseContent, String domain, String site) {

		// don't update if domain or site is null or empty
		if ((domain != null && !("".equals(domain))) &&
				(site != null && !("".equals(site)))) {

			// both domain and site are not null, proceed with update
			try {
				if (STRATEGY_ATTRIBUTE_VALUE_AUTOMATIC.equalsIgnoreCase(site)) {
					site = getCurrentSiteName(rc);
				}
				String existingSiteCtx = responseContent.getHeader(XAPIConstants.X_SITECTX_HEADER);
				String newSiteCtx = CommunityComponentConstants.CUSTOM_ATTR_SITE_CONTEXT_AFFIX + domain.trim() + site + CommunityComponentConstants.CUSTOM_ATTR_SITE_CONTEXT_AFFIX;
				if(commonlogger.isInfoEnabled()) {
					commonlogger.info("site is " + site);
					commonlogger.info("Existing site context is " + existingSiteCtx);
					commonlogger.info("New site context is " + newSiteCtx);
				}
				// Assuming the instance will have only one site association and thus adding the site context if it does not exist
				if (existingSiteCtx == null || existingSiteCtx.equals("")) {
					String oid = responseContent.getHeader(XAPIConstants.X_OID_HEADER);
					// build the action data with custom attribute setting
					ModifyObjectAction modifyAction = new ModifyObjectAction();
					SimpleActionData actionData = new SimpleActionData();
					actionData.addParam(CommunityComponentConstants.CUSTOM_ATTR_VALUE_PREFIX + CommunityComponentConstants.CUSTOM_ATTR_SITE_CONTEXT_NAME, newSiteCtx);
					actionData.addParam("object", oid);
					Response result = modifyAction.execute(privilegedService.getClientService(), actionData);

				}
			} catch(Exception ex) {
				commonlogger.error("Error updating the site context for app instance", ex);
			}
		}

	}

	/**
	 * Method to return the image name given the local type for social search results
	 * @param localType
	 * @return imageName
	 */
	public String getImageNameForSearchResults(String localType) {
		String imageName="";
		  if("blog".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_BLOG_ARTICLE.equals(localType)){
			  imageName="blog24_b24";
		  }else if("wiki".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_WIKI_PAGE.equals(localType)){
			  imageName="wiki24_b24";
		  }else if("photolibrary".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_PHOTO.equals(localType)){
			  imageName="photo24_b24";
		  }else if("videolibrary".equalsIgnoreCase(localType) || CommunityComponentConstants.TYPE_VIDEO.equals(localType)){
			  imageName="video24_b24";
		  }
		 return imageName;
	}




    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block1Bytes, _wl_block1);

            if (_jsp__tag0(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);

	//websphere goes crazy if null attributes are present in request scope during a include
	if(pageContext.getAttribute(Constants.JSP_OVERRIDE_URI, PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute(Constants.JSP_OVERRIDE_URI, PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.jspOverrideUri", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.jspOverrideUri", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.types", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.types", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.name", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.name", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.scope", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.scope", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.displayInContextEdit", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.displayInContextEdit", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.nextURL", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.nextURL", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute(Constants.XSL_OVERRIDE_URI, PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute(Constants.XSL_OVERRIDE_URI, PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute("com.vignette.ext.templating.portlet.region.xslOverrideUri", PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute("com.vignette.ext.templating.portlet.region.xslOverrideUri", PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute(Constants.REGION_TTL_ATTR, PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute(Constants.REGION_TTL_ATTR, PageContext.REQUEST_SCOPE);
	}

	if(pageContext.getAttribute(Constants.REGION_TYPES_ATTR, PageContext.REQUEST_SCOPE) == null){
		pageContext.removeAttribute(Constants.REGION_TYPES_ATTR, PageContext.REQUEST_SCOPE);
	}

	String requestContext = (String) request.getAttribute("javax.servlet.include.context_path");	

            bw.write(_wl_block1Bytes, _wl_block1);
            bw.write(_wl_block1Bytes, _wl_block1);
        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag0(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag __tag0 = null ;
        int __result__tag0 = 0 ;

        if (__tag0 == null ){
            __tag0 = new  org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
        }
        __tag0.setPageContext(pageContext);
        __tag0.setParent(null);
        __tag0.setBasename(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("com.vignette.ext.templating.community.CommunityMsgs", java.lang.String .class,"basename"));
        _activeTag=__tag0;
        __result__tag0 = __tag0.doStartTag();

        if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag0);
            return true;
        }
        _activeTag=__tag0.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
        __tag0.release();
        return false;
    }
}
