package jsp_servlet._views;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.vignette.as.client.javabean.ManagedObject;
import com.vignette.ext.templating.client.javabean.SearchResultsComponent;
import com.vignette.as.client.javabean.SearchQuery;
import com.vignette.as.client.javabean.Channel;
import com.vignette.as.client.exception.ApplicationException;
import com.vignette.logging.context.ContextLogger;
import com.vignette.logging.LoggingManager;
import com.vignette.ext.templating.util.*;
import java.util.List;
import java.util.ArrayList;
import com.vignette.ext.templating.searchcomponent.*;
import java.util.Locale;

public final class __searchresultsview extends  weblogic.servlet.jsp.JspBase  implements weblogic.servlet.jsp.StaleIndicator {

    private static void _releaseTags(javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag t) {
        while (t != null) {
            weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, t);
            if(t instanceof javax.servlet.jsp.tagext.Tag) {
                javax.servlet.jsp.tagext.Tag tmp = (javax.servlet.jsp.tagext.Tag)t;
                t = ((javax.servlet.jsp.tagext.Tag) t).getParent();
                try {
                    tmp.release();
                } catch(java.lang.Exception ignore) {}
            }
            else {
                t = ((javax.servlet.jsp.tagext.SimpleTag)t).getParent();
            }
        }
    }

    public boolean _isStale(){
        boolean _stale = _staticIsStale((weblogic.servlet.jsp.StaleChecker) getServletConfig().getServletContext());
        return _stale;
    }

    public static boolean _staticIsStale(weblogic.servlet.jsp.StaleChecker sci) {
        if (sci.isResourceStale("/views/searchResultsView.jsp", 1323384680000L ,"10.3.3.0","US/Central")) return true;
        return false;
    }

    private static boolean _WL_ENCODED_BYTES_OK = true;
    private static final java.lang.String _WL_ORIGINAL_ENCODING = "ISO-8859-1".intern();

    private static byte[] _getBytes(java.lang.String block){
        try {
            return block.getBytes(_WL_ORIGINAL_ENCODING);
        } catch (java.io.UnsupportedEncodingException u){
            _WL_ENCODED_BYTES_OK = false;
        }
        return null;
    }

    private final static java.lang.String  _wl_block0 ="\n";
    private final static byte[]  _wl_block0Bytes = _getBytes( _wl_block0 );

    private final static java.lang.String  _wl_block1 ="\n\n";
    private final static byte[]  _wl_block1Bytes = _getBytes( _wl_block1 );

    private final static java.lang.String  _wl_block2 ="\n\n<div class=\"vgn-ext-text\" id=\"vgn-ext-search-comp-";
    private final static byte[]  _wl_block2Bytes = _getBytes( _wl_block2 );

    private final static java.lang.String  _wl_block3 ="\">\n";
    private final static byte[]  _wl_block3Bytes = _getBytes( _wl_block3 );

    private final static java.lang.String  _wl_block4 ="\n\t\t";
    private final static byte[]  _wl_block4Bytes = _getBytes( _wl_block4 );

    private final static java.lang.String  _wl_block5 ="\n\n\t\t<br>\n";
    private final static byte[]  _wl_block5Bytes = _getBytes( _wl_block5 );

    private final static java.lang.String  _wl_block6 ="\n\t\t<br><h3>";
    private final static byte[]  _wl_block6Bytes = _getBytes( _wl_block6 );

    private final static java.lang.String  _wl_block7 ="</h3><br>\n\n\t\t</div>\n";
    private final static byte[]  _wl_block7Bytes = _getBytes( _wl_block7 );

    private final static java.lang.String  _wl_block8 ="\n\t\t\t";
    private final static byte[]  _wl_block8Bytes = _getBytes( _wl_block8 );

    private final static java.lang.String  _wl_block9 ="\n\t\t<br>\n";
    private final static byte[]  _wl_block9Bytes = _getBytes( _wl_block9 );

    private final static java.lang.String  _wl_block10 ="\n\t\t<br>";
    private final static byte[]  _wl_block10Bytes = _getBytes( _wl_block10 );

    private final static java.lang.String  _wl_block11 =" <b>";
    private final static byte[]  _wl_block11Bytes = _getBytes( _wl_block11 );

    private final static java.lang.String  _wl_block12 ="</b>\n\n\t\t<br>\n";
    private final static byte[]  _wl_block12Bytes = _getBytes( _wl_block12 );

    private final static java.lang.String  _wl_block13 =" \"<b>";
    private final static byte[]  _wl_block13Bytes = _getBytes( _wl_block13 );

    private final static java.lang.String  _wl_block14 ="</b>\"\n\n\t\t<br><br>";
    private final static byte[]  _wl_block14Bytes = _getBytes( _wl_block14 );

    private final static java.lang.String  _wl_block15 =" &nbsp; \"<b>";
    private final static byte[]  _wl_block15Bytes = _getBytes( _wl_block15 );

    private final static java.lang.String  _wl_block16 ="</b>\" &nbsp; ";
    private final static byte[]  _wl_block16Bytes = _getBytes( _wl_block16 );

    private final static java.lang.String  _wl_block17 ="\n\n\t\t<br><br>\n\n\t\t<table>\n";
    private final static byte[]  _wl_block17Bytes = _getBytes( _wl_block17 );

    private final static java.lang.String  _wl_block18 ="\n\t\t\t<tr colspan=\"2\">\n\t\t\t\t<td>\n\t\t\t\t\t<a href=\"";
    private final static byte[]  _wl_block18Bytes = _getBytes( _wl_block18 );

    private final static java.lang.String  _wl_block19 ="\" class=\"vgn-ext-link\" >";
    private final static byte[]  _wl_block19Bytes = _getBytes( _wl_block19 );

    private final static java.lang.String  _wl_block20 =" </a>\n\n";
    private final static byte[]  _wl_block20Bytes = _getBytes( _wl_block20 );

    private final static java.lang.String  _wl_block21 ="\n\t\t\t\t\t\t<p>\n\t\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n\t\t\t\t\t\t\t";
    private final static byte[]  _wl_block21Bytes = _getBytes( _wl_block21 );

    private final static java.lang.String  _wl_block22 ="\n\t\t\t\t\t\t</p>\n";
    private final static byte[]  _wl_block22Bytes = _getBytes( _wl_block22 );

    private final static java.lang.String  _wl_block23 ="\n  \t\t\t\t</td>\n\t\t\t</tr>\n\n\t\t\t<tr colspan=\"2\" height=\"10\">\n\t\t\t\t<td>&nbsp;</td>\n\t\t\t</tr>\n";
    private final static byte[]  _wl_block23Bytes = _getBytes( _wl_block23 );

    private final static java.lang.String  _wl_block24 ="\n\t\t</table>\n\n";
    private final static byte[]  _wl_block24Bytes = _getBytes( _wl_block24 );

    private final static java.lang.String  _wl_block25 ="\n\t\t<script type=\"text/javascript\" src=\"/vgn-ext-templating/scripts/search.js\" >\n\t\t</script>\n\t\t\n\t\t<script type=\"text/javascript\">\t\t\t\t\n\t\t\tfunction paginateRedirect_Search(maxPageCount, currentPage){\t\t\t\t\t\t\n\t\t\t\tif(maxPageCount && currentPage) {\n\t\t\t\t\tpaginate({vgnextcomponentid : \'";
    private final static byte[]  _wl_block25Bytes = _getBytes( _wl_block25 );

    private final static java.lang.String  _wl_block26 ="\',\n\t\t\t\t\t\tvgnextoid : \'";
    private final static byte[]  _wl_block26Bytes = _getBytes( _wl_block26 );

    private final static java.lang.String  _wl_block27 ="\',\n\t\t\t\t\t\tappInstanceName : \'\',\n\t\t\t\t\t\tvgnextkeyword : \'";
    private final static byte[]  _wl_block27Bytes = _getBytes( _wl_block27 );

    private final static java.lang.String  _wl_block28 ="\',\n\t\t\t\t\t\tvgnextsearchresultspageno : document.getElementById(\'pageNumberText_search\').value,\n\t\t\t\t\t\tmaxPages : maxPageCount,\n\t\t\t\t\t\tcurrentPageNo : currentPage,\n\t\t\t\t\t\tpageNumberElementId : \'pageNumberText_search\'});\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t</script>\n\n\t\t<table width=\"100%\">\n\t\t\t<tr> \n\t\t\t\t<td>\n\t\t\t\t\t<p>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block28Bytes = _getBytes( _wl_block28 );

    private final static java.lang.String  _wl_block29 ="\n\t\t\t\t\t\t\t\t<span style=\"color:gray\"> |< </span>\n\t\t\t\t\t\t\t\t<span style=\"color:gray\"> < </span>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block29Bytes = _getBytes( _wl_block29 );

    private final static java.lang.String  _wl_block30 ="\n\t\t\t\t\t\t\t\t<a href=\"javascript:paginate({vgnextcomponentid : \'";
    private final static byte[]  _wl_block30Bytes = _getBytes( _wl_block30 );

    private final static java.lang.String  _wl_block31 ="\', vgnextoid : \'";
    private final static byte[]  _wl_block31Bytes = _getBytes( _wl_block31 );

    private final static java.lang.String  _wl_block32 ="\', appInstanceName : \'\', vgnextkeyword : \'";
    private final static byte[]  _wl_block32Bytes = _getBytes( _wl_block32 );

    private final static java.lang.String  _wl_block33 ="\', vgnextsearchresultspageno : \'1\'});\"> |< </a>\n\t\t\t\t\t\t\t\t<a href=\"javascript:paginate({vgnextcomponentid : \'";
    private final static byte[]  _wl_block33Bytes = _getBytes( _wl_block33 );

    private final static java.lang.String  _wl_block34 ="\', vgnextsearchresultspageno : \'";
    private final static byte[]  _wl_block34Bytes = _getBytes( _wl_block34 );

    private final static java.lang.String  _wl_block35 ="\'});\"> < </a>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block35Bytes = _getBytes( _wl_block35 );

    private final static java.lang.String  _wl_block36 ="\n\n\t\t\t\t\t\tPage\n\n\t\t\t\t\t\t<input type=\"text\" id=\"pageNumberText_search\" value=\'";
    private final static byte[]  _wl_block36Bytes = _getBytes( _wl_block36 );

    private final static java.lang.String  _wl_block37 ="\'\n\t\t\t\t\t\t\t   title=\"Enter Page Number\" size=\"1\"\n\t\t\t\t\t\t\t   onkeypress=\"if(event.keyCode == 13){ paginateRedirect_Search(\'";
    private final static byte[]  _wl_block37Bytes = _getBytes( _wl_block37 );

    private final static java.lang.String  _wl_block38 ="\', \'";
    private final static byte[]  _wl_block38Bytes = _getBytes( _wl_block38 );

    private final static java.lang.String  _wl_block39 ="\');document.getElementById(\'pageNumberText_search\').focus == true;}\"\n\t\t\t\t\t\t\t   onblur=\"paginateRedirect_Search(\'";
    private final static byte[]  _wl_block39Bytes = _getBytes( _wl_block39 );

    private final static java.lang.String  _wl_block40 ="\')\"/>\n\t\t\t\t\t\tof\n\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block40Bytes = _getBytes( _wl_block40 );

    private final static java.lang.String  _wl_block41 ="\n\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block41Bytes = _getBytes( _wl_block41 );

    private final static java.lang.String  _wl_block42 ="\n\t\t\t\t\t\t\t\t<span style=\"color:gray\"> > </span>\n\t\t\t\t\t\t\t\t<span style=\"color:gray\"> >| </span>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block42Bytes = _getBytes( _wl_block42 );

    private final static java.lang.String  _wl_block43 ="\', appInstanceName\t: \'\', vgnextkeyword\t: \'";
    private final static byte[]  _wl_block43Bytes = _getBytes( _wl_block43 );

    private final static java.lang.String  _wl_block44 ="\'});\"> > </a>\n\t\t\t\t\t\t\t\t<a href=\"javascript:paginate({vgnextcomponentid : \'";
    private final static byte[]  _wl_block44Bytes = _getBytes( _wl_block44 );

    private final static java.lang.String  _wl_block45 ="\'});\"> >| </a>\n\t\t\t\t\t\t";
    private final static byte[]  _wl_block45Bytes = _getBytes( _wl_block45 );

    private final static java.lang.String  _wl_block46 ="\n\t\t\t\t\t</p>\n\n\t\t\t\t</td>\n             </tr>\n          </table>\n";
    private final static byte[]  _wl_block46Bytes = _getBytes( _wl_block46 );

    private final static java.lang.String  _wl_block47 ="\n\t<br>\n";
    private final static byte[]  _wl_block47Bytes = _getBytes( _wl_block47 );

    private final static java.lang.String  _wl_block48 ="\n</div>";
    private final static byte[]  _wl_block48Bytes = _getBytes( _wl_block48 );

    static private weblogic.jsp.internal.jsp.JspFunctionMapper _jspx_fnmap = weblogic.jsp.internal.jsp.JspFunctionMapper.getInstance();

    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) 
    throws javax.servlet.ServletException, java.io.IOException {

        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        javax.servlet.jsp.tagext.JspTag _activeTag = null;
        java.lang.Object page = this;
        javax.servlet.jsp.PageContext pageContext = javax.servlet.jsp.JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true , 8192 , true );
        response.setHeader("Content-Type", "text/html");
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter)out;
        bw.setInitCharacterEncoding(_WL_ORIGINAL_ENCODING, _WL_ENCODED_BYTES_OK);
        javax.servlet.jsp.JspWriter _originalOut = out;
        javax.servlet.http.HttpSession session = request.getSession( true );
        try {;
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block0Bytes, _wl_block0);
            bw.write(_wl_block1Bytes, _wl_block1);

            if (_jsp__tag0(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block0Bytes, _wl_block0);

	/**
	 * This sample JSP is used to render view for Search Results Component. This is to demonstrate the functionality of
	 * Display View. Users can extend this JSP to customize their views.
	 */

	ContextLogger LOG = LoggingManager.getContextLogger("searchResultsView.jsp");

	RequestContext rc = PageUtil.getCurrentRequestContext(pageContext);
	Locale currentLocale = rc.getLocale();
	String vgnExtComponentId = rc.getRenderedManagedObject().getContentManagementId().getId();
	ManagedObject mo = null;
	String header = null, footer = null, title = null ;

	try{
		mo = rc.getRenderedManagedObject();
		header = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_HEADER ).getValue();
		footer = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_FOOTER ).getValue();
		title = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_TITLE ).getValue();
	}catch(Exception ex){
		rc.setNoCache(true);
		LOG.error(SysUtil.convertExceptionToString(ex));
	}

	String searchKeyword = rc.getParameter(SearchComponentConfig.RP_KEYWORD);
	int pageNumber = 1;

	try{
		pageNumber = Integer.parseInt(rc.getParameter(SearchComponentConfig.RP_PAGE_NO));
	}catch (Exception e){
		pageNumber = 1;
	}

            bw.write(_wl_block2Bytes, _wl_block2);
            out.print( vgnExtComponentId );
            bw.write(_wl_block3Bytes, _wl_block3);

	if( !TemplatingUtil.isNullOrEmpty(title) ){

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print( title );
            bw.write(_wl_block5Bytes, _wl_block5);

	}

	if( !TemplatingUtil.isNullOrEmpty(header) ){

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print( header );
            bw.write(_wl_block5Bytes, _wl_block5);

	}
	if( TemplatingUtil.isNullOrEmpty(searchKeyword)){

            bw.write(_wl_block6Bytes, _wl_block6);

            if (_jsp__tag1(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block7Bytes, _wl_block7);

			if( !TemplatingUtil.isNullOrEmpty(footer) ){

            bw.write(_wl_block8Bytes, _wl_block8);
            out.print( footer );
            bw.write(_wl_block9Bytes, _wl_block9);
			}
		return;
	}

	searchKeyword = searchKeyword.trim();

	// Render SearchResultsComponent results
	List<SearchComponentResult> searchComponentResults = new ArrayList<SearchComponentResult>();


	Integer resultsPerPage = null;
	Integer maxNoOfResults = null;

	if (mo instanceof SearchResultsComponent) {
		String xml = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_CONTENT_QUERY ).getValue();
		resultsPerPage = (Integer)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_RESULTS_PER_PAGE ).getValue();
		maxNoOfResults = (Integer)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_MAX_RESULTS ).getValue();
		String searchBoundary = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_BOUNDARY ).getValue();
		String searchOrder = (String)mo.getAttribute( SearchComponentConfig.ATTRIBUTE_ORDER_RESULTS ).getValue();

		SearchComponentQuery defaultSearchComponentQuery = SearchComponentConfig.getSearchComponentQuery();
		SearchComponentQueryExecutor searchComponentQueryExecutor = SearchComponentConfig.getSearchComponentQueryExecutor();

		String siteNamesCSV = null;

		if( !TemplatingUtil.isNullOrEmpty( searchBoundary ) && searchBoundary.equalsIgnoreCase(
											SearchComponentConfig.BOUNDARY_VALUE_CURRENT_SITE )){
			siteNamesCSV = ( rc.getCurrentSite() != null ) ? rc.getCurrentSite().getName() : null;
		}

		try{
			SearchComponentQueryParameters searchParameters = new SearchComponentQueryParameters();
			searchParameters.setKeyword( searchKeyword );
			searchParameters.setSearchOrder( searchOrder );
			searchParameters.setSearchSitesCSV(siteNamesCSV);
			if(currentLocale!=null){
				searchParameters.setLocale(currentLocale);
			}
			searchParameters.setRequestParamMap(rc.getRequest().getParameterMap());
			searchParameters.setRequestAttrMap(RequestUtil.getRequestAttributesMap( rc ));

			Channel channel = rc.getRequestedChannel();
			if( channel != null ){
				searchParameters.setCurrentChannel( channel.getId().getId() );
			}

			SearchQuery searchQuery = defaultSearchComponentQuery.getSearchQuery(xml, searchParameters);

			if( resultsPerPage != null ){
				int startIndex = ( pageNumber - 1 ) * resultsPerPage;
				int endIndex = pageNumber  * resultsPerPage;

				if( ( maxNoOfResults != null ) && ( maxNoOfResults < endIndex ) ){
					endIndex = maxNoOfResults;
				}

				searchComponentResults = searchComponentQueryExecutor.execute(searchQuery, startIndex, endIndex);
			}else{
				searchComponentResults = ( maxNoOfResults == null ) ? searchComponentQueryExecutor.execute(searchQuery)
											: searchComponentQueryExecutor.execute(searchQuery, maxNoOfResults.intValue() );
			}
		}catch(ApplicationException ex){
			out.println("<b>" + ex.getCausedByException().getMessage() + "</b><BR>");
			LOG.error(SysUtil.convertExceptionToString(ex));
		}
	}
	if( TemplatingUtil.isNullOrEmpty( searchComponentResults ) ){

            bw.write(_wl_block10Bytes, _wl_block10);

            if (_jsp__tag2(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block11Bytes, _wl_block11);
            out.print( searchKeyword );
            bw.write(_wl_block12Bytes, _wl_block12);

	}else{

            bw.write(_wl_block10Bytes, _wl_block10);

            if (_jsp__tag3(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block13Bytes, _wl_block13);
            out.print( searchKeyword );
            bw.write(_wl_block14Bytes, _wl_block14);

            if (_jsp__tag4(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block15Bytes, _wl_block15);
            out.print( searchKeyword );
            bw.write(_wl_block16Bytes, _wl_block16);

            if (_jsp__tag5(request, response, pageContext, _activeTag, null))
             return;
            bw.write(_wl_block17Bytes, _wl_block17);

		int resultNumber = ( resultsPerPage != null ) ? ( ( pageNumber -1 ) *  resultsPerPage.intValue() ) : 0 ;

		for (int index = 0, len = searchComponentResults.size(); index < len ; index++) {
			SearchComponentResult resultObject = searchComponentResults.get(index);
			String name = resultObject.getName();
			String linkURI = "";
			try{
				linkURI = XSLPageUtil.buildLinkURI(rc, resultObject.getOid(), "", "");
			}catch(Exception e){
				rc.setNoCache(true);
				LOG.error(SysUtil.convertExceptionToString(e));
			}

            bw.write(_wl_block18Bytes, _wl_block18);
            out.print(linkURI);
            bw.write(_wl_block19Bytes, _wl_block19);
            out.print(name);
            bw.write(_wl_block20Bytes, _wl_block20);

					if( !TemplatingUtil.isNullOrEmpty( resultObject.getSummary() ) ){

            bw.write(_wl_block21Bytes, _wl_block21);
            out.print(resultObject.getSummary() );
            bw.write(_wl_block22Bytes, _wl_block22);

					}

            bw.write(_wl_block23Bytes, _wl_block23);

		}

            bw.write(_wl_block24Bytes, _wl_block24);

	if( resultsPerPage != null ){
		int currentPage = pageNumber;
		int prevPageNo = currentPage - 1;
		int nextPageNo = currentPage + 1;

		int maxResultsPagination = searchComponentResults.get(0).getTotalNumberOfResults();
		if( ( maxNoOfResults != null ) && ( maxResultsPagination > maxNoOfResults.intValue() ) ) {
			maxResultsPagination = maxNoOfResults.intValue();
		}
		int totalPageCount = (int)Math.ceil( (double) maxResultsPagination / resultsPerPage.intValue());
		String primaryObjectContentId = rc.getPrimaryRequestedObject().getContentManagementId().getId();

            bw.write(_wl_block25Bytes, _wl_block25);
            out.print( vgnExtComponentId );
            bw.write(_wl_block26Bytes, _wl_block26);
            out.print( primaryObjectContentId );
            bw.write(_wl_block27Bytes, _wl_block27);
            out.print( searchKeyword );
            bw.write(_wl_block28Bytes, _wl_block28);

							if( prevPageNo <=0 ){
						
            bw.write(_wl_block29Bytes, _wl_block29);

							}else{
						
            bw.write(_wl_block30Bytes, _wl_block30);
            out.print( vgnExtComponentId );
            bw.write(_wl_block31Bytes, _wl_block31);
            out.print( primaryObjectContentId );
            bw.write(_wl_block32Bytes, _wl_block32);
            out.print( searchKeyword );
            bw.write(_wl_block33Bytes, _wl_block33);
            out.print( vgnExtComponentId );
            bw.write(_wl_block31Bytes, _wl_block31);
            out.print( primaryObjectContentId );
            bw.write(_wl_block32Bytes, _wl_block32);
            out.print( searchKeyword );
            bw.write(_wl_block34Bytes, _wl_block34);
            out.print(prevPageNo);
            bw.write(_wl_block35Bytes, _wl_block35);

							}
						
            bw.write(_wl_block36Bytes, _wl_block36);
            out.print( currentPage );
            bw.write(_wl_block37Bytes, _wl_block37);
            out.print( totalPageCount );
            bw.write(_wl_block38Bytes, _wl_block38);
            out.print( currentPage);
            bw.write(_wl_block39Bytes, _wl_block39);
            out.print( totalPageCount );
            bw.write(_wl_block38Bytes, _wl_block38);
            out.print( currentPage);
            bw.write(_wl_block40Bytes, _wl_block40);
            out.print( totalPageCount );
            bw.write(_wl_block41Bytes, _wl_block41);

							if( nextPageNo > totalPageCount ){
						
            bw.write(_wl_block42Bytes, _wl_block42);

							}else{
						
            bw.write(_wl_block30Bytes, _wl_block30);
            out.print( vgnExtComponentId );
            bw.write(_wl_block31Bytes, _wl_block31);
            out.print( primaryObjectContentId );
            bw.write(_wl_block43Bytes, _wl_block43);
            out.print( searchKeyword );
            bw.write(_wl_block34Bytes, _wl_block34);
            out.print(nextPageNo);
            bw.write(_wl_block44Bytes, _wl_block44);
            out.print( vgnExtComponentId );
            bw.write(_wl_block31Bytes, _wl_block31);
            out.print( primaryObjectContentId );
            bw.write(_wl_block43Bytes, _wl_block43);
            out.print( searchKeyword );
            bw.write(_wl_block34Bytes, _wl_block34);
            out.print(totalPageCount);
            bw.write(_wl_block45Bytes, _wl_block45);

							}
						
            bw.write(_wl_block46Bytes, _wl_block46);

		}
	}

            bw.write(_wl_block47Bytes, _wl_block47);

	if( !TemplatingUtil.isNullOrEmpty(footer) ){

            bw.write(_wl_block4Bytes, _wl_block4);
            out.print( footer );
            bw.write(_wl_block5Bytes, _wl_block5);

	}

            bw.write(_wl_block48Bytes, _wl_block48);
        } catch (java.lang.Throwable __ee){
            if(!(__ee instanceof javax.servlet.jsp.SkipPageException)) {
                while ((out != null) && (out != _originalOut)) out = pageContext.popBody(); 
                _releaseTags(pageContext, _activeTag);
                pageContext.handlePageException(__ee);
            }
        }
    }

    private boolean _jsp__tag0(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag __tag0 = null ;
        int __result__tag0 = 0 ;

        if (__tag0 == null ){
            __tag0 = new  org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag0);
        }
        __tag0.setPageContext(pageContext);
        __tag0.setParent(null);
        __tag0.setBasename(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("com.vignette.ext.templating.TemplatingJSPMsgs", java.lang.String .class,"basename"));
        _activeTag=__tag0;
        __result__tag0 = __tag0.doStartTag();

        if (__result__tag0!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag0== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
                 throw  new  javax.servlet.jsp.JspTagException("Since tag class org.apache.taglibs.standard.tag.rt.fmt.SetBundleTag does not implement BodyTag, it cannot return BodyTag.EVAL_BODY_BUFFERED");
            }
        }
        if (__tag0.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag0);
            return true;
        }
        _activeTag=__tag0.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag0);
        __tag0.release();
        return false;
    }

    private boolean _jsp__tag1(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.MessageTag __tag1 = null ;
        int __result__tag1 = 0 ;

        if (__tag1 == null ){
            __tag1 = new  org.apache.taglibs.standard.tag.rt.fmt.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag1);
        }
        __tag1.setPageContext(pageContext);
        __tag1.setParent(null);
        __tag1.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("searchcomponent.no.search.keyword", java.lang.String .class,"key"));
        _activeTag=__tag1;
        __result__tag1 = __tag1.doStartTag();

        if (__result__tag1!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag1== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag1.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag1);
            return true;
        }
        _activeTag=__tag1.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag1);
        __tag1.release();
        return false;
    }

    private boolean _jsp__tag2(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.MessageTag __tag2 = null ;
        int __result__tag2 = 0 ;

        if (__tag2 == null ){
            __tag2 = new  org.apache.taglibs.standard.tag.rt.fmt.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag2);
        }
        __tag2.setPageContext(pageContext);
        __tag2.setParent(null);
        __tag2.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("searchcomponent.no.search.results", java.lang.String .class,"key"));
        _activeTag=__tag2;
        __result__tag2 = __tag2.doStartTag();

        if (__result__tag2!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag2== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag2.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag2);
            return true;
        }
        _activeTag=__tag2.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag2);
        __tag2.release();
        return false;
    }

    private boolean _jsp__tag3(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.MessageTag __tag3 = null ;
        int __result__tag3 = 0 ;

        if (__tag3 == null ){
            __tag3 = new  org.apache.taglibs.standard.tag.rt.fmt.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag3);
        }
        __tag3.setPageContext(pageContext);
        __tag3.setParent(null);
        __tag3.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("searchcomponent.search.results", java.lang.String .class,"key"));
        _activeTag=__tag3;
        __result__tag3 = __tag3.doStartTag();

        if (__result__tag3!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag3== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag3.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag3);
            return true;
        }
        _activeTag=__tag3.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag3);
        __tag3.release();
        return false;
    }

    private boolean _jsp__tag4(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.MessageTag __tag4 = null ;
        int __result__tag4 = 0 ;

        if (__tag4 == null ){
            __tag4 = new  org.apache.taglibs.standard.tag.rt.fmt.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag4);
        }
        __tag4.setPageContext(pageContext);
        __tag4.setParent(null);
        __tag4.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("searchcomponent.search.text.1", java.lang.String .class,"key"));
        _activeTag=__tag4;
        __result__tag4 = __tag4.doStartTag();

        if (__result__tag4!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag4== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag4.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag4);
            return true;
        }
        _activeTag=__tag4.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag4);
        __tag4.release();
        return false;
    }

    private boolean _jsp__tag5(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.jsp.PageContext pageContext, javax.servlet.jsp.tagext.JspTag activeTag, javax.servlet.jsp.tagext.JspTag parent) throws java.lang.Throwable
    {
        javax.servlet.jsp.tagext.JspTag _activeTag = activeTag;
        javax.servlet.jsp.JspWriter out = pageContext.getOut();
        weblogic.servlet.jsp.ByteWriter bw = (weblogic.servlet.jsp.ByteWriter) out;
         org.apache.taglibs.standard.tag.rt.fmt.MessageTag __tag5 = null ;
        int __result__tag5 = 0 ;

        if (__tag5 == null ){
            __tag5 = new  org.apache.taglibs.standard.tag.rt.fmt.MessageTag ();
            weblogic.servlet.jsp.DependencyInjectionHelper.inject(pageContext, __tag5);
        }
        __tag5.setPageContext(pageContext);
        __tag5.setParent(null);
        __tag5.setKey(( java.lang.String ) weblogic.jsp.internal.jsp.utils.JspRuntimeUtils.convertType("searchcomponent.search.text.2", java.lang.String .class,"key"));
        _activeTag=__tag5;
        __result__tag5 = __tag5.doStartTag();

        if (__result__tag5!= javax.servlet.jsp.tagext.Tag.SKIP_BODY){
            if (__result__tag5== javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_BUFFERED) {
            }
        }
        if (__tag5.doEndTag()== javax.servlet.jsp.tagext.Tag.SKIP_PAGE){
            _activeTag = null;
            _releaseTags(pageContext, __tag5);
            return true;
        }
        _activeTag=__tag5.getParent();
        weblogic.servlet.jsp.DependencyInjectionHelper.preDestroy(pageContext, __tag5);
        __tag5.release();
        return false;
    }
}
