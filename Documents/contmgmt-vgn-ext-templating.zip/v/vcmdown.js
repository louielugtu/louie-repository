var vgnextvcmdown = {
	init: function() {
		this.serverPrefix = document.location.protocol+"//"+document.location.host;
		this.imagePrefix = this.serverPrefix + "/vgn-ext-templating/vcmdown-images/";
		this.vcmPingUrl = this.serverPrefix + "/cps/script/preview/cps-ping.jsp";
		if (window.XMLHttpRequest) {
			// code for all new browsers
			this.xmlhttp = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			// code for IE5 and IE6
			this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	},
	retry: function() {
		var xmlhttp = this.xmlhttp;
		if (xmlhttp != null) {
			this.button.disabled = true;
			this.ready.style.display = 'none';
			this.wait.style.display = '';
			this.timeout = 30000;
			try {
				xmlhttp.open("GET", this.vcmPingUrl, false);
				xmlhttp.send(null);
				if (xmlhttp.readyState == 4) {
					if (xmlhttp.status == 200) {
						//VCM is now up
						document.location.reload(true);
					}
				}
			} catch (ex) {
			}
			this.button.disabled = false;
			this.ready.style.display = '';
			this.wait.style.display = 'none';
		}
	}
};
(function(){
	vgnextvcmdown.init();
	document.writeln(
	'<style type="text/css">'+
		'.vui-cps-ui-vcmdownfloatie{position: fixed; bottom: 0; left: 0; z-index: 10000;}'+
		'.vui-cps-ui-vcmdownfloatie, .vui-cps-ui-vcmdownfloatie .warning-message{font-family: arial, sans-serif; font-size: 0.875em;}'+
		'.vui-cps-ui-vcmdownfloatie .x-window-tl{background: transparent url("'+vgnextvcmdown.imagePrefix+'headerSprite-opt.png") no-repeat scroll left top; padding-left: 6px; zoom: 1; z-index: 1; position: relative;}'+
		'.vui-cps-ui-vcmdownfloatie .x-window-tr{background: transparent url("'+vgnextvcmdown.imagePrefix+'headerSprite-opt.png") no-repeat scroll right -104px; padding-right: 6px;}'+
		'.vui-cps-ui-vcmdownfloatie .x-window-tc{background: transparent url("'+vgnextvcmdown.imagePrefix+'headerSprite-opt.png") repeat-x scroll left -312px; zoom: 1;}'+
		'.vui-cps-ui-vcmdownfloatie .x-window-tc .x-window-header{background: transparent url("'+vgnextvcmdown.imagePrefix+'headerSprite-opt.png") no-repeat scroll right -208px; padding: 2px 0 2px;}'+
		'.vui-cps-ui-vcmdownfloatie .vui-cps-icon-warning, .vui-cps-ui-vcmdownfloatie .x-btn-retry{font-size: 0.85em;}'+
		'.vui-cps-ui-vcmdownfloatie .vui-cps-icon-warning{font-weight: bold; width: 100px; height: 16px; margin: 0 0 0 3px; overflow: hidden; padding: 1px 0 0 19px; background: transparent url("'+vgnextvcmdown.imagePrefix+'warning.png") no-repeat; color: #ffffff;}'+
		'.vui-cps-ui-vcmdownfloatie .x-btn-retry{background: #cccccc none no-repeat;}'+
	'</style>');
	document.writeln(
	'<div class="vui-cps-ui-vcmdownfloatie">'+
		'<div class="x-window-tl">'+
			'<div class="x-window-tr">'+
				'<div class="x-window-tc">'+
					'<div class="x-window-header">'+
						'<span class="x-window-header-text vui-cps-icon-warning">Server Down&nbsp;&nbsp;</span>'+
						'<img id="vgnextvcmdown_wait" src="'+vgnextvcmdown.imagePrefix+'animated_wait.gif" style="display: none;" width="16" height="16"/>'+
						'<img id="vgnextvcmdown_ready" src="'+vgnextvcmdown.imagePrefix+'s.gif" width="16" height="16"/>'+
						'<input id="vgnextvcmdown_button" type="button" class="x-btn-retry" value="Retry" onclick="vgnextvcmdown.retry();" />'+
					'</div>'+
				'</div>'+
			'</div>'+
		'</div>'+
	'</div>');
	vgnextvcmdown.wait = document.getElementById('vgnextvcmdown_wait');
	vgnextvcmdown.ready = document.getElementById('vgnextvcmdown_ready');
	vgnextvcmdown.button = document.getElementById('vgnextvcmdown_button');
})();
